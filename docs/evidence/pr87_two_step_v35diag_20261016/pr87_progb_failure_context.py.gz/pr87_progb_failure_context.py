"""Add call-site context to the frozen V31 ProgB transient diagnostic."""

from __future__ import annotations

import hashlib


V31_KDM6_SHA256 = "9cb8d19bf676771e5bfd717d07cdaf43b4bc63912b0b7869b977fbd0f2ac1397"
_CALL = "   call ProgB_param(brs,qrs_tmp,rhox,its,ite,jts,jte,kts,kte,qcrmin"
_CALL_END = (
    "                   ,g1pbg,g3pbg,g4pbg,g5pbgo2,g1pdgbgmg,dgbgmug1,progb_status)"
)
_TRANSIENT = "            progb_status(i,k) = PROGB_TRANSIENT\n            cycle"


def add_progb_failure_context(source: str) -> str:
    """Return V31 KDM6 source with transient-only call and location reporting."""
    actual_hash = hashlib.sha256(source.encode()).hexdigest()
    if actual_hash != V31_KDM6_SHA256:
        raise ValueError(f"unexpected V31 KDM6 source hash: {actual_hash}")

    calls = source.count(_CALL)
    if calls != 7:
        raise ValueError(f"expected 7 ProgB call sites, found {calls}")
    call_number = 0
    pieces: list[str] = []
    cursor = 0
    while True:
        start = source.find(_CALL, cursor)
        if start < 0:
            pieces.append(source[cursor:])
            break
        end = source.find("\n", start)
        if end < 0:
            raise ValueError("unterminated ProgB call anchor")
        # The actual call spans several continuation lines. Locate its final actual.
        call_end = source.find(_CALL_END, end)
        if call_end < 0:
            raise ValueError("ProgB call final-argument anchor missing")
        call_end += len(_CALL_END)
        call_number += 1
        pieces.append(source[cursor:call_end - len(")")])
        pieces.append(f",source_context={call_number},source_lat=lat)")
        cursor = call_end
    if call_number != 7:
        raise ValueError(f"expected to annotate 7 calls, annotated {call_number}")
    source = "".join(pieces)

    old_signature = (
        "                         ,g1pbg,g3pbg,g4pbg,g5pbgo2,g1pdgbgmg,dgbgmug1,progb_status)"
    )
    new_signature = (
        "                         ,g1pbg,g3pbg,g4pbg,g5pbgo2,g1pdgbgmg,dgbgmug1,progb_status &\n"
        "                         ,source_context,source_lat)"
    )
    if source.count(old_signature) != 1:
        raise ValueError("ProgB private signature anchor missing or ambiguous")
    source = source.replace(old_signature, new_signature, 1)

    routine_start = source.index("   SUBROUTINE ProgB_param(")
    routine_end = source.index("  END subroutine ProgB_param", routine_start)
    routine = source[routine_start:routine_end]

    declarations = "  INTEGER, DIMENSION( its:ite , kts:kte),INTENT(OUT) :: progb_status\n"
    declarations_new = declarations + (
        "  integer, optional, intent(in) :: source_context, source_lat\n"
        "  integer :: pr87_context, pr87_lat\n"
        "  logical :: pr87_transient_logged\n"
    )
    if routine.count(declarations) != 1:
        raise ValueError("ProgB declaration anchor missing or ambiguous")
    routine = routine.replace(declarations, declarations_new, 1)

    init_anchor = "      do k = kts, kte\n        do i = its, ite\n"
    init_new = (
        "      pr87_context = 0\n"
        "      pr87_lat = 0\n"
        "      if (present(source_context)) pr87_context = source_context\n"
        "      if (present(source_lat)) pr87_lat = source_lat\n"
        "      pr87_transient_logged = .false.\n"
        + init_anchor
    )
    if routine.count(init_anchor) != 1:
        raise ValueError("ProgB loop initialization anchor missing or ambiguous")
    routine = routine.replace(init_anchor, init_new, 1)

    transient_new = (
        "            progb_status(i,k) = PROGB_TRANSIENT\n"
        "            if (present(source_context) .and. present(source_lat) .and. &\n"
        "                .not.pr87_transient_logged) then\n"
        "              write(*,'(A,4(1X,I0),3(1X,ES24.16E3),2(1X,Z8.8))') &\n"
        "                'PR87_PROGB_TRANSIENT',pr87_context,pr87_lat,i,k, &\n"
        "                dble(qrs(i,k,3)),dble(brs(i,k)), &\n"
        "                dble(qrs(i,k,3))/dble(brs(i,k)), &\n"
        "                transfer(qrs(i,k,3),0),transfer(brs(i,k),0)\n"
        "              flush(6)\n"
        "              pr87_transient_logged = .true.\n"
        "            endif\n"
        "            cycle"
    )
    if routine.count(_TRANSIENT) != 1:
        raise ValueError("ProgB transient branch anchor missing or ambiguous")
    routine = routine.replace(_TRANSIENT, transient_new, 1)
    source = source[:routine_start] + routine + source[routine_end:]
    return source
