from __future__ import annotations

import gzip
import hashlib
from pathlib import Path
import sys

import pytest


ROOT = Path(__file__).resolve().parents[1]
SOURCE = ROOT / "docs/evidence/pr87_two_step_v34_20261016/module_mp_kdm6.F.gz"
sys.path.insert(0, str(ROOT / "tools"))

from pr87_process_failure_context import (  # noqa: E402
    V34_KDM6_SHA256,
    add_process_failure_context,
)


def test_failure_context_is_hash_pinned_and_diagnostic_only():
    source = gzip.open(SOURCE, "rt").read()
    assert hashlib.sha256(source.encode()).hexdigest() == V34_KDM6_SHA256

    transformed = add_process_failure_context(source)
    marker = transformed.index("              write(*,'(a,9(1x,i0))') 'PR87_GSEARCH_FAIL_META'")
    end = transformed.index("              if (.not.rain_bg_rates_feasible) then", marker)
    diagnostic = transformed[marker:end]
    assert transformed.count("PR87_GSEARCH_FAIL_META") == 1
    assert transformed.count("PR87_GSEARCH_FAIL_STATE") == 1
    assert transformed.count("PR87_GSEARCH_FAIL_CONFIG") == 1
    assert transformed.rfind("if (.not.rain_process_feasible) then", 0, marker) >= 0
    assert "error stop 'KDM6 cold rain process rejected an infeasible moment state'" in transformed[end:]
    for operand in (
        "rain_g_q_process", "rain_g_n_process", "rain_g_bg_process", "rain_g_t_process",
        "rain_g_qv_process", "rain_g_alpha", "rain_process_search_status",
        "dry_carrier_density(i,k)", "ice_full_sublimation_pending(i,k)",
        "real(PR85_ICE_NATIVE_INACTIVE_MAX,8)",
    ):
        assert operand in diagnostic
    assert "rain_q_fixed,8),real(rain_g_q_process,8)" in diagnostic
    assert "rain_n_fixed,8),real(rain_g_n_process,8)" in diagnostic

    # Removing the inserted reporter recovers the source byte-for-byte.
    recovered = transformed[:marker] + transformed[end:]
    assert recovered == source
    with pytest.raises(ValueError, match="unexpected V34 KDM6 source hash"):
        add_process_failure_context(source + "\n")
