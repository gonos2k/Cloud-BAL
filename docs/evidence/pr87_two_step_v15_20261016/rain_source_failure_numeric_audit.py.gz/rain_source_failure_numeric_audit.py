#!/usr/bin/env python3
"""Audit V15 p3 rain source-weighted and full-only failure ratios."""
from __future__ import annotations

import gzip
from decimal import Decimal
import hashlib
import json
import math
import pathlib
import struct
import sys

import numpy as np

ROOT = pathlib.Path('/var/tmp')
RUNS = {arm: ROOT / f'pr87_joint_{arm}_40s_v15_20261016' for arm in ('OFF','COUPLED')}
SOURCE_SHA = 'cacefe3d99d744c26203068791e83a991fa6db2d6e33a5a4ba950fa4f24fe738'
EM_SOURCE_SHA = '86360c01b00b8a7b8804a93aae3bc47e4bf63b389dd66c269736c6036768baaa'
BUILD_SHA = '588a4dea2cd92d36f612aa8552c659310058c8ddab1d488dd8687452f6a45853'
PIDNR_R32 = 12566.37109375
LAMBDAMIN_R32 = 961.0
LAMBDAMAX_R32 = 35000.0
POWER_R32 = 3.0
TAGS = {'SOURCE','FULL','SOURCE_NOT_STORABLE_R32','SOURCE_FAILURE_COUNT','FULL_FAILURE_COUNT'}


def sha256(path: pathlib.Path) -> str:
    digest=hashlib.sha256()
    with path.open('rb') as stream:
        for block in iter(lambda:stream.read(1024*1024),b''):
            digest.update(block)
    return digest.hexdigest()


def parse_list_records(path: pathlib.Path) -> dict:
    before=sha256(path)
    rows=[]; current_tag=None; values=[]; totals={}
    def finish():
        if current_tag is None: return
        if current_tag in {'FULL','SOURCE'}:
            expected=20 if current_tag=='FULL' else 16
            if len(values)!=expected:
                raise ValueError(f'{path}: {current_tag} record has {len(values)} numeric values; expected {expected}')
            rows.append((current_tag,values.copy()))
        else:
            if len(values)!=1: raise ValueError(f'{path}: malformed {current_tag} count row')
            totals[current_tag]=int(values[0])
    with gzip.open(path,'rt',encoding='ascii') as stream:
        for line_number,line in enumerate(stream,1):
            fields=line.split()
            if fields and fields[0] in TAGS:
                finish(); current_tag=fields[0]; values=fields[1:]
            elif current_tag is not None:
                values.extend(fields)
    finish()
    if sha256(path)!=before: raise ValueError(f'{path}: artifact changed while read')
    return {'path':str(path),'sha256':before,'bytes':path.stat().st_size,'rows':rows,'totals':totals}


def read_exact(stream, count: int) -> bytes:
    chunks=[]; remaining=count
    while remaining:
        block=stream.read(remaining)
        if not block: raise ValueError('truncated binary stage ledger')
        chunks.append(block); remaining-=len(block)
    return b''.join(chunks)


def read_first_post(path: pathlib.Path, target_cells: set[tuple[int,int,int]]) -> dict:
    before=sha256(path); selected={}; record_count=0
    with gzip.open(path,'rb') as stream:
        while True:
            magic=stream.read(8)
            if not magic: break
            if len(magic)!=8: raise ValueError('truncated stage magic')
            label=read_exact(stream,32).decode('ascii').strip()
            header=struct.unpack('>15i',read_exact(stream,60))
            kind,step,rk,ims,ime,jms,jme,kms,kme,its,ite,jts,jte,kts,kte=header
            if magic not in (b'PR85QND2',b'PR85PLB1'):
                raise ValueError(f'unexpected stage magic {magic!r}')
            cells=(ite-its+1)*(kte-kts+1)*(jte-jts+1)
            if min(ite-its,kte-kts,jte-jts)<0: raise ValueError(f'invalid stage bounds {label}')
            if magic==b'PR85QND2':
                if kind!=1: raise ValueError('bad state-stage kind')
                fields=('DEN','Q','QC','QI','QR','QS','QG','NN','NC','NI','NR','BG')
                for field in fields:
                    raw=read_exact(stream,cells*4)
                    if label=='POST_KDM6' and step==1 and field in ('QR','NR'):
                        ni=ite-its+1; nk=kte-kts+1
                        for i,j,k in target_cells:
                            if its<=i<=ite and jts<=j<=jte and kts<=k<=kte:
                                offset=((j-jts)*nk+(k-kts))*ni+(i-its)
                                selected.setdefault((i,j,k),{})[field]=struct.unpack_from('>f',raw,offset*4)[0]
            else:
                if kind!=2: raise ValueError('bad tendency-stage kind')
                for _ in range(5): read_exact(stream,cells*4)
            if label=='POST_KDM6' and step==1: record_count+=1
    if sha256(path)!=before: raise ValueError(f'{path}: stage ledger changed while read')
    missing=[cell for cell in target_cells if cell not in selected or set(selected[cell])!={'QR','NR'}]
    return {'path':str(path),'sha256':before,'bytes':path.stat().st_size,
            'first_post_records':record_count,'selected':selected,'missing':missing}


def f32(value: float) -> float:
    return float(np.float32(value))

def printed_token_roundtrips_f32(token: str) -> bool:
    decimal_value=Decimal(token)
    decoded=Decimal.from_float(f32(float(token)))
    unit=Decimal(1).scaleb(decimal_value.adjusted()-(len(decimal_value.as_tuple().digits)-1))
    return abs(decimal_value-decoded)<=unit/2


def round_interval(value: float) -> tuple[float,float]:
    x=np.float32(value)
    low=np.nextafter(x,np.float32(-np.inf),dtype=np.float32)
    high=np.nextafter(x,np.float32(np.inf),dtype=np.float32)
    return ((float(low)+float(x))/2.0,(float(x)+float(high))/2.0)


def ulp32(value: float) -> float:
    x=np.float32(value)
    return abs(float(np.nextafter(x,np.float32(np.inf),dtype=np.float32))-float(x))


def full_rows(parsed: dict) -> list[dict]:
    result=[]
    for tag,v in parsed['rows']:
        if tag!='FULL': continue
        step,rk,p,i,j,k=map(int,v[:6])
        floats=list(map(float,v[6:]))
        old,new,qb,nb,qs,ns,qa,na,qfull,nfull,qstore,nstore,rho,dt=floats
        # These fields are declared REAL32 in the source writer. Reconstruct their
        # stored values by the nearest REAL32 conversion of their list output.
        old,new,qb,nb,rho,dt=map(f32,(old,new,qb,nb,rho,dt))
        result.append({'step':step,'rk':rk,'pair':p,'i':i,'j':j,'k':k,
          'oldcarrier':old,'newcarrier':new,'qb':qb,'nb':nb,'qs':qs,'ns':ns,'qa':qa,'na':na,
          'qfull_print':qfull,'nfull_print':nfull,'qfull_store':qstore,'nfull_store':nstore,
          'rho':rho,'dt':dt})
    return result


def rel_to_bound(q: float,n: float,bound: float) -> float | None:
    if q<=0 or n<=0: return None
    return (q/n)/bound-1.0


def classify(values: list[float|None], lower: float, upper: float) -> dict:
    usable=[v for v in values if v is not None and math.isfinite(v)]
    lowtol=8*ulp32(lower); uptol=8*ulp32(upper)
    below=[v for v in usable if v<lower]; above=[v for v in usable if v>upper]
    beyond=[v for v in usable if v<lower-lowtol or v>upper+uptol]
    inside8=[v for v in usable if (lower<=v<lower+lowtol) or (upper-uptol<v<=upper)]
    return {'n':len(usable),'exact_cone_outside':len(below)+len(above),
      'below_lower':len(below),'above_upper':len(above),
      'outside_8_float32_ulp_tolerance':len(beyond),
      'outside_exact_but_within_8_ulp':len(below)+len(above)-len(beyond),
      'minimum_ratio_over_lower_bound':min(usable) if usable else None,
      'maximum_ratio_over_lower_bound':max(usable) if usable else None,
      'minimum_relative_to_lower':min((v/lower-1 for v in usable),default=None),
      'maximum_relative_to_lower':max((v/lower-1 for v in usable),default=None),
      'lower_8ulp_absolute_tolerance':lowtol,'upper_8ulp_absolute_tolerance':uptol}


def audit_arm(arm: str, parsed: dict, stage: dict) -> dict:
    rows=full_rows(parsed)
    if len(rows)!=131 or any((r['step'],r['rk'],r['pair'])!=(2,1,3) for r in rows):
        raise ValueError(f'{arm}: unexpected FULL scope')
    lower=PIDNR_R32/(LAMBDAMAX_R32**POWER_R32)
    upper=PIDNR_R32/(LAMBDAMIN_R32**POWER_R32)
    lower_coefficient_rho=[]; upper_coefficient_rho=[]
    source_ratio=[]; full_ratio=[]; air_ratio=[]
    source_r32=[]; full_r32=[]; source_volume32=[]; full_volume32=[]
    rate_signs={name:{'positive':0,'zero':0,'negative':0} for name in ('source_only','air_only','combined')}
    pair_zero_combinations={'source_zero_air_zero':0,'source_zero_air_nonzero':0,'source_nonzero_air_zero':0,'both_nonzero':0,'mixed_sign_component':0}
    interval_plausible=0; interval_any_cone=0; interval_below_only=0; interval_above_only=0; air_dominated=0; exact_f32_counts={k:0 for k in ('qs','ns','qa','na','qb','nb','oldcarrier','newcarrier','rho','dt')}
    source_lower_rel=[]; air_lower_rel=[]; full_lower_rel=[]; source_full_shift=[]
    firstpost_relation={'cells':0,'q_zero':0,'n_zero':0,'both_zero':0,'mismatch_vs_failure_base':0}
    for r in rows:
        w0,w1,dt=r['oldcarrier'],r['newcarrier'],r['dt']; rho=r['rho']
        qs,ns,qa,na=r['qs'],r['ns'],r['qa'],r['na']
        for key in exact_f32_counts:
            exact_f32_counts[key]+=int(f32(r[key])==r[key])
        source_zero=(qs==0.0 and ns==0.0); air_zero=(qa==0.0 and na==0.0)
        if source_zero and air_zero: pair_zero_combinations['source_zero_air_zero']+=1
        elif source_zero: pair_zero_combinations['source_zero_air_nonzero']+=1
        elif air_zero: pair_zero_combinations['source_nonzero_air_zero']+=1
        else: pair_zero_combinations['both_nonzero']+=1
        if (qs==0.0)!=(ns==0.0) or (qa==0.0)!=(na==0.0): pair_zero_combinations['mixed_sign_component']+=1
        for name,qv,nv in (('source_only',qs,ns),('air_only',qa,na),('combined',qs+qa,ns+na)):
            if qv>0 and nv>0: rate_signs[name]['positive']+=1
            elif qv==0 and nv==0: rate_signs[name]['zero']+=1
            else: rate_signs[name]['negative']+=1
        qsrc=qs; nsrc=ns
        qair=qa; nair=na
        qfull=r['qfull_print']; nfull=r['nfull_print']
        # dt is written with only ~7 decimal digits, so reconstructing absolute
        # candidates from it is not reliable. This cone audit uses ratios, where
        # the common positive dt/W factor cancels when the starting pair is zero.
        if r['qb'] != 0.0 or r['nb'] != 0.0:
            raise ValueError(f"{arm}: nonzero starting pair prevents ratio-only cancellation at {(r['i'],r['j'],r['k'])}")
        source_ratio.append(qsrc/nsrc if nsrc>0 else None)
        full_ratio.append(qfull/nfull if nfull>0 else None)
        air_ratio.append(qa/na if na>0 else None)
        source_lower_rel.append((qsrc/nsrc)/lower-1 if nsrc>0 else float('nan'))
        air_lower_rel.append((qa/na)/lower-1 if na>0 else float('nan'))
        full_lower_rel.append((qfull/nfull)/lower-1 if nfull>0 else float('nan'))
        source_full_shift.append((qfull/nfull)/(qsrc/nsrc)-1 if nsrc>0 and nfull>0 else float('nan'))
        qsrc32,nsrc32=f32(qsrc),f32(nsrc); qfull32,nfull32=f32(qfull),f32(nfull)
        source_r32.append(rel_to_bound(qsrc32,nsrc32,lower))
        full_r32.append(rel_to_bound(qfull32,nfull32,lower))
        # Match the helper's strict public number-volume product: REAL64(rho*N)
        # and its REAL32 cast are both compared to the same REAL64 bounds.
        rho64=float(np.float32(rho))
        bmin=rho64*(LAMBDAMIN_R32**POWER_R32)/PIDNR_R32
        bmax=rho64*(LAMBDAMAX_R32**POWER_R32)/PIDNR_R32
        src_nv64=nsrc32*rho64; full_nv64=nfull32*rho64
        src_nv32=f32(src_nv64); full_nv32=f32(full_nv64)
        source_volume32.append({'low':src_nv32>=bmin*qsrc32,'high':src_nv32<=bmax*qsrc32,
                                'continuous_low':nsrc*rho64>=bmin*qsrc,
                                'continuous_high':nsrc*rho64<=bmax*qsrc})
        full_volume32.append({'low':full_nv32>=bmin*qfull32,'high':full_nv32<=bmax*qfull32,
                              'continuous_low':nfull*rho64>=bmin*qfull,
                              'continuous_high':nfull*rho64<=bmax*qfull})
        qlo,qhi=round_interval(qa); nlo,nhi=round_interval(na)
        qbest=qs+qhi
        nbest=ns+nlo
        best_rel=rel_to_bound(qbest,nbest,lower)
        if best_rel is not None and best_rel>=0: interval_plausible+=1
        min_ratio=(qs+qlo)/(ns+nhi) if ns+nhi>0 else float('inf')
        max_ratio=(qs+qhi)/(ns+nlo) if ns+nlo>0 else float('inf')
        if max_ratio>=lower and min_ratio<=upper: interval_any_cone+=1
        elif max_ratio<lower: interval_below_only+=1
        elif min_ratio>upper: interval_above_only+=1
        if na>0 and ns>0 and (qa/na)<lower and (qsrc/ns)>lower: air_dominated+=1
        cell=(r['i'],r['j'],r['k'])
        post=stage['selected'].get(cell)
        if post is not None:
            firstpost_relation['cells']+=1
            firstpost_relation['q_zero']+=int(post['QR']==0.0)
            firstpost_relation['n_zero']+=int(post['NR']==0.0)
            firstpost_relation['both_zero']+=int(post['QR']==0.0 and post['NR']==0.0)
            firstpost_relation['mismatch_vs_failure_base']+=int(post['QR']!=r['qb'] or post['NR']!=r['nb'])
    def bool_counts(rows,key):
        return {'pass':sum(int(x[key]) for x in rows),'fail':len(rows)-sum(int(x[key]) for x in rows)}
    return {'arm':arm,'full_rows':len(rows),'scope':{'timestep':2,'rk':1,'pair_index':3,'pair_name':'rain'},
      'native_r32_coefficients':{'pidnr':PIDNR_R32,'lambda_min':LAMBDAMIN_R32,'lambda_max':LAMBDAMAX_R32,'power':POWER_R32,
        'exact_lower_mean_mass':lower,'exact_upper_mean_mass':upper,
        'lower_8_ulp_tolerance':8*ulp32(lower),'upper_8_ulp_tolerance':8*ulp32(upper)},
      'continuous_specific_mass_ratio':{
        'source_weighted_no_air':classify(source_ratio,lower,upper),
        'air_tendency_only':classify(air_ratio,lower,upper),
        'combined_source_plus_recorded_r32_air':classify(full_ratio,lower,upper)},
      'relative_margin_summary':{
        'source_weighted_no_air':{'min':min(x for x in source_lower_rel if math.isfinite(x)),'max':max(x for x in source_lower_rel if math.isfinite(x)),'mean':sum(x for x in source_lower_rel if math.isfinite(x))/sum(math.isfinite(x) for x in source_lower_rel)},
        'air_tendency_only':{'min':min(x for x in air_lower_rel if math.isfinite(x)),'max':max(x for x in air_lower_rel if math.isfinite(x)),'mean':sum(x for x in air_lower_rel if math.isfinite(x))/sum(math.isfinite(x) for x in air_lower_rel)},
        'combined_source_plus_recorded_r32_air':{'min':min(x for x in full_lower_rel if math.isfinite(x)),'max':max(x for x in full_lower_rel if math.isfinite(x)),'mean':sum(x for x in full_lower_rel if math.isfinite(x))/sum(math.isfinite(x) for x in full_lower_rel)},
        'combined_minus_source_ratio_relative':{'min':min(x for x in source_full_shift if math.isfinite(x)),'max':max(x for x in source_full_shift if math.isfinite(x)),'mean':sum(x for x in source_full_shift if math.isfinite(x))/sum(math.isfinite(x) for x in source_full_shift)}},
      'rate_sign_counts':rate_signs,
      'source_air_pair_overlap':pair_zero_combinations,
      'recorded_rate_token_checks':{
        'source_and_air_rates_are_declared_real32_widened_in_v15_source':True,
        'printed_rate_tokens_round_to_source_real32_values':{name:sum(printed_token_roundtrips_f32(v[10+idx]) for tag,v in parsed['rows'] if tag=='FULL') for idx,name in enumerate(('qs','ns','qa','na'))},
        'full_rows':len(rows),
        'meaning':'The ledger decimal text is rounded; these checks allow at most half a unit in its last printed decimal digit before confirming the token identifies its declared REAL32 value.'},
      'rounding_interval_diagnostic':{
        'air_rate_casts_are_real32_widened':all(printed_token_roundtrips_f32(v[12+idx]) for tag,v in parsed['rows'] if tag=='FULL' for idx in (0,1)),
        'rows_where_some_r64_air_rate_pair_within_each_recorded_r32_rounding_bin_can_meet_lower_cone':interval_plausible,
        'rows_where_full_rate_ratio_interval_intersects_exact_cone':interval_any_cone,
        'rows_where_interval_stays_below_exact_cone':interval_below_only,
        'rows_where_interval_stays_above_exact_cone':interval_above_only,
        'rows_where_r32_air_rate_ratio_is_below_bound_but_source_only_ratio_is_above':air_dominated,
        'interpretation':'possibility test over independent R32 round-to-nearest bins for the recorded air Q/N rates; not the actual unrounded air_tendency result because the raw failure record stores only widened R32 casts'},
      'first_post_state_crosscheck':{**firstpost_relation,'missing_stage_cells':stage['missing'],'post_record_count':stage['first_post_records'],
        'interpretation':'compares prior timestep POST_KDM6 QR/NR with each step-2 RK1 failure base at matching i,j,k; does not substitute for step-2 PRE_RK state'},
      'record_precision_checks':{'starting_pair_is_zero_for_all_full_rows':True,'full_qn_ratio_uses_printed_candidate_fields_because_dt_text_is_coarse':True,
        'full_writer_sentinel_invalid_stored_pair_count':sum(r['qfull_store']==-1.0 and r['nfull_store']==-1.0 for r in rows),
        'all_rate_tokens_identify_source_real32_values':all(printed_token_roundtrips_f32(v[10+idx]) for tag,v in parsed['rows'] if tag=='FULL' for idx in range(4)),
        'combined_ratio_matches_qfull_over_nfull_from_printed_rates':{'max_absolute_relative_difference':max(abs(((float(v[14])/float(v[15]))/((float(v[10])+float(v[12]))/(float(v[11])+float(v[13]))))-1.0) for tag,v in parsed['rows'] if tag=='FULL'),'all_within_1e-14':all(abs(((float(v[14])/float(v[15]))/((float(v[10])+float(v[12]))/(float(v[11])+float(v[13]))))-1.0)<1e-14 for tag,v in parsed['rows'] if tag=='FULL')}}}


def main() -> None:
    parsed={}; stages={}; receipts={}
    for arm,run in RUNS.items():
        receipt_path=run/'receipt.json'; receipt=json.loads(receipt_path.read_text()); receipts[arm]=receipt
        if receipt.get('status')!='INCOMPLETE' or receipt.get('returncode')!=1:
            raise ValueError(f'{arm}: expected closed incomplete receipt')
        if receipt['candidate_build']['receipt_sha256']!=BUILD_SHA:
            raise ValueError(f'{arm}: run is not bound to V15 build')
        listed={row['path']:row for row in receipt['generated_files']}
        for name in ('pr85_joint_source_failure.raw.gz','pr85_joint_moment_stages.raw.gz'):
            path=run/'run'/name; row=listed.get(name)
            if row is None or row['sha256']!=sha256(path) or row['bytes']!=path.stat().st_size:
                raise ValueError(f'{arm}: receipt does not bind {name}')
        parsed[arm]=parse_list_records(run/'run/pr85_joint_source_failure.raw.gz')
    if parsed['OFF']['sha256']!=parsed['COUPLED']['sha256']:
        raise ValueError('OFF/COUPLED source failure ledgers differ')
    full0=full_rows(parsed['OFF'])
    targets={(r['i'],r['j'],r['k']) for r in full0}
    stage_a=read_first_post(RUNS['OFF']/'run/pr85_joint_moment_stages.raw.gz',targets)
    stage_b=read_first_post(RUNS['COUPLED']/'run/pr85_joint_moment_stages.raw.gz',targets)
    out={'schema':'pr87_v15_rain_source_failure_numeric_audit_v1','kdm6_source_sha256':SOURCE_SHA,
      'source_emitter_module_em_pr85_sha256':EM_SOURCE_SHA,'build_receipt_sha256':BUILD_SHA,'scope':'closed V15 first failure only; no physics change; no promotion of incomplete 40-second run',
      'run_arms':'OFF and COUPLED each closed INCOMPLETE with returncode 1; ledger rows were byte-identical',
      'interpretation_limits':['The diagnosis is only for emitted p3 FULL failures at timestep 2/RK1.','Each recorded starting QR/NR is zero; ratios of source and air terms cancel the common positive dt/new-carrier factor.','Air rates in the failure record are widened REAL32 casts of REAL64 air_tendency outputs. The actual unrounded rates cannot be recovered from this ledger.','Independent cast-bin interval results are possibility bounds, not proof of the actual air_tendency pair.','No global kg totals or completed 40-second run claim.'],
      'receipts':{},'source_failure_ledgers':{},'first_post_stage':{},'arms':{},
      'parser_contract':{'list_directed_full_numeric_fields':20,'wrapped_physical_lines_joined_until_next_record_tag':True,
        'source_failure_full_records':131,'source_failure_other_source_records':582},
      'physical_mean_mass_ratio':'Q/N, native source contract kg per particle (dry-specific number); lower=PIDNR/lambda_max^power, upper=PIDNR/lambda_min^power'}
    for arm,run in RUNS.items():
        out['receipts'][arm]={'path':str(run/'receipt.json'),'sha256':sha256(run/'receipt.json'),
          'status':receipts[arm]['status'],'returncode':receipts[arm]['returncode'],
          'candidate_build_receipt_sha256':receipts[arm]['candidate_build']['receipt_sha256'],
          'candidate_executable_sha256':receipts[arm]['candidate_build']['executable_sha256']}
        out['source_failure_ledgers'][arm]={'path':parsed[arm]['path'],'compressed_sha256':parsed[arm]['sha256'],
          'bytes':parsed[arm]['bytes'],'source_count':parsed[arm]['totals'].get('SOURCE_FAILURE_COUNT'),
          'full_count':parsed[arm]['totals'].get('FULL_FAILURE_COUNT'),
          'parsed_full_count':sum(tag=='FULL' for tag,_ in parsed[arm]['rows'])}
        out['arms'][arm]=audit_arm(arm,parsed[arm],stage_a if arm=='OFF' else stage_b)
    out['first_post_stage']={arm:{'path':stage['path'],'compressed_sha256':stage['sha256'],'bytes':stage['bytes'],
        'post_kdm6_step1_records':stage['first_post_records'],'target_cell_count':len(targets),
        'matched_cell_count':len(stage['selected']),'missing_cells':stage['missing']}
        for arm,stage in (('OFF',stage_a),('COUPLED',stage_b))}
    out['first_post_stage']['off_coupled_hash_match']=stage_a['sha256']==stage_b['sha256']
    text=json.dumps(out,indent=2,sort_keys=True,allow_nan=False)
    if len(sys.argv)>1: pathlib.Path(sys.argv[1]).write_text(text+'\n')
    else: print(text)

if __name__=='__main__': main()
