from __future__ import annotations

import gzip
import hashlib
import sys
from pathlib import Path

import pytest

ROOT = Path(__file__).resolve().parents[1]
sys.path.insert(0, str(ROOT / "tools"))
from pr87_graupel_diffusion_probe import (  # noqa: E402
    V24C_EM_SHA256,
    extend_graupel_diffusion_probe,
)


FIXTURE = ROOT / "docs/evidence/pr87_two_step_v24c_20261016/module_em_pr85.F.gz"


def _source() -> str:
    source = gzip.decompress(FIXTURE.read_bytes()).decode("utf-8")
    assert hashlib.sha256(source.encode("utf-8")).hexdigest() == V24C_EM_SHA256
    return source


def test_probe_records_qg_and_qib_same_horizontal_stencil_without_changing_call():
    source = _source()
    call = "CALL horizontal_diffusion ( 'm', scalar(ims,kms,jms,im),            &"
    result = extend_graupel_diffusion_probe(source)

    assert result.count("'PR87_G_DIFFUSION_PRE'") == 1
    assert result.count("'PR87_G_DIFFUSION_POST'") == 1
    assert result.count("p_qnc, p_qib, tiedtkescheme") == 1
    assert result.count(call) == source.count(call) == 1
    assert result.index("'PR87_G_DIFFUSION_PRE'") < result.index(call)
    assert result.index(call) < result.index("'PR87_G_DIFFUSION_POST'")
    for tag in ("PRE", "POST"):
        tag_index = result.index(f"'PR87_G_DIFFUSION_{tag}'")
        block_start = result.rfind("IF (rk_step == 1", 0, tag_index)
        record = result[block_start:result.index("END IF", tag_index)]
        assert "(im == P_QG .OR. im == P_QIB)" in record
        assert "8, 205, 16" in record
        assert "scalar_tends(8,16,205,im)" in record
        assert "scalar(8,16,205,im)" in record
        assert "scalar(7,16,205,im)" in record
        assert "scalar(9,16,205,im)" in record
        assert "scalar(8,16,204,im)" in record
        assert "scalar(8,16,206,im)" in record


def test_probe_rejects_drifted_preimage():
    source = _source()
    with pytest.raises(ValueError, match="unexpected V24c module_em source"):
        extend_graupel_diffusion_probe(source.replace("scalar_loop : DO im = scs, sce",
                                                      "scalar_loop : DO im = scs + 1, sce"))
