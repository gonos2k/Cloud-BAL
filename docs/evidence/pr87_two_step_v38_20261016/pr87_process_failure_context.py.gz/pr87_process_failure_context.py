"""Add failure-only exact operand context to the V34 cold G search fatal."""

from __future__ import annotations

import hashlib


V34_KDM6_SHA256 = "2b10d9f15caa6c91a541428b19a6187bab7d75080e1ab67ae94b2435f7d928ce"
V36_KDM6_SHA256 = "4566a0c25cc20823a0fb07220ba0e646e3f3db6f42ffc954fc11924789de90c1"
V38_KDM6_SHA256 = "2a98262602d98b9288453ea0183e3ffe425c972779e012590317fc80ca11d73d"


def add_process_failure_context(source: str) -> str:
    """Print the actual cold G search operands immediately before its fatal."""
    actual_hash = hashlib.sha256(source.encode()).hexdigest()
    if actual_hash not in (V34_KDM6_SHA256, V36_KDM6_SHA256, V38_KDM6_SHA256):
        raise ValueError(f"unexpected KDM6 source hash: {actual_hash}")

    anchor = """            if (.not.rain_process_feasible) then
              if (.not.rain_bg_rates_feasible) then
"""
    diagnostic = """            if (.not.rain_process_feasible) then
              write(*,'(a,9(1x,i0))') 'PR87_GSEARCH_FAIL_META', &
                   pr87_model_timestep,lat,i,k,loop,n,rain_process_search_status, &
                   merge(1,0,rain_full_evap_pending(i,k)), &
                   merge(1,0,ice_full_sublimation_pending(i,k))
              write(*,'(a,26(1x,es26.17))') 'PR87_GSEARCH_FAIL_STATE', &
                   real(rain_q_fixed,8),real(rain_g_q_process,8), &
                   real(rain_n_fixed,8),real(rain_g_n_process,8), &
                   real(rain_bg_fixed,8),real(rain_g_bg_process,8), &
                   real(rain_t_fixed,8),real(rain_g_t_process,8), &
                   real(dry_carrier_density(i,k),8),real(pidnr,8),real(qmin,8), &
                   real(ncmin,8),real(qcrmin,8),real(dmr,8)
              write(*,'(a,16(1x,es26.17))') 'PR87_GSEARCH_FAIL_CONFIG', &
                   real(lamdarmin,8),real(lamdarmax,8),100.0_8,900.0_8, &
                   real(pidnc,8),real(dmc,8),real(lamdacmin,8),real(lamdacmax,8), &
                   real(pidni,8),real(dmi,8),real(lamdaimin,8),real(lamdaimax,8), &
                   real(rain_qv_stage,8),real(rain_g_qv_process,8), &
                   real(PR85_ICE_NATIVE_INACTIVE_MAX,8),real(rain_g_alpha,8)
              flush(6)
              if (.not.rain_bg_rates_feasible) then
"""
    if source.count(anchor) != 1:
        raise ValueError("expected one cold G process failure anchor")
    if "PR87_GSEARCH_FAIL_META" in source:
        raise ValueError("cold G process failure context already present")
    return source.replace(anchor, diagnostic, 1)
