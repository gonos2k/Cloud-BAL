# 초기 입자수·압력 전달 경계 그림 모음

현재 B1 유지 · DM065 미채택 · 새 6시간 성능 결과 없음.

## 초기 입자수와 RK 갱신

![초기 입자수와 RK 갱신](rk_mass_coupled_entry.png)

## 압력·Exner·기온의 실제 계산 경계

![압력·Exner·기온의 실제 계산 경계](phi_pressure_thermo_chain.png)

## 호출 영역의 입자수 차이 분포

![호출 영역의 입자수 차이 분포](native_nr_support.png)

## 초기 입력과 첫 진입 차이 집계

![초기 입력과 첫 진입 차이 집계](first_entry_counts.png)

## 첫 네 단계의 진입 차이

![첫 네 단계의 진입 차이](first_four_entry_frontier.png)
