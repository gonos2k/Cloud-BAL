"""Pin the selective REAL64 boundary repair to the frozen PR85 advection source."""

from __future__ import annotations

import hashlib


V42_MODULE_EM_SHA256 = "5eb415ca23119460ae3dd766d9acea0f4c99b96ad576100efb95c3bb4d402a6c"


def extend_graupel_cone_mixture(source: str) -> str:
    """Add a strict, source-certified mixture fallback for stored graupel pairs."""
    actual_hash = hashlib.sha256(source.encode()).hexdigest()
    if actual_hash != V42_MODULE_EM_SHA256:
        raise ValueError(f"unexpected pinned module_em source hash: {actual_hash}")

    import_anchor = "SUBROUTINE rk_update_joint_moments("
    import_end = "USE iso_fortran_env, ONLY: real32,real64"
    import_start = source.find(import_anchor)
    import_line = source.find(import_end, import_start)
    if import_start < 0 or import_line < 0:
        raise ValueError("missing pinned RK routine kind import")
    source = source[:import_line] + "USE iso_fortran_env, ONLY: int32,int64,real32,real64" + source[import_line + len(import_end):]

    call_anchor = """                         number_pair_bounds=number_bounds, &
                         strict_mass_pairs=[.FALSE.,.FALSE.,.FALSE.,.TRUE.])
  END SUBROUTINE evaluate_joint_candidate"""
    call_replacement = """                         number_pair_bounds=number_bounds, &
                         strict_mass_pairs=[.FALSE.,.FALSE.,.FALSE.,.TRUE.])
    IF (.NOT.feasible) CALL try_graupel_mixture_trial()
  END SUBROUTINE evaluate_joint_candidate

  SUBROUTINE try_graupel_mixture_trial()
    REAL(real32),ALLOCATABLE :: q_trial(:,:),n_trial(:,:)
    REAL(real64) :: trial_delta_q(4),trial_delta_n(4)
    INTEGER :: trial_adjustments(4),fallback_count,witness_i,witness_j,witness_k
    INTEGER(int32) :: witness_q32,witness_n32
    INTEGER(int64) :: witness_q64,witness_n64
    LOGICAL :: witness_canonical_valid,witness_stored_valid
    LOGICAL :: trial_feasible,valid
    ALLOCATE(q_trial(cells,4),n_trial(cells,4))
    q_trial=qc; n_trial=nc
    CALL joint_qnb_update(qb,nb,q_trial,n_trial,qs,ns,qa,na,oldcarrier,newcarrier,drydensity, &
                         dt,minmass,maxmass,theta,rejected_q,rejected_n,trial_feasible, &
                         joint_constrained_storage=.TRUE.,storage_delta_q=trial_delta_q, &
                         storage_delta_n=trial_delta_n,storage_adjustments=trial_adjustments, &
                         q_source_rate64=qs64,n_source_rate64=ns64, &
                         q_transport_rate64=qa64,n_transport_rate64=na64,joint_quantum_absence=.TRUE., &
                         number_pair_bounds=number_bounds, &
                         strict_mass_pairs=[.FALSE.,.FALSE.,.FALSE.,.FALSE.])
    IF (.NOT.trial_feasible) THEN
      feasible=.FALSE.; theta=0.0_real64; rejected_q=0.0_real64; rejected_n=0.0_real64
      DEALLOCATE(q_trial,n_trial); RETURN
    END IF
    IF (theta/=1.0_real64) THEN
      feasible=.FALSE.; theta=0.0_real64; rejected_q=0.0_real64; rejected_n=0.0_real64
      DEALLOCATE(q_trial,n_trial); RETURN
    END IF
    CALL certify_graupel_storage(q_trial,n_trial,trial_delta_q,trial_delta_n, &
                                 trial_adjustments,valid,fallback_count,witness_i,witness_j,witness_k, &
                                 witness_q64,witness_n64,witness_q32,witness_n32, &
                                 witness_canonical_valid,witness_stored_valid)
    IF (.NOT.valid) THEN
      feasible=.FALSE.; theta=0.0_real64; rejected_q=0.0_real64; rejected_n=0.0_real64
      DEALLOCATE(q_trial,n_trial); RETURN
    END IF
    qc=q_trial; nc=n_trial
    storage_delta_q=trial_delta_q; storage_delta_n=trial_delta_n
    storage_adjustments=trial_adjustments
    feasible=.TRUE.
    IF (fallback_count>0) WRITE(*,'(A,6(1X,I0),2(1X,Z16.16),2(1X,Z8.8),2(1X,L1))') &
      'PR87_GRAUPEL_MIXTURE',itimestep,rk,fallback_count,witness_i,witness_j,witness_k, &
      witness_q64,witness_n64,witness_q32,witness_n32,witness_canonical_valid,witness_stored_valid
    DEALLOCATE(q_trial,n_trial)
  END SUBROUTINE try_graupel_mixture_trial

  SUBROUTINE certify_graupel_storage(q_trial,n_trial,delta_q_by_pair,delta_n_by_pair, &
      adjustments_by_pair,valid,fallback_count,witness_i,witness_j,witness_k, &
      witness_q64,witness_n64,witness_q32,witness_n32,witness_canonical_valid,witness_stored_valid)
    REAL(real32),INTENT(INOUT) :: q_trial(cells,4),n_trial(cells,4)
    REAL(real64),INTENT(INOUT) :: delta_q_by_pair(4),delta_n_by_pair(4)
    INTEGER,INTENT(INOUT) :: adjustments_by_pair(4)
    INTEGER,INTENT(OUT) :: fallback_count,witness_i,witness_j,witness_k
    INTEGER(int32),INTENT(OUT) :: witness_q32,witness_n32
    INTEGER(int64),INTENT(OUT) :: witness_q64,witness_n64
    LOGICAL,INTENT(OUT) :: witness_canonical_valid,witness_stored_valid
    LOGICAL,INTENT(OUT) :: valid
    INTEGER :: c,i,k,j
    REAL(real64) :: reference_q,reference_n,delta_q,delta_n
    REAL(real64) :: weights(7)
    REAL(real32) :: q_terms(7),n_terms(7),stored_q,stored_n
    LOGICAL :: fallback_used,cell_valid
    LOGICAL :: canonical_valid,stored_valid
    delta_q_by_pair(4)=0.0_real64; delta_n_by_pair(4)=0.0_real64
    adjustments_by_pair(4)=0
    fallback_count=0; witness_i=0; witness_j=0; witness_k=0
    witness_q64=0_int64; witness_n64=0_int64; witness_q32=0_int32; witness_n32=0_int32
    witness_canonical_valid=.FALSE.; witness_stored_valid=.FALSE.
    valid=.FALSE.
    c=0
    DO j=jl,jh
      DO k=kl,kh
        DO i=il,ih
          c=c+1
          cell_valid=.FALSE.
          fallback_used=.FALSE.
          reference_q=(REAL(oldcarrier(c),real64)*REAL(qb(c,4),real64)+ &
              REAL(dt,real64)*(qs64(c,4)+qa64(c,4)))/REAL(newcarrier(c),real64)
          reference_n=(REAL(oldcarrier(c),real64)*REAL(nb(c,4),real64)+ &
              REAL(dt,real64)*(ns64(c,4)+na64(c,4)))/REAL(newcarrier(c),real64)
          canonical_valid=strict_graupel_pair(reference_q,reference_n,minmass(4),maxmass(4))
          stored_valid=strict_graupel_pair(REAL(q_trial(c,4),real64),REAL(n_trial(c,4),real64), &
                                           minmass(4),maxmass(4))
          IF (canonical_valid.AND.stored_valid) THEN
            ! Keep the common ledger convention for ordinary nearest-R32 stores.
            ! A fallback always records its full stored-minus-canonical residual.
            delta_q=0.0_real64; delta_n=0.0_real64
            IF (q_trial(c,4)/=REAL(reference_q,real32).OR. &
                n_trial(c,4)/=REAL(reference_n,real32)) THEN
              delta_q=REAL(newcarrier(c),real64)*(REAL(q_trial(c,4),real64)-reference_q)
              delta_n=REAL(newcarrier(c),real64)*(REAL(n_trial(c,4),real64)-reference_n)
            END IF
          ELSE
            IF (qs64(c,4)/=0.0_real64.OR.ns64(c,4)/=0.0_real64) THEN
              RETURN
            END IF
            CALL graupel_transport_mixture(c,i,k,j,weights,q_terms,n_terms,cell_valid)
            IF (.NOT.cell_valid) THEN
              RETURN
            END IF
          CALL store_graupel_mixture(weights,q_terms,n_terms,newcarrier(c),minmass(4), &
              maxmass(4),reference_q,reference_n,stored_q,stored_n,delta_q,delta_n,cell_valid)
          IF (.NOT.cell_valid) THEN
            RETURN
          END IF
          q_trial(c,4)=stored_q; n_trial(c,4)=stored_n
          fallback_used=.TRUE.
          fallback_count=fallback_count+1
          IF (fallback_count==1) THEN
            witness_i=i; witness_j=j; witness_k=k
            witness_q64=TRANSFER(reference_q,witness_q64)
            witness_n64=TRANSFER(reference_n,witness_n64)
            witness_q32=TRANSFER(stored_q,witness_q32)
            witness_n32=TRANSFER(stored_n,witness_n32)
            witness_canonical_valid=canonical_valid
            witness_stored_valid=stored_valid
          END IF
          END IF
          delta_q_by_pair(4)=delta_q_by_pair(4)+delta_q
          delta_n_by_pair(4)=delta_n_by_pair(4)+delta_n
          IF (fallback_used.OR.q_trial(c,4)/=REAL(reference_q,real32).OR. &
              n_trial(c,4)/=REAL(reference_n,real32)) &
            adjustments_by_pair(4)=adjustments_by_pair(4)+1
        END DO
      END DO
    END DO
    valid=.TRUE.
  END SUBROUTINE certify_graupel_storage

  SUBROUTINE graupel_transport_mixture(c,i,k,j,weights,q_terms,n_terms,valid)
    INTEGER,INTENT(IN) :: c,i,k,j
    REAL(real64),INTENT(OUT) :: weights(7)
    REAL(real32),INTENT(OUT) :: q_terms(7),n_terms(7)
    LOGICAL,INTENT(OUT) :: valid
    REAL(real64) :: xscale,yscale,zscale,outflow,edge,base_weight
    weights=0.0_real64; q_terms=0.0_real32; n_terms=0.0_real32; valid=.FALSE.
    xscale=REAL(msfty(i,j),real64)*REAL(msftx(i,j)*rdx,real64)
    yscale=REAL(msfty(i,j),real64)*REAL(msftx(i,j)*rdy,real64)
    zscale=REAL(msfty(i,j),real64)*REAL(-rdnw(k),real64)
    IF (.NOT.ALL(ieee_is_finite([xscale,yscale,zscale]))) RETURN
    IF (MIN(xscale,yscale,zscale)<0.0_real64) RETURN
    outflow=xscale*(MAX(REAL(ru(i+1,k,j),real64),0.0_real64)+ &
                    MAX(-REAL(ru(i,k,j),real64),0.0_real64))+ &
            yscale*(MAX(REAL(rv(i,k,j+1),real64),0.0_real64)+ &
                    MAX(-REAL(rv(i,k,j),real64),0.0_real64))
    IF (k>kl) outflow=outflow+zscale*MAX(REAL(ww(i,k,j),real64),0.0_real64)
    IF (k<kh) outflow=outflow+zscale*MAX(-REAL(ww(i,k+1,j),real64),0.0_real64)
    base_weight=REAL(oldcarrier(c),real64)-REAL(dt,real64)*outflow
    IF (.NOT.ieee_is_finite(base_weight).OR.base_weight<0.0_real64) RETURN
    weights(1)=base_weight
    q_terms(1)=q1(i,k,j,qindex(4)); n_terms(1)=n1(i,k,j,nindex(4))

    edge=REAL(ru(i+1,k,j),real64)
    IF (edge<0.0_real64) THEN
      weights(2)=REAL(dt,real64)*xscale*(-edge)
      q_terms(2)=q1(i+1,k,j,qindex(4)); n_terms(2)=n1(i+1,k,j,nindex(4))
    END IF
    edge=REAL(ru(i,k,j),real64)
    IF (edge>0.0_real64) THEN
      weights(3)=REAL(dt,real64)*xscale*edge
      q_terms(3)=q1(i-1,k,j,qindex(4)); n_terms(3)=n1(i-1,k,j,nindex(4))
    END IF
    edge=REAL(rv(i,k,j+1),real64)
    IF (edge<0.0_real64) THEN
      weights(4)=REAL(dt,real64)*yscale*(-edge)
      q_terms(4)=q1(i,k,j+1,qindex(4)); n_terms(4)=n1(i,k,j+1,nindex(4))
    END IF
    edge=REAL(rv(i,k,j),real64)
    IF (edge>0.0_real64) THEN
      weights(5)=REAL(dt,real64)*yscale*edge
      q_terms(5)=q1(i,k,j-1,qindex(4)); n_terms(5)=n1(i,k,j-1,nindex(4))
    END IF
    IF (k<kh) THEN
      edge=REAL(ww(i,k+1,j),real64)
      IF (edge>0.0_real64) THEN
        weights(6)=REAL(dt,real64)*zscale*edge
        q_terms(6)=q1(i,k+1,j,qindex(4)); n_terms(6)=n1(i,k+1,j,nindex(4))
      END IF
    END IF
    IF (k>kl) THEN
      edge=REAL(ww(i,k,j),real64)
      IF (edge<0.0_real64) THEN
        weights(7)=REAL(dt,real64)*zscale*(-edge)
        q_terms(7)=q1(i,k-1,j,qindex(4)); n_terms(7)=n1(i,k-1,j,nindex(4))
      END IF
    END IF
    IF (.NOT.ALL(ieee_is_finite(weights))) RETURN
    IF (ANY(weights<0.0_real64)) RETURN
    valid=.TRUE.
  END SUBROUTINE graupel_transport_mixture

  PURE LOGICAL FUNCTION strict_graupel_pair(q,n,minimum_ratio,maximum_ratio)
    REAL(real64),INTENT(IN) :: q,n,minimum_ratio,maximum_ratio
    INTEGER,PARAMETER :: real128=SELECTED_REAL_KIND(33,4931)
    REAL(real128) :: q128,n128
    strict_graupel_pair=.FALSE.
    IF (.NOT.ALL(ieee_is_finite([q,n,minimum_ratio,maximum_ratio]))) RETURN
    IF (q<0.0_real64.OR.n<0.0_real64.OR.minimum_ratio<=0.0_real64.OR. &
        maximum_ratio<minimum_ratio) RETURN
    IF (q==0.0_real64.AND.n==0.0_real64) THEN
      strict_graupel_pair=.TRUE.; RETURN
    END IF
    IF (q<=0.0_real64.OR.n<=0.0_real64) RETURN
    q128=REAL(q,real128); n128=REAL(n,real128)
    strict_graupel_pair=q128>=REAL(minimum_ratio,real128)*n128.AND. &
                        q128<=REAL(maximum_ratio,real128)*n128
  END FUNCTION strict_graupel_pair

  SUBROUTINE store_graupel_mixture(weights,q_terms,n_terms,denominator,minimum_ratio, &
      maximum_ratio,reference_q,reference_n,stored_q,stored_n,delta_q,delta_n,valid)
    REAL(real64),INTENT(IN) :: weights(7),minimum_ratio,maximum_ratio,reference_q,reference_n
    REAL(real32),INTENT(IN) :: q_terms(7),n_terms(7),denominator
    REAL(real32),INTENT(OUT) :: stored_q,stored_n
    REAL(real64),INTENT(OUT) :: delta_q,delta_n
    LOGICAL,INTENT(OUT) :: valid
    INTEGER,PARAMETER :: real128=SELECTED_REAL_KIND(33,4931)
    REAL(real128) :: qsum,nsum,qvalue,nvalue,qcheck,ncheck
    INTEGER :: term,attempt
    stored_q=-1.0_real32; stored_n=-1.0_real32
    delta_q=0.0_real64; delta_n=0.0_real64; valid=.FALSE.
    IF (.NOT.ALL(ieee_is_finite(weights))) RETURN
    IF (ANY(weights<0.0_real64)) RETURN
    IF (.NOT.ALL(ieee_is_finite(q_terms))) RETURN
    IF (.NOT.ALL(ieee_is_finite(n_terms))) RETURN
    IF (.NOT.ieee_is_finite(denominator)) RETURN
    IF (denominator<=0.0_real32) RETURN
    IF (.NOT.ieee_is_finite(reference_q).OR..NOT.ieee_is_finite(reference_n)) RETURN
    qsum=0.0_real128; nsum=0.0_real128
    DO term=1,7
      IF (weights(term)==0.0_real64) CYCLE
      IF (.NOT.strict_graupel_pair(REAL(q_terms(term),real64),REAL(n_terms(term),real64), &
                                   minimum_ratio,maximum_ratio)) RETURN
      qsum=qsum+REAL(weights(term),real128)*REAL(q_terms(term),real128)
      nsum=nsum+REAL(weights(term),real128)*REAL(n_terms(term),real128)
    END DO
    qvalue=qsum/REAL(denominator,real128); nvalue=nsum/REAL(denominator,real128)
    IF (.NOT.ieee_is_finite(qvalue).OR..NOT.ieee_is_finite(nvalue)) RETURN
    IF (qvalue>REAL(HUGE(0.0_real32),real128).OR.nvalue>REAL(HUGE(0.0_real32),real128)) RETURN
    stored_q=REAL(qvalue,real32); stored_n=REAL(nvalue,real32)
    IF (.NOT.ieee_is_finite(stored_q).OR..NOT.ieee_is_finite(stored_n)) RETURN
    DO attempt=1,4
      IF (strict_graupel_pair(REAL(stored_q,real64),REAL(stored_n,real64), &
                              minimum_ratio,maximum_ratio)) EXIT
      qcheck=REAL(stored_q,real128); ncheck=REAL(stored_n,real128)
      IF (stored_q<=0.0_real32.OR.stored_n<=0.0_real32) RETURN
      IF (qcheck<REAL(minimum_ratio,real128)*ncheck) THEN
        stored_q=NEAREST(stored_q,1.0_real32)
      ELSE IF (qcheck>REAL(maximum_ratio,real128)*ncheck) THEN
        stored_q=NEAREST(stored_q,-1.0_real32)
      ELSE
        RETURN
      END IF
    END DO
    IF (.NOT.strict_graupel_pair(REAL(stored_q,real64),REAL(stored_n,real64), &
                                 minimum_ratio,maximum_ratio)) RETURN
    delta_q=REAL(denominator,real64)*(REAL(stored_q,real64)-reference_q)
    delta_n=REAL(denominator,real64)*(REAL(stored_n,real64)-reference_n)
    IF (.NOT.ALL(ieee_is_finite([delta_q,delta_n]))) RETURN
    valid=.TRUE.
  END SUBROUTINE store_graupel_mixture"""

    if source.count(call_anchor) != 1:
        raise ValueError("expected one joint candidate call anchor")
    source = source.replace(call_anchor, call_replacement, 1)
    return source
