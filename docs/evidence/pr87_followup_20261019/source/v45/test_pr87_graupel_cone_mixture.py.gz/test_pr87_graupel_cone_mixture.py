from __future__ import annotations

import hashlib
import gzip
from pathlib import Path
import re
import subprocess
import tempfile

import pytest

ROOT = Path(__file__).resolve().parents[1]
SOURCE = ROOT / "docs/evidence/pr87_two_step_v42_20261016/module_em_pr85.F.gz"
JOINT_SOURCE = ROOT / "docs/evidence/pr87_two_step_v42_20261016/cloud_bal_joint_transport.f90.gz"
TOOLCHAIN = ROOT / "tests/intel_toolchain.sh"

import sys
sys.path.insert(0, str(ROOT / "tools"))
from pr87_graupel_cone_mixture import (  # noqa: E402
    V42_MODULE_EM_SHA256,
    extend_graupel_cone_mixture,
)


def _routine(source: str, name: str) -> str:
    start = re.search(
        rf"^\s*(?:pure\s+)?(?:logical\s+)?(?:subroutine|function)\s+{name}\s*\(",
        source, re.I | re.M,
    )
    assert start, f"missing {name}"
    end = re.search(
        rf"^\s*end\s+(?:subroutine|function)\s+{name}\s*$",
        source[start.end():], re.I | re.M,
    )
    assert end, f"missing end of {name}"
    return source[start.start():start.end() + end.end()]


def _fixture(source: str) -> str:
    strict = _routine(source, "strict_graupel_pair")
    store = _routine(source, "store_graupel_mixture")
    return f"""module mixture_fixture
  use iso_fortran_env, only: int32,real32,real64
  use, intrinsic :: ieee_arithmetic, only: ieee_is_finite
  implicit none
contains
{strict}
{store}
end module mixture_fixture

program test_graupel_mixture
  use iso_fortran_env, only: int32,real32,real64
  use mixture_fixture
  implicit none
  real(real64) :: weights(7),dq,dn
  real(real32) :: qterms(7),nterms(7),stored_q,stored_n,donor_q,donor_n
  real(real64) :: reference_q,reference_n
  logical :: valid
  donor_q=transfer(int(z'398DD8E4',int32),0.0_real32)
  donor_n=transfer(int(z'34A16400',int32),0.0_real32)
  if (.not.strict_graupel_pair(real(donor_q,real64),real(donor_n,real64),100.0_real64,900.0_real64)) &
    error stop 'exact upper-bound donor rejected'
  reference_q=3.456802809170887e-6_real64
  reference_n=3.840892010189874e-9_real64
  if (strict_graupel_pair(reference_q,reference_n,100.0_real64,900.0_real64)) &
    error stop 'printed canonical candidate did not expose boundary roundoff'
  weights=0.0_real64; qterms=0.0_real32; nterms=0.0_real32
  weights(7)=10.0_real64*3.032055185624720e-2_real64/real(donor_q,real64)
  qterms(7)=donor_q; nterms(7)=donor_n
  call store_graupel_mixture(weights,qterms,nterms,87712.70_real32,100.0_real64,900.0_real64, &
       reference_q,reference_n,stored_q,stored_n,dq,dn,valid)
  if (.not.valid) error stop 'valid upper-bound donor mixture rejected'
  if (.not.strict_graupel_pair(real(stored_q,real64),real(stored_n,real64), &
                               100.0_real64,900.0_real64)) error stop 'stored pair is outside strict cone'
  if (.not.ieee_is_finite(dq).or..not.ieee_is_finite(dn)) error stop 'storage residual nonfinite'

  ! Invalid positive-weight donor and negative weight both veto the fallback.
  qterms(7)=nearest(donor_q,1.0_real32)
  call store_graupel_mixture(weights,qterms,nterms,87712.70_real32,100.0_real64,900.0_real64, &
       reference_q,reference_n,stored_q,stored_n,dq,dn,valid)
  if (valid) error stop 'out-of-cone donor accepted'
  qterms(7)=donor_q; weights(7)=-weights(7)
  call store_graupel_mixture(weights,qterms,nterms,87712.70_real32,100.0_real64,900.0_real64, &
       reference_q,reference_n,stored_q,stored_n,dq,dn,valid)
  if (valid) error stop 'negative mixture weight accepted'

  ! Nonzero source is rejected by the transactional caller certificate.
  print '(a)', 'PR87 strict graupel mixture helper PASS'
end program test_graupel_mixture
"""


def _transaction_fixture(source: str, joint_source: str) -> str:
    routines = "\n".join(
        _routine(source, name)
        for name in (
            "try_graupel_mixture_trial",
            "certify_graupel_storage",
            "graupel_transport_mixture",
            "strict_graupel_pair",
            "store_graupel_mixture",
        )
    )
    return f"""{joint_source}
module mixture_host
  use iso_fortran_env, only: int32,int64,real32,real64
  use, intrinsic :: ieee_arithmetic, only: ieee_is_finite
  use cloud_bal_joint_transport, only: joint_qnb_update
  implicit none
  integer,parameter :: cells=2
  integer :: itimestep=1,rk=2
  integer :: il=1,ih=2,jl=1,jh=1,kl=1,kh=1
  integer :: qindex(4)=[1,2,3,4],nindex(4)=[1,2,3,4]
  real(real32) :: qb(cells,4),nb(cells,4),qc(cells,4),nc(cells,4)
  real(real32) :: qs(cells,4),ns(cells,4),qa(cells,4),na(cells,4)
  real(real32) :: oldcarrier(cells),newcarrier(cells),drydensity(cells),dt
  real(real64) :: minmass(4),maxmass(4),theta,rejected_q(4),rejected_n(4)
  real(real64) :: qs64(cells,4),ns64(cells,4),qa64(cells,4),na64(cells,4)
  real(real64) :: number_bounds(cells,2,4),storage_delta_q(4),storage_delta_n(4)
  integer :: storage_adjustments(4)
  real(real32) :: q1(0:3,0:1,0:2,8),n1(0:3,0:1,0:2,8)
  real(real32) :: ru(0:3,0:1,0:2),rv(0:3,0:1,0:2),ww(0:3,0:1,0:2)
  real(real32) :: msftx(0:3,0:2),msfty(0:3,0:2),rdnw(0:1)
  real(real64) :: rdx=1.0_real64,rdy=1.0_real64
  logical :: feasible
contains
{routines}
  subroutine reset_case()
    real(real32) :: donor_q,donor_n
    qb=0.0_real32; nb=0.0_real32; qc=0.0_real32; nc=0.0_real32
    qs=0.0_real32; ns=0.0_real32; qa=0.0_real32; na=0.0_real32
    qs64=0.0_real64; ns64=0.0_real64; qa64=0.0_real64; na64=0.0_real64
    number_bounds=0.0_real64; storage_delta_q=0.0_real64; storage_delta_n=0.0_real64
    storage_adjustments=0; q1=0.0_real32; n1=0.0_real32
    ru=0.0_real32; rv=0.0_real32; ww=0.0_real32
    msftx=1.0_real32; msfty=1.0_real32; rdnw=-1.0_real32
    oldcarrier=[86592.0_real32,87712.70_real32]
    newcarrier=[87712.70_real32,86592.0_real32]
    drydensity=1.0_real32; dt=10.0_real32
    minmass=[1.0e-20_real64,1.0e-20_real64,1.0e-20_real64,100.0_real64]
    maxmass=[1.0e-10_real64,1.0e-10_real64,1.0e-10_real64,900.0_real64]
    donor_q=transfer(int(z'398DD8E4',int32),0.0_real32)
    donor_n=transfer(int(z'34A16400',int32),0.0_real32)
    qb(2,4)=donor_q; nb(2,4)=donor_n
    q1(2,1,1,4)=donor_q; n1(2,1,1,4)=donor_n
    ru(2,1,1)=-112.07_real32
    qa64(1,4)=3.032055185624720e-2_real64
    na64(1,4)=3.368950206249689e-5_real64
    qa(1,4)=real(qa64(1,4),real32); na(1,4)=real(na64(1,4),real32)
    theta=0.0_real64; rejected_q=0.0_real64; rejected_n=0.0_real64; feasible=.false.
  end subroutine reset_case
end module mixture_host

program test_graupel_transaction
  use iso_fortran_env, only: real32,real64
  use mixture_host
  implicit none
  real(real32) :: old_q(cells,4),old_n(cells,4)
  real(real64) :: old_dq(4),old_dn(4)
  integer :: old_adjust(4)
  call reset_case()
  call try_graupel_mixture_trial()
  if (.not.feasible) error stop 'valid boundary mixture transaction rejected'
  if (theta/=1.0_real64) error stop 'accepted mixture did not retain theta one'
  if (.not.strict_graupel_pair(real(qc(1,4),real64),real(nc(1,4),real64),100.0_real64,900.0_real64)) &
    error stop 'accepted receiver pair is outside strict cone'

  ! A later invalid source must roll back an earlier cell's local repair.
  call reset_case()
  qs64(2,4)=1.0e-8_real64
  qs(2,4)=real(qs64(2,4),real32)
  old_q=qc; old_n=nc; old_dq=storage_delta_q; old_dn=storage_delta_n; old_adjust=storage_adjustments
  call try_graupel_mixture_trial()
  if (feasible) error stop 'nonzero-source cone violation accepted'
  if (any(qc/=old_q).or.any(nc/=old_n)) error stop 'failed transaction changed stored moments'
  if (any(storage_delta_q/=old_dq).or.any(storage_delta_n/=old_dn).or. &
      any(storage_adjustments/=old_adjust)) error stop 'failed transaction changed storage ledger'

  ! An infeasible retry cannot change stored moments or expose a theta.
  call reset_case()
  qa64(1,4)=1.0_real64; qa(1,4)=1.0_real32; na64(1,4)=0.0_real64; na(1,4)=0.0_real32
  old_q=qc; old_n=nc
  call try_graupel_mixture_trial()
  if (feasible) error stop 'infeasible theta transaction accepted'
  if (theta/=0.0_real64) error stop 'failed transaction left nonzero theta'
  if (any(qc/=old_q).or.any(nc/=old_n)) error stop 'infeasible trial changed stored moments'
  print '(a)', 'PR87 graupel transaction PASS'
end program test_graupel_transaction
"""


def test_pinned_transform_preserves_strict_primary_kernel_and_requires_witness():
    original = gzip.decompress(SOURCE.read_bytes()).decode()
    assert hashlib.sha256(original.encode()).hexdigest() == V42_MODULE_EM_SHA256
    transformed = extend_graupel_cone_mixture(original)
    assert "strict_mass_pairs=[.FALSE.,.FALSE.,.FALSE.,.TRUE.]" in transformed
    assert "strict_mass_pairs=[.FALSE.,.FALSE.,.FALSE.,.FALSE.]" in transformed
    assert "IF (qs64(c,4)/=0.0_real64.OR.ns64(c,4)/=0.0_real64) THEN" in transformed
    assert "IF (theta/=1.0_real64) THEN" in transformed
    assert "n_terms(7)=q1" not in transformed
    assert "n_terms(7)=n1(i,k-1,j,nindex(4))" in transformed
    assert "storage_delta_q(4)=storage_delta_q(4)+delta_q" not in transformed
    with pytest.raises(ValueError, match="unexpected pinned module_em source hash"):
        extend_graupel_cone_mixture(original + "\n")


@pytest.mark.parametrize("optimization", ["O0", "O2"])
def test_boundary_mixture_store_with_pinned_intel(optimization: str):
    transformed = extend_graupel_cone_mixture(gzip.decompress(SOURCE.read_bytes()).decode())
    fixture = _fixture(transformed)
    with tempfile.TemporaryDirectory(prefix=f"pr87_mixture_{optimization}_", dir="/var/tmp") as tmp:
        scratch = Path(tmp)
        source_path = scratch / "test_graupel_mixture.F90"
        executable = scratch / "test_graupel_mixture.exe"
        source_path.write_text(fixture)
        script = f"""
set -euo pipefail
source '{TOOLCHAIN}'
if [[ '{optimization}' == O0 ]]; then flags=("${{CLOUD_BAL_FREE_FLAGS[@]}}"); else flags=("${{CLOUD_BAL_REPRO_FLAGS[@]}}"); fi
"$CLOUD_BAL_FC" -free "${{flags[@]}}" '{source_path}' -o '{executable}'
'{executable}'
"""
        result = subprocess.run(["bash", "-lc", script], cwd=scratch, text=True,
                                stdout=subprocess.PIPE, stderr=subprocess.STDOUT, check=False)
        assert result.returncode == 0, result.stdout
        assert "PR87 strict graupel mixture helper PASS" in result.stdout


@pytest.mark.parametrize("optimization", ["O0", "O2"])
def test_source_certified_transaction_with_pinned_intel(optimization: str):
    transformed = extend_graupel_cone_mixture(gzip.decompress(SOURCE.read_bytes()).decode())
    joint_source = gzip.decompress(JOINT_SOURCE.read_bytes()).decode()
    fixture = _transaction_fixture(transformed, joint_source)
    with tempfile.TemporaryDirectory(prefix=f"pr87_transaction_{optimization}_", dir="/var/tmp") as tmp:
        scratch = Path(tmp)
        source_path = scratch / "test_graupel_transaction.F90"
        executable = scratch / "test_graupel_transaction.exe"
        source_path.write_text(fixture)
        script = f"""
set -euo pipefail
source '{TOOLCHAIN}'
if [[ '{optimization}' == O0 ]]; then flags=("${{CLOUD_BAL_FREE_FLAGS[@]}}"); else flags=("${{CLOUD_BAL_REPRO_FLAGS[@]}}"); fi
"$CLOUD_BAL_FC" -free "${{flags[@]}}" '{source_path}' -o '{executable}'
'{executable}'
"""
        result = subprocess.run(["bash", "-lc", script], cwd=scratch, text=True,
                                stdout=subprocess.PIPE, stderr=subprocess.STDOUT, check=False)
        assert result.returncode == 0, result.stdout
        assert "PR87 graupel transaction PASS" in result.stdout
        witness = re.search(
            r"PR87_GRAUPEL_MIXTURE\s+1\s+2\s+1\s+1\s+1\s+1\s+"
            r"[0-9A-F]{16}\s+[0-9A-F]{16}\s+[0-9A-F]{8}\s+[0-9A-F]{8}\s+F\s+F",
            result.stdout,
        )
        assert witness, result.stdout
