from pathlib import Path
from decimal import Decimal, localcontext
import hashlib,json,math
import numpy as np
from netCDF4 import Dataset
source=Path('/var/tmp/pr82_same13_real_boundary_candidate.final2_20261012/wrfinput_d01')
sha=lambda p:hashlib.sha256(Path(p).read_bytes()).hexdigest()
before=sha(source)
assert before=='dce4a2633521639a4195babc461a45427f669dc808cb7b2d99d321b153b77afb'
with Dataset(source) as ds:
 for name in ('QICE','AL','ALB'):
  assert not np.ma.getmaskarray(ds[name][:]).any()
 qi=np.asarray(ds['QICE'][0],dtype=np.float64)
 alt=np.add(np.asarray(ds['AL'][0]),np.asarray(ds['ALB'][0]),dtype=np.float32)
 rho=np.divide(np.float32(1),alt,dtype=np.float32)
assert np.isfinite(qi).all() and np.isfinite(rho).all() and (rho>0).all()
# Necessary inequality from the declared source PSD envelope, independent of initializer.
mean_max=(math.pi*500/6*math.gamma(4))/(9080**3)
minimum=qi*rho.astype(np.float64)/mean_max
bad=(qi>0)&(minimum>1e6)
active=(slice(None),slice(1,-1),slice(1,-1))
locations=np.argwhere(bad[active]);first=locations[0]+np.array([0,1,1])
maximum=np.unravel_index(np.argmax(minimum[active]),minimum[active].shape)
maximum=np.array(maximum)+np.array([0,1,1])
def record(index):
 k,j,i=map(int,index)
 with localcontext() as ctx:
  ctx.prec=80
  pi=Decimal('3.14159265358979323846264338327950288419716939937510582097494459230781640628620899')
  exact=Decimal.from_float(float(qi[k,j,i]))*Decimal.from_float(float(rho[k,j,i]))*Decimal(9080)**3/(pi*Decimal(500))
 return {'wrf_ijk_one_based':[i+1,j+1,k+1],'qice_kg_kg_dry':float(qi[k,j,i]),'dry_density_kg_m3':float(rho[k,j,i]),'minimum_internal_number_m3':float(minimum[k,j,i]),'independent_80decimal_source_formula':str(exact)}
assert sha(source)==before
r={'schema':'pr83_independent_ice_cap_necessity_v1','source':str(source),'source_sha256_before':before,'source_sha256_after':sha(source),'density_operation':'real32 AL+ALB followed by real32 reciprocal','derivation':'n_v >= rho_d*r_i*lambda_min^3/pidni; feasible only if this lower bound <= cap','declared_lambda_min_m1':9080,'declared_internal_cap_m3':1e6,'declared_maximum_mean_mass_kg':mean_max,'full_array_infeasible_cells':int(bad.sum()),'active_interior_infeasible_cells':int(bad[active].sum()),'first_active_infeasible_cell':record(first),'maximum_active_minimum_cell':record(maximum),'scope':'actual NetCDF state and independent algebra of the declared source envelope; no initializer import, native Fortran coefficient-bit or model execution claim','science_assessed':False,'no_mass_or_moment_modified':True}
out=Path('/var/tmp/pr83_independent_ice_cap_20261013.json')
with out.open('x') as f:json.dump(r,f,indent=2,sort_keys=True,allow_nan=False);f.write('\n')
print(out)
