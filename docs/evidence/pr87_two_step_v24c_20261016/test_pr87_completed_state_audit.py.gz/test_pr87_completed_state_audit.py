from __future__ import annotations

import gzip
import struct
import sys
import tempfile
import unittest
from pathlib import Path

import numpy as np

ROOT = Path(__file__).resolve().parents[1]
sys.path.insert(0, str(ROOT / "tools"))
import pr87_completed_state_audit as audit_module
from pr85_joint_stage_trace import STATE_FIELDS


def state_record(stage: str, timestep: int, rkstep: int, negative_q: bool = False) -> bytes:
    header = struct.pack(
        ">15i", 1, timestep, rkstep,
        1, 1, 1, 1, 1, 1,
        1, 1, 1, 1, 1, 1,
    )
    fields = []
    for name in STATE_FIELDS:
        value = 1.0 if name == "DEN" else -1.0 if name == "Q" and negative_q else 0.0
        values = np.array([value], dtype=">f4")
        fields.append(values.tobytes())
    return b"PR85QND2" + stage.encode("ascii").ljust(32) + header + b"".join(fields)


def timestep_records(timestep: int, second_rkstep: int = 2) -> bytes:
    stages = (("PRE_RK", 0), ("RK_STAGE_END", 1), ("RK_STAGE_END", second_rkstep),
              ("RK_STAGE_END", 3), ("PRE_KDM6", 0), ("POST_KDM6", 0))
    return b"".join(state_record(stage, timestep, rkstep) for stage, rkstep in stages)


class CompletedStateAuditTests(unittest.TestCase):
    def test_passes_repeated_complete_sequences(self) -> None:
        with tempfile.TemporaryDirectory() as directory:
            path = Path(directory) / "two_steps.raw.gz"
            with gzip.open(path, "wb") as stream:
                stream.write(timestep_records(1))
                stream.write(timestep_records(2))
            report = audit_module.audit(path)

        self.assertEqual(report["status"], "PASS")
        self.assertEqual(report["trace_timesteps"], [1, 2])
        self.assertTrue(report["timestep_ids_contiguous_from_one"])
        self.assertEqual(report["completed_post_kdm6_timestep_count"], 2)
        self.assertEqual([row["state_record_count"] for row in report["timestep_audits"]], [6, 6])

    def test_audits_each_completed_timestep_and_marks_partial_tail(self) -> None:
        with tempfile.TemporaryDirectory() as directory:
            path = Path(directory) / "stages.raw.gz"
            with gzip.open(path, "wb") as stream:
                stream.write(timestep_records(1))
                stream.write(state_record("PRE_RK", 2, 0, negative_q=True))
                stream.write(state_record("RK_STAGE_END", 2, 1))
            report = audit_module.audit(path)

        self.assertEqual(report["status"], "INCOMPLETE")
        self.assertEqual(report["trace_timestep_count"], 2)
        self.assertEqual(report["completed_post_kdm6_timestep_count"], 1)
        self.assertEqual(report["state_record_count"], 8)
        first, partial = report["timestep_audits"]
        self.assertEqual(first["status"], "PASS")
        self.assertEqual(first["state_stage_sequence"], list(audit_module.STATE_SEQUENCE))
        self.assertTrue(first["density_contract_verified"])
        self.assertEqual(partial["status"], "INCOMPLETE")
        self.assertEqual(partial["state_record_count"], 2)
        self.assertEqual(partial["first_recorded_state_violation"]["stage"], "PRE_RK")
        self.assertEqual(partial["first_recorded_state_violation"]["fields"]["Q"]["negative"], 1)
        self.assertTrue(all(not stage["violations"][key]
                            for stage in first["completed_state_summaries"]
                            for key in ("fields", "pairs", "number_conversion")))

    def test_rejects_malformed_rkstep_sequence_even_when_stage_names_match(self) -> None:
        with tempfile.TemporaryDirectory() as directory:
            path = Path(directory) / "malformed.raw"
            path.write_bytes(timestep_records(1, second_rkstep=3))
            report = audit_module.audit(path)

        timestep = report["timestep_audits"][0]
        self.assertEqual(report["status"], "INCOMPLETE")
        self.assertTrue(timestep["required_state_sequence_complete"])
        self.assertFalse(timestep["required_rkstep_sequence_complete"])
        self.assertTrue(timestep["observed_post_kdm6"])
        self.assertFalse(timestep["completed_post_kdm6"])
        self.assertEqual(report["completed_post_kdm6_timestep_count"], 0)

    def test_requires_contiguous_timestep_ids_from_one(self) -> None:
        with tempfile.TemporaryDirectory() as directory:
            path = Path(directory) / "gap.raw"
            path.write_bytes(timestep_records(1) + timestep_records(3))
            report = audit_module.audit(path)

        self.assertEqual(report["trace_timesteps"], [1, 3])
        self.assertFalse(report["timestep_ids_contiguous_from_one"])
        self.assertEqual(report["status"], "INCOMPLETE")


if __name__ == "__main__":
    unittest.main()
