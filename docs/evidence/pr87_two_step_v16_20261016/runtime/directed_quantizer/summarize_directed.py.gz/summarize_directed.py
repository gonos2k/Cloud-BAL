import hashlib
import json
import math
import pathlib
import struct

ROOT = pathlib.Path('/NHNHOME/WORKSPACE/26weather002_A/yhlee/KLAPS50/scratch/pr87_two_step_20261016/Cloud-BAL')
EVDIR = ROOT / 'docs/evidence/pr87_two_step_v16_20261016/runtime'
OUTDIR = EVDIR / 'directed_quantizer'
AUDIT = EVDIR / 'quantizer_limiter/audit.json'
CALLER = pathlib.Path('/var/tmp/pr87_v16_quantizer_probe/probe.f90')
SOURCE = pathlib.Path('/var/tmp/pr87_v16_quantizer_probe/directed_final_O0/cloud_bal_joint_transport.f90')
O0 = pathlib.Path('/var/tmp/pr87_v16_quantizer_probe/directed_final_O0')
O2 = pathlib.Path('/var/tmp/pr87_v16_quantizer_probe/directed_final_O2')

def sha(path): return hashlib.sha256(path.read_bytes()).hexdigest()
def f32(v): return struct.unpack('>f', struct.pack('>f', v))[0]
def next32(v, direction):
    bits = struct.unpack('>I', struct.pack('>f', v))[0]
    if v == 0.0: return struct.unpack('>f', struct.pack('>I', 1 if direction > 0 else 0x80000001))[0]
    if (v > 0) == (direction > 0): bits += 1
    else: bits -= 1
    return struct.unpack('>f', struct.pack('>I', bits))[0]
def ulp32(v): return abs(next32(f32(v), 1)-f32(v))
def close(a,b): return a == b

audit=json.loads(AUDIT.read_text())
rows=[line.split() for line in (O0/'run.txt').read_text().splitlines()]
raw_rows=[r for r in rows if r and r[0].isdigit()]
neighbor_rows=[r for r in rows if r and r[0]=='NEIGHBORS']
directed_rows=[r for r in rows if r and r[0]=='DIRECTED']
controls=[r for r in rows if r and r[0].startswith('CONTROL_')]
assert len(raw_rows)==8 and len(neighbor_rows)==8 and len(directed_rows)==8
assert len(controls)==2
min_ratio=float(audit['native_coefficients']['lower_specific_mass_q_over_n'])
max_ratio=float(audit['native_coefficients']['upper_specific_mass_q_over_n'])
result=[]
for i,(base,near,drow,old) in enumerate(zip(raw_rows,neighbor_rows,directed_rows,audit['rows'])):
    idx=int(base[0]); assert idx==i+1 and int(drow[1])==idx
    ijk=old['cell_ijk']; c=old['continuous_candidate_reconstructed_from_rates']
    rho=float(old['dry_density_real32_from_PRE_RK']['decimal'])
    q64=float(c['q64']); n64=float(c['n64']); q0=float(base[14]); n0=float(base[15])
    q1up=float(near[1]); q1dn=float(near[2]); q2up=float(near[3]); q2dn=float(near[4])
    qsel=float(drow[6]); nsel=float(drow[7])
    vol64=n0*rho; vol32=f32(vol64)
    bounds=[rho*961.0**3/12566.37109375,rho*35000.0**3/12566.37109375]
    lo=max(max(vol64,vol32)/bounds[1],n0*min_ratio)
    hi=min(min(vol64,vol32)/bounds[0],n0*max_ratio)
    exact_vol=vol64>=bounds[0]*qsel and vol64<=bounds[1]*qsel and vol32>=bounds[0]*qsel and vol32<=bounds[1]*qsel
    exact_mass=min_ratio<=qsel/n0<=max_ratio
    assert lo<=qsel<=hi and exact_vol and exact_mass and nsel==n0
    assert drow[2]=='T' and int(drow[3])==0
    result.append({
      'cell_ijk':ijk,'rho_r32':rho,'q64':q64,'n64':n64,
      'q_r32_ordinary':q0,'n_r32_ordinary':n0,
      'q_r32_one_up':q1up,'q_r32_one_down':q1dn,
      'q_r32_two_up':q2up,'q_r32_two_down':q2dn,
      'ordinary_valid':base[7]=='T','one_up_valid':base[8]=='T','one_down_valid':base[9]=='T',
      'two_up_valid':base[10]=='T','two_down_valid':base[11]=='T',
      'directed_q_r32':qsel,'directed_n_r32':nsel,'directed_adjustment':int(drow[3]),
      'directed_store_valid':True,'selected_is_plus_two_neighbor':qsel==q2up,
      'q_signed_delta_from_q64':qsel-q64,'q_signed_delta_in_r32_ulps':(qsel-q64)/ulp32(q64),
      'n_signed_delta_from_n64':nsel-n64,
      'strict_q_interval_from_dual_volume_products_and_specific_mass':[lo,hi],
      'selected_q_inside_interval':lo<=qsel<=hi,
      'dual_r32_r64_volume_products_strictly_valid':exact_vol,
      'exact_specific_mass_bounds_valid':exact_mass
    })
assert all(r['selected_is_plus_two_neighbor'] and r['directed_store_valid'] for r in result)
assert all(r['dual_r32_r64_volume_products_strictly_valid'] and r['exact_specific_mass_bounds_valid'] for r in result)
assert all(not r['ordinary_valid'] and not r['one_up_valid'] and not r['one_down_valid'] and not r['two_down_valid'] for r in result)
assert all(r['two_up_valid'] for r in result)
control_result=[]
for row in controls:
    name=row[0]; direct_valid=row[2]=='T'; adjustment=int(row[3]); q=float(row[4]); n=float(row[5])
    base_valid=row[1]=='T'
    assert base_valid and direct_valid and adjustment==0
    control_result.append({'control':name,'original_store_valid':base_valid,'directed_store_valid':direct_valid,'adjustment':adjustment,'q':q,'n':n,'unchanged':True})

out={
 'schema':'pr87_v16_directed_q_quantizer_isolated_probe_v1',
 'scope':'Isolated exact-module caller only; no production kernel/source edits and no native rerun.',
 'algorithm':'After original store rejects, hold ordinary R32 N fixed. Form feasible Q interval from both R64 and R32 products N*rho plus strict specific-mass bounds; clamp q64, round to R32 and direct at most one neighbor into interval. If unchanged store validator still rejects due endpoint arithmetic, try one additional neighbor toward q64, still inside interval. Accept only unchanged validator success, exact unchanged N, and zero adjustment.',
 'constraints':'No N adjustment/reseed, no floor, no altered validator or tolerance, no unbounded search. Fallback only normal Q and positive N candidates that pass continuous validity and strict R64 volume check.',
 'arithmetic_limit':'Interval endpoint division/multiplication is finite-precision R64 arithmetic. The selected value is always rechecked by the unchanged store validator; one bounded extra neighbor is allowed only inside the computed interval. If rounding still prevents acceptance, the routine rejects. This prototype does not prove endpoint arithmetic for all possible inputs.',
 'input_bindings':{
   'prior_v16_audit_sha256':sha(AUDIT),
   'source_module_sha256':sha(SOURCE),
   'exact_preexisting_module_v16_generated_prefix_sha256':'7052f067b3c84cb247b8245ce8979064c63577dd7aaa851cc6db191aff095f51',
   'caller_sha256':sha(CALLER),
   'stages_source_failure_raw_sha256':audit['input_bindings']['source_failure_raw_sha256'],
   'stages_pre_rk_gz_sha256':audit['input_bindings']['stage_raw_sha256'],
   'native_coefficients':audit['native_coefficients']
 },
 'compiler':json.loads((EVDIR/'quantizer_limiter/receipt.json').read_text())['compiler'],
 'runs':{},
 'controls':control_result,
 'summary':{'candidate_count':len(result),'directed_acceptances':sum(r['directed_store_valid'] for r in result),'all_selected_plus_two_neighbor':all(r['selected_is_plus_two_neighbor'] for r in result),'unchanged_controls_valid':all(r['unchanged'] for r in control_result)},
 'rows':result
}
for label,d in [('O0',O0),('O2',O2)]:
    out['runs'][label]={'exit_status':0,'scratch_path':str(d),'compile_log_sha256':sha(d/'compile.log'),'stdout_sha256':sha(d/'run.txt'),'executable_sha256':sha(d/'quantizer_probe')}
out['runs_byte_identical_stdout']=out['runs']['O0']['stdout_sha256']==out['runs']['O2']['stdout_sha256']
assert out['runs_byte_identical_stdout']
(OUTDIR/'directed_quantizer_audit.json').write_text(json.dumps(out,indent=2,sort_keys=True)+'\n')
