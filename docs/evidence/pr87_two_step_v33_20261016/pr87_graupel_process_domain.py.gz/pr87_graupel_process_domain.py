"""Keep process-fraction endpoints inside the native ProgB graupel domain."""

from __future__ import annotations

import hashlib


V31_KDM6_SHA256 = "9cb8d19bf676771e5bfd717d07cdaf43b4bc63912b0b7869b977fbd0f2ac1397"


def extend_graupel_process_domain(source: str) -> str:
    """Add the existing ProgB transient boundary to default rain-process search."""
    actual_hash = hashlib.sha256(source.encode()).hexdigest()
    if actual_hash != V31_KDM6_SHA256:
        raise ValueError(f"unexpected V31 KDM6 source hash: {actual_hash}")

    fraction_start = source.index("    subroutine kdm6_rain_process_fraction(")
    fraction_end = source.index("    end subroutine kdm6_rain_process_fraction", fraction_start)
    fraction = source[fraction_start:fraction_end]

    old_breakpoints = (
        "      if (pair_only) then\n"
        "        call add_breakpoint(q0(5),dq(5),real(qcrmin,8))\n"
        "        call add_breakpoint(bg0,dbg,real(1.0e-15,8))\n"
        "      endif\n"
    )
    new_breakpoints = (
        "      call add_breakpoint(q0(5),dq(5),real(qcrmin,8))\n"
        "      call add_breakpoint(bg0,dbg,real(1.0e-15,8))\n"
    )
    if fraction.count(old_breakpoints) != 1:
        raise ValueError("fraction graupel breakpoint anchor missing or ambiguous")
    fraction = fraction.replace(old_breakpoints, new_breakpoints, 1)

    interval_anchor = (
        "        call clip(q0(5)/real(rho_min,8)-bg0,dq(5)/real(rho_min,8)-dbg,lo,hi,valid_interval)\n"
        "        if (lo.gt.hi) valid_interval=.false.\n"
    )
    interval_new = (
        "        call clip(q0(5)/real(rho_min,8)-bg0,dq(5)/real(rho_min,8)-dbg,lo,hi,valid_interval)\n"
        "        if (qm(5).gt.0.0d0 .and. bm.gt.0.0d0 .and. &\n"
        "            qm(5).le.real(qcrmin,8) .and. bm.le.real(1.0e-15,8)) &\n"
        "          valid_interval=.false.\n"
        "        if (lo.gt.hi) valid_interval=.false.\n"
    )
    if fraction.count(interval_anchor) != 1:
        raise ValueError("full-PSD interval graupel anchor missing or ambiguous")
    fraction = fraction.replace(interval_anchor, interval_new, 1)
    source = source[:fraction_start] + fraction + source[fraction_end:]

    state_start = source.index("subroutine kdm6_rain_process_state_valid(")
    state_end = source.index("end subroutine kdm6_rain_process_state_valid", state_start)
    state = source[state_start:state_end]
    state_anchor = (
        "      if (real(bg,8).lt.real(q(5),8)/real(rho_max,8) .or. &\n"
        "          real(bg,8).gt.real(q(5),8)/real(rho_min,8)) then\n"
        "        if (present(failure_reason)) failure_reason=9\n"
        "        return\n"
        "      endif\n"
        "      valid=.true.\n"
    )
    state_new = (
        "      if (q(5).gt.0.0 .or. bg.gt.0.0) then\n"
        "        if (q(5).le.0.0 .or. bg.le.0.0) then\n"
        "          if (present(failure_reason)) failure_reason=9\n"
        "          return\n"
        "        endif\n"
        "        if (real(q(5),8)/real(bg,8).lt.real(rho_min,8) .or. &\n"
        "            real(q(5),8)/real(bg,8).gt.real(rho_max,8)) then\n"
        "          if (present(failure_reason)) failure_reason=9\n"
        "          return\n"
        "        endif\n"
        "        if (q(5).le.qcrmin .and. bg.le.real(1.0e-15,8)) then\n"
        "          if (present(failure_reason)) failure_reason=4\n"
        "          return\n"
        "        endif\n"
        "      endif\n"
        "      valid=.true.\n"
    )
    if state.count(state_anchor) != 1:
        raise ValueError("default state-validator graupel anchor missing or ambiguous")
    state = state.replace(state_anchor, state_new, 1)
    return source[:state_start] + state + source[state_end:]
