from __future__ import annotations

import gzip
import hashlib
from pathlib import Path
import re
import subprocess
import tempfile
import sys

import pytest


ROOT = Path(__file__).resolve().parents[1]
SOURCE = ROOT / "docs/evidence/pr87_two_step_v31_20261016/module_mp_kdm6.F.gz"
TOOLCHAIN = ROOT / "tests/intel_toolchain.sh"
sys.path.insert(0, str(ROOT / "tools"))

from pr87_graupel_process_domain import (  # noqa: E402
    V31_KDM6_SHA256,
    extend_graupel_process_domain,
)


def _routine(source: str, name: str) -> str:
    start = re.search(rf"^\s*subroutine\s+{name}\s*\(", source, re.I | re.M)
    assert start, f"missing {name}"
    end = re.search(
        rf"^\s*end\s+subroutine\s+{name}\s*$",
        source[start.end():], re.I | re.M,
    )
    assert end, f"missing end of {name}"
    return source[start.start():start.end() + end.end()]


def _fixture_source() -> str:
    original = gzip.open(SOURCE, "rt").read()
    transformed = extend_graupel_process_domain(original)
    fraction = _routine(transformed, "kdm6_rain_process_fraction")
    state_valid = _routine(transformed, "kdm6_rain_process_state_valid")
    return f"""module pr87_process_helpers
  implicit none
  real, parameter :: PR85_ICE_NATIVE_INACTIVE_MAX = nearest(1.e-14,-1.0)
contains
{fraction}
{state_valid}
end module pr87_process_helpers

program test_graupel_process_domain
  use, intrinsic :: ieee_arithmetic, only: ieee_is_finite, ieee_value, ieee_quiet_nan
  use pr87_process_helpers
  implicit none
  real :: q(5), dq(5), n(3), dn(3), bg, dbg, alpha
  real :: density,pidnr,qmin,ncmin,qcrmin,dmr,lmin,lmax,rhomin,rhomax
  real :: pidnc,dmc,lcmin,lcmax,pidni,dmi,limin,limax,t
  integer :: reason,status
  logical :: valid,feasible

  density=500.0; pidnr=1.0; pidnc=1.0; pidni=1.0
  qmin=1.0e-15; ncmin=10.0; qcrmin=1.0e-9
  dmr=3.0; dmc=3.0; dmi=3.0
  lmin=1.0; lmax=2.0; lcmin=1.0; lcmax=2.0; limin=1.0; limax=2.0
  rhomin=100.0; rhomax=900.0; t=280.0
  q=0.0; n=0.0; bg=0.0

  ! Exact V32diag context-6 witness: default and pair-only modes agree.
  q(5)=transfer(int(z'2B621F22'),0.0)
  bg=transfer(int(z'2681EB95'),0.0)
  call kdm6_rain_process_state_valid(q,n,bg,t,density,pidnr,qmin,ncmin, &
       qcrmin,dmr,lmin,lmax,rhomin,rhomax,pidnc,dmc,lcmin,lcmax, &
       pidni,dmi,limin,limax,valid,.false.,.true.,failure_reason=reason)
  if (valid .or. reason /= 4) error stop 'pair-only accepted transient graupel'
  call kdm6_rain_process_state_valid(q,n,bg,t,density,pidnr,qmin,ncmin, &
       qcrmin,dmr,lmin,lmax,rhomin,rhomax,pidnc,dmc,lcmin,lcmax, &
       pidni,dmi,limin,limax,valid,failure_reason=reason)
  if (valid .or. reason /= 4) error stop 'default accepted transient graupel'

  ! Exact absence and supported active density remain accepted.
  q=0.0; n=0.0; bg=0.0
  call kdm6_rain_process_state_valid(q,n,bg,t,density,pidnr,qmin,ncmin, &
       qcrmin,dmr,lmin,lmax,rhomin,rhomax,pidnc,dmc,lcmin,lcmax, &
       pidni,dmi,limin,limax,valid)
  if (.not.valid) error stop 'exact absent graupel rejected'
  q(5)=2.0e-9; bg=4.0e-12
  call kdm6_rain_process_state_valid(q,n,bg,t,density,pidnr,qmin,ncmin, &
       qcrmin,dmr,lmin,lmax,rhomin,rhomax,pidnc,dmc,lcmin,lcmax, &
       pidni,dmi,limin,limax,valid)
  if (.not.valid) error stop 'active supported graupel rejected'

  ! At the exact B cutoff, a valid density ratio is still transient. The next
  ! REAL32 value above the cutoff is active and accepted.
  q(5)=8.0e-13; bg=1.0e-15
  call kdm6_rain_process_state_valid(q,n,bg,t,density,pidnr,qmin,ncmin, &
       qcrmin,dmr,lmin,lmax,rhomin,rhomax,pidnc,dmc,lcmin,lcmax, &
       pidni,dmi,limin,limax,valid)
  if (valid) error stop 'exact B threshold transient was accepted'
  bg=nearest(bg,1.0)
  call kdm6_rain_process_state_valid(q,n,bg,t,density,pidnr,qmin,ncmin, &
       qcrmin,dmr,lmin,lmax,rhomin,rhomax,pidnc,dmc,lcmin,lcmax, &
       pidni,dmi,limin,limax,valid)
  if (.not.valid) error stop 'next REAL32 value above B threshold rejected'

  ! Both modes continue rejecting a paired but out-of-domain mean density.
  q(5)=1.0e-6; bg=q(5)/99.0
  call kdm6_rain_process_state_valid(q,n,bg,t,density,pidnr,qmin,ncmin, &
       qcrmin,dmr,lmin,lmax,rhomin,rhomax,pidnc,dmc,lcmin,lcmax, &
       pidni,dmi,limin,limax,valid,.false.,.true.)
  if (valid) error stop 'pair-only accepted unsupported density'
  call kdm6_rain_process_state_valid(q,n,bg,t,density,pidnr,qmin,ncmin, &
       qcrmin,dmr,lmin,lmax,rhomin,rhomax,pidnc,dmc,lcmin,lcmax, &
       pidni,dmi,limin,limax,valid)
  if (valid) error stop 'default accepted unsupported density'

  ! Full generation from absence remains feasible at alpha=1.
  q=0.0; n=0.0; dq=0.0; dn=0.0; bg=0.0; dbg=0.0
  dq(5)=1.0e-6; dbg=2.0e-9
  call process_fraction(alpha,feasible,status)
  if (.not.feasible .or. status /= 0 .or. alpha /= 1.0) &
       error stop 'full graupel generation was not admitted'

  ! A decreasing proposal crosses into the forbidden transient interval.
  ! The default full-PSD search must stop at a valid smaller REAL32 fraction.
  q(5)=2.0e-9; bg=4.0e-12; dq=0.0; dn=0.0
  dq(5)=-1.9996e-9; dbg=-3.9992e-12
  call process_fraction(alpha,feasible,status)
  if (.not.feasible .or. status /= 0 .or. alpha <= 0.0 .or. alpha >= 1.0) &
       error stop 'full-PSD search did not find a smaller valid fraction'
  q(5)=q(5)+alpha*dq(5); bg=bg+alpha*dbg
  call kdm6_rain_process_state_valid(q,n,bg,t,density,pidnr,qmin,ncmin, &
       qcrmin,dmr,lmin,lmax,rhomin,rhomax,pidnc,dmc,lcmin,lcmax, &
       pidni,dmi,limin,limax,valid)
  if (.not.valid .or. q(5)<=qcrmin .and. bg<=1.0e-15) &
       error stop 'selected full-PSD endpoint is outside ProgB domain'

  ! Nonfinite proposals remain fail-closed.
  q=0.0; n=0.0; dq=0.0; dn=0.0; bg=0.0; dbg=0.0
  q(5)=2.0e-9; bg=4.0e-12
  dq(5)=ieee_value(0.0,ieee_quiet_nan)
  call process_fraction(alpha,feasible,status)
  if (feasible .or. status /= 2 .or. .not.ieee_is_finite(alpha)) &
       error stop 'nonfinite proposal did not fail closed'
  print '(a)', 'PR87 graupel process domain PASS'
contains
  subroutine process_fraction(factor,ok,search_status)
    real, intent(out) :: factor
    logical, intent(out) :: ok
    integer, intent(out) :: search_status
    call kdm6_rain_process_fraction(q,dq,n,dn,bg,dbg,t,0.0,.false., &
         density,pidnr,qmin,ncmin,qcrmin,dmr,lmin,lmax,rhomin,rhomax, &
         pidnc,dmc,lcmin,lcmax,pidni,dmi,limin,limax,factor,ok,search_status)
  end subroutine process_fraction
end program test_graupel_process_domain
"""


def test_source_contract_and_pinned_identity():
    source = gzip.open(SOURCE, "rt").read()
    assert hashlib.sha256(source.encode()).hexdigest() == V31_KDM6_SHA256
    changed = extend_graupel_process_domain(source)
    assert changed != source
    assert changed.count("call add_breakpoint(q0(5),dq(5),real(qcrmin,8))") == 1
    assert changed.count("call add_breakpoint(bg0,dbg,real(1.0e-15,8))") == 1
    assert changed.count("qm(5).le.real(qcrmin,8) .and. bm.le.real(1.0e-15,8)") == 2
    assert "q(5).le.qcrmin .and. bg.le.real(1.0e-15,8)" in changed
    assert "real(q(5),8)/real(bg,8).lt.real(rho_min,8)" in changed
    assert "real(q(5),8)/real(bg,8).gt.real(rho_max,8)" in changed
    with pytest.raises(ValueError, match="unexpected V31 KDM6 source hash"):
        extend_graupel_process_domain(source + "\n")


@pytest.mark.parametrize("optimization", ["O0", "O2"])
def test_transformed_helpers_with_pinned_intel(optimization: str):
    fixture = _fixture_source()
    with tempfile.TemporaryDirectory(
        prefix=f"pr87_graupel_domain_{optimization}_", dir="/var/tmp"
    ) as tmp:
        scratch = Path(tmp)
        source_path = scratch / "test_graupel_process_domain.F90"
        executable = scratch / "test_graupel_process_domain.exe"
        source_path.write_text(fixture)
        flags = "-O0" if optimization == "O0" else "-O2"
        script = f"""
set -euo pipefail
source '{TOOLCHAIN}'
"$CLOUD_BAL_FC" -stand f08 -warn all -check all -fpe0 -traceback {flags} \\
  -fp-model strict -fimf-arch-consistency=true -no-ftz \\
  '{source_path}' -o '{executable}'
'{executable}'
"""
        result = subprocess.run(
            ["bash", "-lc", script], cwd=scratch, text=True,
            stdout=subprocess.PIPE, stderr=subprocess.STDOUT, check=False,
        )
        assert result.returncode == 0, result.stdout
        assert "PR87 graupel process domain PASS" in result.stdout

