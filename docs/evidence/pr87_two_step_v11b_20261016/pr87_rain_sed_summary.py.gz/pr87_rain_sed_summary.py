#!/usr/bin/env python3
"""Evidence-only PR87 rain sedimentation ledger summarizer."""
from __future__ import annotations

import argparse
import gzip
import hashlib
import json
import math
from collections import defaultdict
from pathlib import Path

CALL_TAG = "PR87_RAIN_CALL"
ROW_TAG = "PR87_RAIN_SED"


def sha256(data: bytes) -> str:
    return hashlib.sha256(data).hexdigest()


def read_ledger(path: Path) -> tuple[bytes, bytes]:
    raw = path.read_bytes()
    decoded = gzip.decompress(raw) if path.suffix == ".gz" else raw
    return raw, decoded


def arithmetic_close(lhs: float, rhs: float, *operands: float) -> bool:
    scale = max((abs(x) for x in (lhs, rhs, *operands)), default=0.0)
    if scale == 0.0:
        return True
    ulp = math.ulp(scale)
    return abs(lhs - rhs) <= 8.0 * ulp


def sum_metric(rows: list[dict], key: str) -> float:
    return math.fsum(row[key] for row in rows)


def summarize(path: Path, arm: str, source_path: Path | None = None,
              receipt_path: Path | None = None) -> dict:
    raw_bytes, decoded_bytes = read_ledger(path)
    try:
        lines = decoded_bytes.decode("ascii").splitlines()
    except UnicodeDecodeError as exc:
        raise ValueError("rain ledger is not ASCII formatted text") from exc

    calls: list[dict] = []
    current: dict | None = None
    rows_by_call: dict[int, list[dict]] = defaultdict(list)
    row_keys: set[tuple[int, int, int]] = set()
    header_pending = False
    header_comment_count = 0
    stale_row_tag_headers: list[int] = []
    for line_no, line in enumerate(lines, start=1):
        words = line.split()
        if not words:
            continue
        if line.lstrip().startswith("# PR87_RAIN_CALL:"):
            if "model_timestep" not in line or "dtcld" not in line:
                raise ValueError(f"line {line_no}: malformed PR87 call header")
            header_pending = True
            header_comment_count += 1
            if ROW_TAG not in line:
                stale_row_tag_headers.append(line_no)
            continue
        if words[0].startswith("#"):
            continue
        tag = words[0]
        if tag == CALL_TAG:
            if not header_pending:
                raise ValueError(f"line {line_no}: {CALL_TAG} lacks its schema header")
            header_pending = False
            if len(words) != 4:
                raise ValueError(f"line {line_no}: expected 3 fields after {CALL_TAG}")
            timestep, wrapper_j = int(words[1]), int(words[2])
            dt = float(words[3])
            if timestep < 0 or not math.isfinite(dt) or dt <= 0.0:
                raise ValueError(f"line {line_no}: invalid call metadata")
            if current is not None and not rows_by_call[len(calls) - 1]:
                raise ValueError(f"call {len(calls) - 1} has no rain rows")
            current = {"call_index": len(calls), "timestep": timestep,
                       "wrapper_j": wrapper_j, "dtcld_s": dt}
            calls.append(current)
            continue
        if tag != ROW_TAG:
            continue
        if current is None:
            raise ValueError(f"line {line_no}: rain row precedes call metadata")
        if len(words) != 17:
            raise ValueError(f"line {line_no}: expected 16 fields after {ROW_TAG}, got {len(words)-1}")
        i, lat, substep, nlevels = map(int, words[1:5])
        values = list(map(float, words[5:]))
        if not all(math.isfinite(x) for x in values):
            raise ValueError(f"line {line_no}: non-finite rain ledger value")
        if substep < 1 or nlevels < 1 or lat != current["wrapper_j"]:
            raise ValueError(f"line {line_no}: row identity disagrees with its call metadata")
        key = (current["call_index"], i, substep)
        if key in row_keys:
            raise ValueError(f"line {line_no}: duplicate call/cell/substep row {key}")
        row_keys.add(key)
        names = ("proposal_q_kg_m2", "approved_q_kg_m2", "withheld_q_kg_m2",
                 "proposal_n_number_m2", "approved_n_number_m2", "withheld_n_number_m2",
                 "surface_q_kg_m2", "surface_n_number_m2",
                 "stored_delta_q_kg_m2", "stored_delta_n_number_m2",
                 "residual_q_kg_m2", "residual_n_number_m2")
        row = {name: value for name, value in zip(names, values)}
        row.update({"call_index": current["call_index"], "timestep": current["timestep"],
                    "wrapper_j": current["wrapper_j"], "cell_i": i,
                    "substep": substep, "nlevels": nlevels, "line": line_no})
        for suffix in ("q_kg_m2", "n_number_m2"):
            proposed = row[f"proposal_{suffix}"]
            approved = row[f"approved_{suffix}"]
            withheld = row[f"withheld_{suffix}"]
            surface = row[f"surface_{suffix}"]
            stored = row[f"stored_delta_{suffix}"]
            residual = row[f"residual_{suffix}"]
            if min(proposed, approved, surface) < 0.0:
                raise ValueError(f"line {line_no}: negative proposal/approval/surface amount")
            if not arithmetic_close(proposed, approved + withheld, proposed, approved, withheld):
                raise ValueError(f"line {line_no}: proposal != approved + withheld for {suffix}")
            if approved > proposed and not arithmetic_close(approved, proposed, approved, proposed):
                raise ValueError(f"line {line_no}: approval exceeds proposal for {suffix}")
            if surface > approved and not arithmetic_close(surface, approved, surface, approved):
                raise ValueError(f"line {line_no}: surface sink exceeds approved amount for {suffix}")
            if not arithmetic_close(residual, stored + surface, residual, stored, surface):
                raise ValueError(f"line {line_no}: residual != stored delta + surface sink for {suffix}")
        rows_by_call[current["call_index"]].append(row)

    if not calls:
        raise ValueError("no PR87_RAIN_CALL metadata rows found")
    if header_comment_count != len(calls):
        raise ValueError("schema header count does not match rain call count")
    if any(not rows_by_call[idx] for idx in range(len(calls))):
        raise ValueError("one or more rain calls have no PR87_RAIN_SED rows")
    all_rows = [row for idx in range(len(calls)) for row in rows_by_call[idx]]

    by_timestep: dict[int, list[dict]] = defaultdict(list)
    for row in all_rows:
        by_timestep[row["timestep"]].append(row)
    timestep_summaries = []
    for timestep, rows in sorted(by_timestep.items()):
        item = {"model_timestep": timestep,
                "calls": len({row["call_index"] for row in rows}),
                "rows": len(rows),
                "columns": len({(row["call_index"], row["cell_i"]) for row in rows})}
        metrics = ("proposal_q_kg_m2", "approved_q_kg_m2", "withheld_q_kg_m2",
                   "surface_q_kg_m2", "stored_delta_q_kg_m2", "residual_q_kg_m2",
                   "proposal_n_number_m2", "approved_n_number_m2", "withheld_n_number_m2",
                   "surface_n_number_m2", "stored_delta_n_number_m2", "residual_n_number_m2")
        item["sums_over_recorded_columns"] = {name: sum_metric(rows, name) for name in metrics}
        item["residual_scale"] = {
            "q_abs_storage_plus_surface_kg_m2": math.fsum(
                abs(r["stored_delta_q_kg_m2"]) + r["surface_q_kg_m2"] for r in rows),
            "n_abs_storage_plus_surface_number_m2": math.fsum(
                abs(r["stored_delta_n_number_m2"]) + r["surface_n_number_m2"] for r in rows),
        }
        timestep_summaries.append(item)

    metadata = {
        "arm": arm,
        "ledger_path": str(path),
        "ledger_file_sha256": sha256(raw_bytes),
        "decoded_ledger_sha256": sha256(decoded_bytes),
        "compression": "gzip" if path.suffix == ".gz" else "none",
        "calls": calls,
        "call_count": len(calls),
        "row_count": len(all_rows),
        "negative_withheld_roundoff_rows": sum(1 for row in all_rows
            if row["withheld_q_kg_m2"] < 0.0 or row["withheld_n_number_m2"] < 0.0),
        "max_abs_negative_withheld_q_kg_m2": max((abs(row["withheld_q_kg_m2"])
            for row in all_rows if row["withheld_q_kg_m2"] < 0.0), default=0.0),
        "max_abs_negative_withheld_n_number_m2": max((abs(row["withheld_n_number_m2"])
            for row in all_rows if row["withheld_n_number_m2"] < 0.0), default=0.0),
        "schema_header_count": header_comment_count,
        "stale_row_tag_header_lines": stale_row_tag_headers,
        "timestep_summaries": timestep_summaries,
        "scope_note": "Sums are unweighted sums of per-column area amounts; no global kg or domain-total claim.",
        "units": {"q": "kg m-2 per column", "number": "count m-2 per column"},
        "validation": "finite fields; unique cell/substep per call; proposal split and per-row surface/storage closure within formatted R64 operand-scale rounding bound; tiny signed withheld values retained as roundoff rather than clipped",
    }
    if source_path:
        source_bytes = source_path.read_bytes()
        metadata["source"] = {"path": str(source_path), "sha256": sha256(source_bytes)}
    if receipt_path:
        receipt_bytes = receipt_path.read_bytes()
        run_receipt = json.loads(receipt_bytes)
        generated = run_receipt.get("generated_files", [])
        bound_ledger = next((item for item in generated
                             if Path(item.get("path", "")).name == path.name), None)
        if bound_ledger is None:
            raise ValueError("run receipt does not list the supplied rain ledger")
        if bound_ledger.get("sha256") != sha256(raw_bytes) or bound_ledger.get("bytes") != len(raw_bytes):
            raise ValueError("rain ledger hash or size disagrees with the run receipt")
        build = run_receipt.get("candidate_build", {})
        metadata["run_receipt"] = {
            "path": str(receipt_path), "sha256": sha256(receipt_bytes),
            "status": run_receipt.get("status"), "return_code": run_receipt.get("returncode"),
            "run_identity": run_receipt.get("run_identity"),
            "timestep_count": run_receipt.get("timestep_count"),
            "final_completed_step": run_receipt.get("final_completed_step"),
            "maximum_seen_timestep": run_receipt.get("maximum_seen_timestep"),
            "executed_executable_sha256": run_receipt.get("executed_executable_sha256"),
            "source_receipt_sha256": run_receipt.get("source_receipt_sha256"),
            "candidate_build_receipt_sha256": build.get("receipt_sha256"),
            "bound_ledger_sha256": bound_ledger.get("sha256"),
            "bound_ledger_bytes": bound_ledger.get("bytes"),
        }
    return metadata


def main() -> None:
    parser = argparse.ArgumentParser()
    parser.add_argument("ledger", type=Path)
    parser.add_argument("output", type=Path)
    parser.add_argument("--arm", required=True)
    parser.add_argument("--source", type=Path)
    parser.add_argument("--receipt", type=Path)
    args = parser.parse_args()
    result = summarize(args.ledger, args.arm, args.source, args.receipt)
    args.output.write_text(json.dumps(result, indent=2, sort_keys=True) + "\n")
    print(f"summary={args.output}")
    print(f"ledger_sha256={result['ledger_file_sha256']}")
    print(f"calls={result['call_count']} rows={result['row_count']}")
    for entry in result["timestep_summaries"]:
        print(json.dumps(entry, sort_keys=True))


if __name__ == "__main__":
    main()
