from pathlib import Path
import sys,gzip,tempfile,json,hashlib,shutil
import numpy as np
root=Path('/NHNHOME/WORKSPACE/26weather002_A/yhlee/KLAPS50/scratch/pr87_two_step_20261016/Cloud-BAL');sys.path.insert(0,str(root/'tools'))
from native_kdm6_trace import read_dump
from pr86_water_budget import load_call_measure
h=lambda p:hashlib.sha256(p.read_bytes()).hexdigest()
reports={}
for arm in ['OFF','COUPLED']:
 run=Path(f'/var/tmp/pr87_joint_{arm}_40s_v11b_20261016');receipt=json.loads((run/'receipt.json').read_text())
 base=load_call_measure(Path(f'/var/tmp/pr85_same13_{arm}_joint_v17_20261015a'))
 records={r['path']:r for r in receipt['compressed_outputs']}
 states={};identities={}
 with tempfile.TemporaryDirectory(prefix='pr87_v11b_call_compare_',dir='/var/tmp') as td:
  for stage in ['pre','post']:
   name=f'kdm6_first_call_{stage}.raw';src=run/'run'/records[name]['compressed_path'];assert h(src)==records[name]['compressed_sha256']
   dst=Path(td)/name
   with gzip.open(src,'rb') as a,dst.open('wb') as b:shutil.copyfileobj(a,b)
   assert h(dst)==records[name]['sha256']; states[stage]=read_dump(dst);identities[stage]={'raw_sha256':h(dst),'compressed_sha256':h(src)}
  assert states['pre']['sha256']==base['pre']['sha256']
  for stage in states:
   assert states[stage]['bounds']==base[stage]['bounds']
   for n in ['DEN','DELZ']:assert np.array_equal(states[stage]['fields'][n],base[stage]['fields'][n])
  fields={}
  for name in ['Q','QC','QI','QR','QS','QG','NC','NI','NR','BG']:
   a=base['post']['fields'][name].astype(np.float64);b=states['post']['fields'][name].astype(np.float64);d=b-a
   weight=base['dry_mass_jki']; unit='kg' if name in ['Q','QC','QI','QR','QS','QG'] else 'number' if name!='BG' else 'm3'
   fields[name]={'changed_cells':int(np.count_nonzero(d)),'max_abs_native_units':float(np.max(np.abs(d))),'rms_native_units':float(np.sqrt(np.mean(d*d))),'signed_inventory_change':float(np.sum(d*weight,dtype=np.float64)),'l1_inventory_change':float(np.sum(np.abs(d)*weight,dtype=np.float64)),'inventory_unit':unit}
  reports[arm]={'run_receipt_sha256':h(run/'receipt.json'),'baseline_identity':base['identities'],'candidate_dumps':identities,'pre_byte_identical_v17':True,'post_byte_identical_v17':states['post']['sha256']==base['post']['sha256'],'same_fixed_call_density_geometry':True,'fields':fields}
payload={'schema':'pr87_v11b_first_call_change_v1','scope':'New paired-rain numerical model minus preserved v17, same first-call incoming state and local dry-density DELZ area measure. Not improved conservation, observational skill, or host hybrid closure.','physical_approval':'FAIL_OPEN','arms':reports}
out=root/'docs/evidence/pr87_two_step_v11b_20261016/first_call_change.json';out.write_text(json.dumps(payload,indent=2,allow_nan=False)+'\n')
print(out)
