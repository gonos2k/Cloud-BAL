program pr87_v19_directed_store_proof
  use iso_fortran_env, only: real32, real64
  use cloud_bal_joint_transport, only: joint_moment_is_valid64, joint_moment_store
  implicit none
  integer :: count_adjusted
  real(real64) :: delta_sum,delta_min,delta_max
  count_adjusted=0
  delta_sum=0.0_real64
  delta_min=huge(0.0_real64)
  delta_max=-huge(0.0_real64)
  call run_case(1, 'OFF', 109, 5, 19, &
       5.74420273303985596E-01_real32, 5.07889771905745135E-11_real64, 1.73286095261573792E-01_real64)
  call run_case(2, 'OFF', 124, 8, 17, &
       6.76905155181884766E-01_real32, 1.34991244848947645E-08_real64, 4.60574455261230469E+01_real64)
  call run_case(3, 'OFF', 130, 21, 17, &
       6.77967488765716553E-01_real32, 3.37456659837975792E-11_real64, 1.15136295557022095E-01_real64)
  call run_case(4, 'OFF', 124, 32, 17, &
       6.79457187652587891E-01_real32, 2.55183699691963195E-12_real64, 8.70657153427600861E-03_real64)
  call run_case(5, 'OFF', 129, 33, 18, &
       6.29499554634094238E-01_real32, 4.13048978700758518E-12_real64, 1.40927517786622047E-02_real64)
  call run_case(6, 'OFF', 182, 35, 18, &
       6.30918443202972412E-01_real32, 3.46806472428795587E-11_real64, 1.18326343595981598E-01_real64)
  call run_case(7, 'OFF', 142, 45, 17, &
       6.79041743278503418E-01_real32, 3.54847969674665364E-07_real64, 1.21070007324218750E+03_real64)
  call run_case(8, 'OFF', 173, 50, 18, &
       6.29677712917327881E-01_real32, 1.19077505189579824E-07_real64, 4.06278625488281250E+02_real64)
  call run_case(9, 'OFF', 180, 54, 18, &
       6.30397260189056396E-01_real32, 1.38479867572982585E-08_real64, 4.72477226257324219E+01_real64)
  call run_case(10, 'OFF', 181, 54, 18, &
       6.30661249160766602E-01_real32, 3.72317892072260292E-08_real64, 1.27030540466308594E+02_real64)
  call run_case(11, 'OFF', 153, 55, 17, &
       6.80067300796508789E-01_real32, 1.78759921709570335E-06_real64, 6.09908105468750000E+03_real64)
  call run_case(12, 'OFF', 180, 55, 18, &
       6.30133092403411865E-01_real32, 6.68938611170233344E-08_real64, 2.28234085083007812E+02_real64)
  call run_case(13, 'OFF', 200, 56, 18, &
       6.29980444908142090E-01_real32, 2.25326624025967703E-09_real64, 7.68788290023803711E+00_real64)
  call run_case(14, 'OFF', 188, 56, 19, &
       5.78516960144042969E-01_real32, 1.13405551616097000E-08_real64, 3.86926574707031250E+01_real64)
  call run_case(15, 'OFF', 186, 59, 18, &
       6.30088508129119873E-01_real32, 4.84270268330533327E-09_real64, 1.65227394104003906E+01_real64)
  call run_case(16, 'OFF', 150, 62, 18, &
       6.26381218433380127E-01_real32, 2.64501860414156909E-08_real64, 9.02449645996093750E+01_real64)
  call run_case(17, 'OFF', 117, 64, 16, &
       7.28319466114044189E-01_real32, 3.15395959349373811E-10_real64, 1.07609438896179199E+00_real64)
  call run_case(18, 'OFF', 147, 64, 18, &
       6.26357793807983398E-01_real32, 7.62433671752660302E-08_real64, 2.60133514404296875E+02_real64)
  call run_case(19, 'OFF', 200, 65, 18, &
       6.29736781120300293E-01_real32, 1.47707501785276918E-09_real64, 5.03960847854614258E+00_real64)
  call run_case(20, 'OFF', 189, 66, 19, &
       5.77648401260375977E-01_real32, 6.21528695177175905E-09_real64, 2.12058372497558594E+01_real64)
  call run_case(21, 'OFF', 206, 68, 17, &
       6.81296825408935547E-01_real32, 2.91349167014232080E-08_real64, 9.94049530029296875E+01_real64)
  call run_case(22, 'OFF', 193, 68, 18, &
       6.29632532596588135E-01_real32, 5.98742673219021526E-08_real64, 2.04284042358398438E+02_real64)
  call run_case(23, 'OFF', 120, 70, 5, &
       1.09372615814208984E+00_real32, 1.45816709401502820E-11_real64, 4.97509688138961792E-02_real64)
  call run_case(24, 'OFF', 128, 98, 15, &
       7.77417361736297607E-01_real32, 2.23092821993731150E-10_real64, 7.61166810989379883E-01_real64)
  call run_case(25, 'OFF', 127, 98, 16, &
       7.28410720825195312E-01_real32, 3.17879576827717614E-11_real64, 1.08456820249557495E-01_real64)
  call run_case(26, 'OFF', 205, 109, 17, &
       6.82078778743743896E-01_real32, 2.98890218131120378E-10_real64, 1.01977872848510742E+00_real64)
  call run_case(27, 'OFF', 201, 113, 17, &
       6.82441651821136475E-01_real32, 1.90049096460143119E-08_real64, 6.48425445556640625E+01_real64)
  call run_case(28, 'OFF', 30, 118, 18, &
       6.38454437255859375E-01_real32, 2.34347268701640132E-07_real64, 7.99565673828125000E+02_real64)
  call run_case(29, 'OFF', 218, 142, 16, &
       7.35759973526000977E-01_real32, 5.24353879427508218E-07_real64, 1.78903454589843750E+03_real64)
  call run_case(30, 'OFF', 204, 150, 17, &
       6.87596142292022705E-01_real32, 2.44931186443864135E-09_real64, 8.35676765441894531E+00_real64)
  call run_case(31, 'OFF', 201, 153, 18, &
       6.32041871547698975E-01_real32, 2.46767206668607741E-09_real64, 8.41941070556640625E+00_real64)
  call run_case(32, 'OFF', 224, 165, 18, &
       6.32681250572204590E-01_real32, 1.14958376151719222E-10_real64, 3.92224639654159546E-01_real64)
  call run_case(33, 'OFF', 190, 167, 16, &
       7.31917858123779297E-01_real32, 9.78945480234472143E-10_real64, 3.34004831314086914E+00_real64)
  call run_case(34, 'OFF', 160, 178, 16, &
       7.34208226203918457E-01_real32, 8.72098482318506285E-09_real64, 2.97549877166748047E+01_real64)
  call run_case(35, 'OFF', 56, 187, 17, &
       6.78945004940032959E-01_real32, 8.11227039321238408E-07_real64, 2.76781250000000000E+03_real64)
  call run_case(36, 'OFF', 161, 194, 11, &
       9.40002560615539551E-01_real32, 4.00938205302736606E-07_real64, 1.36795458984375000E+03_real64)
  call run_case(37, 'OFF', 176, 203, 12, &
       9.24762666225433350E-01_real32, 3.43575578654053970E-07_real64, 1.17223999023437500E+03_real64)
  call run_case(38, 'OFF', 178, 204, 10, &
       1.00026297569274902E+00_real32, 1.45115805594286940E-07_real64, 4.95118286132812500E+02_real64)
  call run_case(39, 'OFF', 133, 205, 16, &
       6.84276819229125977E-01_real32, 2.63025849562836811E-05_real64, 1.85762786865234375E+00_real64)
  call run_case(40, 'OFF', 168, 220, 16, &
       6.77540183067321777E-01_real32, 2.47871750902461940E-10_real64, 8.45709621906280518E-01_real64)
  call run_case(41, 'OFF', 218, 225, 18, &
       6.35533094406127930E-01_real32, 3.01146423336423608E-13_real64, 1.02747662458568811E-03_real64)
  call run_case(42, 'OFF', 178, 232, 11, &
       9.17211055755615234E-01_real32, 2.31304923659081396E-07_real64, 7.89185546875000000E+02_real64)
  call run_case(43, 'OFF', 43, 235, 17, &
       6.82455480098724365E-01_real32, 4.38234991406716290E-07_real64, 1.49520690917968750E+03_real64)
  call run_case(44, 'OFF', 31, 237, 17, &
       6.77510023117065430E-01_real32, 4.73207384388274477E-09_real64, 1.61452865600585938E+01_real64)
  call run_case(45, 'OFF', 22, 240, 15, &
       7.72024810314178467E-01_real32, 1.96035934152405389E-08_real64, 6.68851852416992188E+01_real64)
  call run_case(46, 'OFF', 193, 244, 12, &
       9.21325802803039551E-01_real32, 1.95927682966612338E-08_real64, 6.68482513427734375E+01_real64)
  call run_case(47, 'OFF', 220, 244, 17, &
       6.88201665878295898E-01_real32, 3.81009002126120322E-08_real64, 1.29995849609375000E+02_real64)
  call run_case(48, 'OFF', 24, 248, 16, &
       7.34705150127410889E-01_real32, 9.50686995793148526E-09_real64, 3.24363365173339844E+01_real64)
  call run_case(49, 'OFF', 222, 249, 14, &
       8.33235859870910645E-01_real32, 1.33057574203121476E-06_real64, 4.53977001953125000E+03_real64)
  call run_case(50, 'OFF', 223, 252, 11, &
       9.57725882530212402E-01_real32, 3.20989130386806210E-07_real64, 1.09517761230468750E+03_real64)
  call run_case(51, 'COUPLED', 109, 5, 19, &
       5.74420273303985596E-01_real32, 5.07889771905745135E-11_real64, 1.73286095261573792E-01_real64)
  call run_case(52, 'COUPLED', 124, 8, 17, &
       6.76905155181884766E-01_real32, 1.34991244848947645E-08_real64, 4.60574455261230469E+01_real64)
  call run_case(53, 'COUPLED', 137, 10, 17, &
       6.77502274513244629E-01_real32, 4.10641052411842011E-12_real64, 1.40105960890650749E-02_real64)
  call run_case(54, 'COUPLED', 124, 32, 17, &
       6.79457187652587891E-01_real32, 2.55183699691963195E-12_real64, 8.70657153427600861E-03_real64)
  call run_case(55, 'COUPLED', 129, 33, 18, &
       6.29499554634094238E-01_real32, 4.13048978700758518E-12_real64, 1.40927517786622047E-02_real64)
  call run_case(56, 'COUPLED', 182, 35, 18, &
       6.30918443202972412E-01_real32, 3.46806472428795587E-11_real64, 1.18326343595981598E-01_real64)
  call run_case(57, 'COUPLED', 142, 45, 17, &
       6.79041743278503418E-01_real32, 3.54847969674665364E-07_real64, 1.21070007324218750E+03_real64)
  call run_case(58, 'COUPLED', 173, 50, 18, &
       6.29677712917327881E-01_real32, 1.19077505189579824E-07_real64, 4.06278625488281250E+02_real64)
  call run_case(59, 'COUPLED', 180, 54, 18, &
       6.30397260189056396E-01_real32, 1.38479867572982585E-08_real64, 4.72477226257324219E+01_real64)
  call run_case(60, 'COUPLED', 181, 54, 18, &
       6.30661249160766602E-01_real32, 3.72317892072260292E-08_real64, 1.27030540466308594E+02_real64)
  call run_case(61, 'COUPLED', 153, 55, 17, &
       6.80067300796508789E-01_real32, 1.78759921709570335E-06_real64, 6.09908105468750000E+03_real64)
  call run_case(62, 'COUPLED', 180, 55, 18, &
       6.30133092403411865E-01_real32, 6.68938611170233344E-08_real64, 2.28234085083007812E+02_real64)
  call run_case(63, 'COUPLED', 200, 56, 18, &
       6.29980444908142090E-01_real32, 2.25326624025967703E-09_real64, 7.68788290023803711E+00_real64)
  call run_case(64, 'COUPLED', 188, 56, 19, &
       5.78516960144042969E-01_real32, 1.13405551616097000E-08_real64, 3.86926574707031250E+01_real64)
  call run_case(65, 'COUPLED', 186, 59, 18, &
       6.30088508129119873E-01_real32, 4.84270268330533327E-09_real64, 1.65227394104003906E+01_real64)
  call run_case(66, 'COUPLED', 150, 62, 18, &
       6.26381218433380127E-01_real32, 2.64501860414156909E-08_real64, 9.02449645996093750E+01_real64)
  call run_case(67, 'COUPLED', 117, 64, 16, &
       7.28319466114044189E-01_real32, 3.15395959349373811E-10_real64, 1.07609438896179199E+00_real64)
  call run_case(68, 'COUPLED', 147, 64, 18, &
       6.26357793807983398E-01_real32, 7.62433671752660302E-08_real64, 2.60133514404296875E+02_real64)
  call run_case(69, 'COUPLED', 200, 65, 18, &
       6.29736781120300293E-01_real32, 1.47707501785276918E-09_real64, 5.03960847854614258E+00_real64)
  call run_case(70, 'COUPLED', 189, 66, 19, &
       5.77648401260375977E-01_real32, 6.21528695177175905E-09_real64, 2.12058372497558594E+01_real64)
  call run_case(71, 'COUPLED', 206, 68, 17, &
       6.81296825408935547E-01_real32, 2.91349167014232080E-08_real64, 9.94049530029296875E+01_real64)
  call run_case(72, 'COUPLED', 193, 68, 18, &
       6.29632532596588135E-01_real32, 5.98742673219021526E-08_real64, 2.04284042358398438E+02_real64)
  call run_case(73, 'COUPLED', 120, 70, 5, &
       1.09372615814208984E+00_real32, 1.45816709401502820E-11_real64, 4.97509688138961792E-02_real64)
  call run_case(74, 'COUPLED', 128, 98, 15, &
       7.77417361736297607E-01_real32, 2.23092821993731150E-10_real64, 7.61166810989379883E-01_real64)
  call run_case(75, 'COUPLED', 127, 98, 16, &
       7.28410720825195312E-01_real32, 3.17879576827717614E-11_real64, 1.08456820249557495E-01_real64)
  call run_case(76, 'COUPLED', 205, 109, 17, &
       6.82078778743743896E-01_real32, 2.98890218131120378E-10_real64, 1.01977872848510742E+00_real64)
  call run_case(77, 'COUPLED', 201, 113, 17, &
       6.82441651821136475E-01_real32, 1.90049096460143119E-08_real64, 6.48425445556640625E+01_real64)
  call run_case(78, 'COUPLED', 30, 118, 18, &
       6.38454437255859375E-01_real32, 2.34347268701640132E-07_real64, 7.99565673828125000E+02_real64)
  call run_case(79, 'COUPLED', 218, 142, 16, &
       7.35759973526000977E-01_real32, 5.24353879427508218E-07_real64, 1.78903454589843750E+03_real64)
  call run_case(80, 'COUPLED', 204, 150, 17, &
       6.87596142292022705E-01_real32, 2.44931186443864135E-09_real64, 8.35676765441894531E+00_real64)
  call run_case(81, 'COUPLED', 201, 153, 18, &
       6.32041871547698975E-01_real32, 2.46767206668607741E-09_real64, 8.41941070556640625E+00_real64)
  call run_case(82, 'COUPLED', 224, 165, 18, &
       6.32681250572204590E-01_real32, 1.14958376151719222E-10_real64, 3.92224639654159546E-01_real64)
  call run_case(83, 'COUPLED', 190, 167, 16, &
       7.31917858123779297E-01_real32, 9.78945480234472143E-10_real64, 3.34004831314086914E+00_real64)
  call run_case(84, 'COUPLED', 160, 178, 16, &
       7.34208226203918457E-01_real32, 8.72098482318506285E-09_real64, 2.97549877166748047E+01_real64)
  call run_case(85, 'COUPLED', 56, 187, 17, &
       6.78945004940032959E-01_real32, 8.11227039321238408E-07_real64, 2.76781250000000000E+03_real64)
  call run_case(86, 'COUPLED', 161, 194, 11, &
       9.40002560615539551E-01_real32, 4.00938205302736606E-07_real64, 1.36795458984375000E+03_real64)
  call run_case(87, 'COUPLED', 176, 203, 12, &
       9.24762666225433350E-01_real32, 3.43575578654053970E-07_real64, 1.17223999023437500E+03_real64)
  call run_case(88, 'COUPLED', 178, 204, 10, &
       1.00026297569274902E+00_real32, 1.45115805594286940E-07_real64, 4.95118286132812500E+02_real64)
  call run_case(89, 'COUPLED', 133, 205, 16, &
       6.84276819229125977E-01_real32, 2.63025849562836811E-05_real64, 1.85762786865234375E+00_real64)
  call run_case(90, 'COUPLED', 168, 220, 16, &
       6.77540183067321777E-01_real32, 2.47871750902461940E-10_real64, 8.45709621906280518E-01_real64)
  call run_case(91, 'COUPLED', 218, 225, 18, &
       6.35533094406127930E-01_real32, 3.01146423336423608E-13_real64, 1.02747662458568811E-03_real64)
  call run_case(92, 'COUPLED', 178, 232, 11, &
       9.17211055755615234E-01_real32, 2.31304923659081396E-07_real64, 7.89185546875000000E+02_real64)
  call run_case(93, 'COUPLED', 43, 235, 17, &
       6.82455480098724365E-01_real32, 4.38234991406716290E-07_real64, 1.49520690917968750E+03_real64)
  call run_case(94, 'COUPLED', 31, 237, 17, &
       6.77510023117065430E-01_real32, 4.73207384388274477E-09_real64, 1.61452865600585938E+01_real64)
  call run_case(95, 'COUPLED', 22, 240, 15, &
       7.72024810314178467E-01_real32, 1.96035934152405389E-08_real64, 6.68851852416992188E+01_real64)
  call run_case(96, 'COUPLED', 193, 244, 12, &
       9.21325802803039551E-01_real32, 1.95927682966612338E-08_real64, 6.68482513427734375E+01_real64)
  call run_case(97, 'COUPLED', 220, 244, 17, &
       6.88201665878295898E-01_real32, 3.81009002126120322E-08_real64, 1.29995849609375000E+02_real64)
  call run_case(98, 'COUPLED', 24, 248, 16, &
       7.34705150127410889E-01_real32, 9.50686995793148526E-09_real64, 3.24363365173339844E+01_real64)
  call run_case(99, 'COUPLED', 222, 249, 14, &
       8.33235859870910645E-01_real32, 1.33057574203121476E-06_real64, 4.53977001953125000E+03_real64)
  call run_case(100, 'COUPLED', 223, 252, 11, &
       9.57725882530212402E-01_real32, 3.20989130386806210E-07_real64, 1.09517761230468750E+03_real64)
  if (count_adjusted /= 100) error stop 'not every captured bad rounded-N case used directed Q storage'
  write(*,'(a,i0,a,1p,3e24.16)') 'PASS cases=',count_adjusted,' signed_Q_delta_sum/min/max=', &
       delta_sum,delta_min,delta_max
contains
  subroutine run_case(case_id,arm,cell_i,lat,k,rho,q,n)
    integer, intent(in) :: case_id,cell_i,lat,k
    character(*), intent(in) :: arm
    real(real32), intent(in) :: rho
    real(real64), intent(in) :: q,n
    real(real64), parameter :: pidnr=12566.37109375_real64
    real(real64), parameter :: lambda_min=961.0_real64,lambda_max=35000.0_real64
    real(real64) :: min_ratio,max_ratio,bounds(2),stored_q64,stored_n64
    real(real64) :: lower_n,upper_n,n_product64,n_product32,delta_q
    real(real32) :: stored_q,stored_n
    integer :: adjustment
    logical :: valid
    min_ratio=pidnr/(lambda_max**3)
    max_ratio=pidnr/(lambda_min**3)
    bounds(1)=real(rho,real64)*(lambda_min**3)/pidnr
    bounds(2)=real(rho,real64)*(lambda_max**3)/pidnr
    if (.not.joint_moment_is_valid64(q,n,rho,min_ratio,max_ratio)) then
      write(*,*) 'CONTINUOUS_REJECT',arm,cell_i,lat,k
      error stop 'captured continuous-valid case rejected by current store gate'
    endif
    call joint_moment_store(q,n,rho,min_ratio,max_ratio,.true.,stored_q,stored_n, &
        adjustment,valid,allow_normal_q_adjustment=.true.,volume_number_bounds=bounds)
    if (.not.valid) then
      write(*,*) 'STORE_REJECT',arm,cell_i,lat,k
      error stop 'directed Q store could not represent captured case'
    endif
    if (stored_n /= real(n,real32)) error stop 'store changed ordinary public N rounding'
    if (adjustment /= 2) error stop 'captured case did not use directed-Q adjustment class'
    stored_q64=real(stored_q,real64)
    stored_n64=real(stored_n,real64)
    lower_n=bounds(1)*stored_q64
    upper_n=bounds(2)*stored_q64
    n_product64=real(rho,real64)*stored_n64
    n_product32=real(stored_n*rho,real64)
    if (n_product64<lower_n .or. n_product64>upper_n .or. &
        n_product32<lower_n .or. n_product32>upper_n) then
      write(*,*) 'STORED_VOLUME_REJECT',arm,cell_i,lat,k,n_product64,n_product32,lower_n,upper_n
      error stop 'stored N-volume product escaped exact bounds'
    endif
    if (stored_q64/stored_n64<min_ratio .or. stored_q64/stored_n64>max_ratio) &
      error stop 'stored public pair escaped exact mean-mass bounds'
    delta_q=stored_q64-q
    count_adjusted=count_adjusted+1
    delta_sum=delta_sum+delta_q
    delta_min=min(delta_min,delta_q)
    delta_max=max(delta_max,delta_q)
  end subroutine run_case
end program pr87_v19_directed_store_proof
