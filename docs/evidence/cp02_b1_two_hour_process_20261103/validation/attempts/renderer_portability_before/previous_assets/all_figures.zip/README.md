CP02 B1 first-two-hour process diagnostic

This offline bundle contains unchanged historical score contexts and validated local process summaries. The score table has 18 contexts: three cases × six leads × six one-hour precipitation thresholds. No model score was recomputed for this package. Profiles retain native model levels; four-corner weights are used only for each selected location.

Tables: data/b1_categorical_scores_18_contexts.csv, data/selected_points.csv, data/integrated_components.csv. Analysis and renderer receipts are included. Native raw traces are not included. Open index.html locally for a lazy-loaded figure gallery; it makes no network requests.
