set debuginfod enabled off
set startup-with-shell off
set pagination off
set language c
set confirm off
set print thread-events off
set $capture_pending = 0
set stop-on-solib-events 1
run
set stop-on-solib-events 0
break module_mp_kdm6_mp_specific_number_to_volume_
condition 1 (*(unsigned int*)$rdi == 1) && (*(float*)$rsi > 0.0) && (*(float*)$rsi <= 0.5)
commands 1
  silent
  set $input_ptr = $rdi
  set $rho_ptr = $rsi
  set $output_ptr = $rdx
  set $valid_ptr = $rcx
  set $capture_pending = 1
  printf "PR84_CAPTURE_ENTRY input/rho/output/valid pointers\n"
  p/x $input_ptr
  p/x $rho_ptr
  p/x $output_ptr
  p/x $valid_ptr
  x/wx $input_ptr
  x/wx $rho_ptr
  info registers mxcsr
  continue
end
break *0x25b834f
condition 2 $capture_pending == 1
commands 2
  silent
  printf "PR84_CAPTURE_RETURN output and valid\n"
  x/wx $output_ptr
  x/wx $valid_ptr
  printf "PR84_CAPTURE_CALLSITE instructions/backtrace\n"
  x/12i $pc-24
  bt 5
  quit
end
continue
