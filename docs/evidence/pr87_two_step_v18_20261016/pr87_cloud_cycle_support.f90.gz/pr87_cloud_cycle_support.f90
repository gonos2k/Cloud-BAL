! Read-only cloud-pair summaries at completed state boundaries.
subroutine pr87_cloud_cycle(label, step, ims, ime, jms, jme, kms, kme, &
                           its, ite, jts, jte, kts, kte, qc, nc)
  use, intrinsic :: iso_fortran_env, only: real64, int32
  use, intrinsic :: ieee_arithmetic, only: ieee_is_finite
  implicit none
  character(*), intent(in) :: label
  integer, intent(in) :: step, ims, ime, jms, jme, kms, kme
  integer, intent(in) :: its, ite, jts, jte, kts, kte
  real, intent(in) :: qc(ims:ime,kms:kme,jms:jme), nc(ims:ime,kms:kme,jms:jme)
  integer :: i, j, k, unit, status, nonfinite, negative, mass_only, number_only
  integer :: first(3), probe(3)
  character(80) :: text
  real(real64) :: first_q, first_n

  nonfinite=0; negative=0; mass_only=0; number_only=0
  first=0; first_q=0; first_n=0
  do j=jts,jte
    do i=its,ite
      do k=kts,kte
        if (.not.ieee_is_finite(qc(i,k,j)) .or. .not.ieee_is_finite(nc(i,k,j))) then
          nonfinite=nonfinite+1
          cycle
        endif
        if (qc(i,k,j)<0 .or. nc(i,k,j)<0) negative=negative+1
        if (qc(i,k,j)>0 .and. nc(i,k,j)==0) mass_only=mass_only+1
        if (qc(i,k,j)==0 .and. nc(i,k,j)>0) number_only=number_only+1
        if (all(first==0)) then
          if ((qc(i,k,j)>0 .and. nc(i,k,j)==0) .or. &
              (qc(i,k,j)==0 .and. nc(i,k,j)>0)) then
            first=(/i,j,k/)
            first_q=real(qc(i,k,j),real64); first_n=real(nc(i,k,j),real64)
          endif
        endif
      enddo
    enddo
  enddo
  open(newunit=unit,file='pr87_cloud_cycle.log',status='unknown',position='append',iostat=status)
  if (status/=0) error stop 'PR87 cycle log open failed'
  write(unit,'(a,1x,a,11(1x,i0),2(1x,es24.16))') 'PR87_CLOUD',trim(label), &
       step,its,ite,jts,jte,kts,kte,nonfinite,negative,mass_only,number_only,first_q,first_n
  write(unit,'(a,1x,a,4(1x,i0),2(1x,es24.16))') 'PR87_FIRST',trim(label), &
       step,first,first_q,first_n
  call get_environment_variable('PR87_PROBE',text,status=status)
  if (status==0) then
    read(text,*,iostat=status) probe
    if (status/=0) error stop 'PR87 invalid probe coordinates'
    i=probe(1); j=probe(2); k=probe(3)
    if (i>=its .and. i<=ite .and. j>=jts .and. j<=jte .and. k>=kts .and. k<=kte) then
      write(unit,'(a,1x,a,4(1x,i0),2(1x,es24.16),2(1x,z8.8))') &
           'PR87_PROBE',trim(label),step,probe,real(qc(i,k,j),real64),real(nc(i,k,j),real64), &
           transfer(qc(i,k,j),0_int32),transfer(nc(i,k,j),0_int32)
    endif
  endif
  close(unit,iostat=status)
  if (status/=0) error stop 'PR87 cycle log close failed'
end subroutine pr87_cloud_cycle

subroutine pr87_rain_public_store(q_internal, nvol_internal, dry_density, pidnr, power, &
                                  lambda_min, lambda_max, q_public, n_specific, valid, &
                                  delta_q, delta_n, adjustment)
  use iso_fortran_env, only: real32, real64
  use, intrinsic :: ieee_arithmetic, only: ieee_is_finite
  use cloud_bal_joint_transport, only: joint_moment_store
  implicit none
    ! Convert the KDM6 rain pair from public N-volume to specific N, then store
    ! both moments under the exact source-derived R32 volume-number contract.
    real(real32), intent(in) :: q_internal, nvol_internal, dry_density
    real(real32), intent(in) :: pidnr, power, lambda_min, lambda_max
    real(real32), intent(out) :: q_public, n_specific
    logical, intent(out) :: valid
    real(real64), intent(out) :: delta_q, delta_n
    integer, intent(out) :: adjustment

    real(real64) :: q64, n64, rho64, pid64, power64, lambda_min64, lambda_max64
    real(real64) :: minimum_ratio, maximum_ratio, volume_bounds(2)
    real(real64) :: qstored, nstored
    real(real32) :: stored_q, stored_n

    q_public = -1.0_real32
    n_specific = -1.0_real32
    valid = .false.
    delta_q = 0.0_real64
    delta_n = 0.0_real64
    adjustment = 0

    if (.not.all(ieee_is_finite([q_internal,nvol_internal,dry_density,pidnr,power, &
                                 lambda_min,lambda_max]))) return
    if (q_internal < 0.0_real32 .or. nvol_internal < 0.0_real32 .or. &
        dry_density <= 0.0_real32 .or. pidnr <= 0.0_real32 .or. &
        power <= 0.0_real32 .or. power > 8.0_real32 .or. &
        lambda_min <= 0.0_real32 .or. lambda_max < lambda_min) return

    rho64 = real(dry_density,real64)
    pid64 = real(pidnr,real64)
    power64 = real(power,real64)
    lambda_min64 = real(lambda_min,real64)
    lambda_max64 = real(lambda_max,real64)
    if (power64*log(lambda_min64) < log(real(tiny(0.0_real32),real64)) .or. &
        power64*log(lambda_max64) > log(real(huge(0.0_real32),real64))) return

    volume_bounds(1) = (rho64*lambda_min64**power64)/pid64
    volume_bounds(2) = (rho64*lambda_max64**power64)/pid64
    minimum_ratio = pid64/(lambda_max64**power64)
    maximum_ratio = pid64/(lambda_min64**power64)
    if (.not.all(ieee_is_finite([volume_bounds,minimum_ratio,maximum_ratio])) .or. &
        volume_bounds(1) <= 0.0_real64 .or. volume_bounds(2) < volume_bounds(1) .or. &
        volume_bounds(2) > real(huge(0.0_real32),real64) .or. &
        maximum_ratio < minimum_ratio) return

    q64 = real(q_internal,real64)
    n64 = real(nvol_internal,real64)/rho64
    call joint_moment_store(q64,n64,dry_density,minimum_ratio,maximum_ratio,.true., &
                            stored_q,stored_n,adjustment,valid, &
                            allow_normal_q_adjustment=.true., &
                            allow_joint_quantum_absence=.true., &
                            volume_number_bounds=volume_bounds)
    if (.not.valid) then
      adjustment = 0
      return
    end if

    q_public = stored_q
    n_specific = stored_n
    qstored = real(stored_q,real64)
    nstored = real(stored_n,real64)
    delta_q = qstored-q64
    delta_n = nstored-n64
end subroutine pr87_rain_public_store
