"""Add a read-only, one-cell graupel horizontal-diffusion probe to V24c."""

from __future__ import annotations

import hashlib


V24C_EM_SHA256 = "bf97496a1013b86ac0382fb9dfb22ad9e818af996d5bcb49bebcbdeec790f8b2"
_DIFFUSION_CALL = """CALL horizontal_diffusion ( 'm', scalar(ims,kms,jms,im),            &
                                            scalar_tends(ims,kms,jms,im), mut, &
                                            c1h, c2h, config_flags,            &
                                            msfux, msfuy, msfvx, msfvx_inv,    &
                                            msfvy, msftx, msfty,               &
                                            khdq , xkmhd, rdx, rdy,            &
                                            ids, ide, jds, jde, kds, kde,      &
                                            ims, ime, jms, jme, kms, kme,      &
                                            its, ite, jts, jte, kts, kte      )"""
_QIB_USE_ANCHOR = "p_qnr, p_qnc, tiedtkescheme"


def _probe(phase: str) -> str:
    return f"""           IF (rk_step == 1 .AND. config_flags%mp_physics == 37 .AND. &
               config_flags%diff_opt == 1 .AND. &
               ((moist_step .AND. im == P_QG) .OR. &
                (.NOT. moist_step .AND. im == P_QIB)) .AND. &
               8 >= its .AND. 8 <= ite .AND. 205 >= jts .AND. 205 <= jte .AND. &
               16 >= kts .AND. 16 <= kte .AND. 8 > ims .AND. 9 < ime .AND. &
               205 > jms .AND. 206 < jme) THEN
             WRITE(*,'(A,1X,5(I0,1X),2(L1,1X),*(1X,ES25.17E3))') &
                 'PR87_G_DIFFUSION_{phase}', rk_step, im, 8, 205, 16, &
                 moist_step, mix2_off, dt_step, khdq, &
                 scalar_tends(8,16,205,im), scalar(8,16,205,im), &
                 scalar(7,16,205,im), scalar(9,16,205,im), &
                 scalar(8,16,204,im), scalar(8,16,206,im), &
                 mut(8,205), mut(7,205), mut(9,205), mut(8,204), mut(8,206), &
                 c1h(16), c2h(16), &
                 xkmhd(8,16,205), xkmhd(7,16,205), xkmhd(9,16,205), &
                 xkmhd(8,16,204), xkmhd(8,16,206), &
                 msfux(7,205), msfux(8,205), msfux(9,205), &
                 msfuy(7,205), msfuy(8,205), msfuy(9,205), &
                 msfvx_inv(8,205), msfvx_inv(8,206), &
                 msfvy(8,205), msfvy(8,206), &
                 msftx(8,205), msfty(8,205), rdx, rdy
           END IF
"""


def extend_graupel_diffusion_probe(em: str) -> str:
    """Insert PRE/POST G-Q and G-B diffusion records; leave the call untouched."""
    actual = hashlib.sha256(em.encode("utf-8")).hexdigest()
    if actual != V24C_EM_SHA256:
        raise ValueError(f"unexpected V24c module_em source: {actual}")
    if em.count(_DIFFUSION_CALL) != 1:
        raise ValueError("expected exactly one pinned horizontal_diffusion call")
    if em.count(_QIB_USE_ANCHOR) != 1:
        raise ValueError("expected exactly one pinned state-description import anchor")

    result = em.replace(_QIB_USE_ANCHOR, "p_qnr, p_qnc, p_qib, tiedtkescheme", 1)
    result = result.replace(_DIFFUSION_CALL, _probe("PRE") + _DIFFUSION_CALL + "\n" + _probe("POST"), 1)
    if result.count(_DIFFUSION_CALL) != 1:
        raise ValueError("horizontal_diffusion call changed during probe insertion")
    if result.count("p_qnc, p_qib, tiedtkescheme") != 1:
        raise ValueError("P_QIB state-description import was not added exactly once")
    if result.count("'PR87_G_DIFFUSION_PRE'") != 1 or result.count("'PR87_G_DIFFUSION_POST'") != 1:
        raise ValueError("probe insertion did not produce one PRE and one POST record")
    return result
