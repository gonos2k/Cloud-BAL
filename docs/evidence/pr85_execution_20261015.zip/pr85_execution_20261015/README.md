# PR85 execution evidence

Final v17 matched OFF/COUPLED runs keep the original PR84 2026-08-16 13 UTC
Q/N/B inputs. Both complete the first full native KDM6 call and first
20-second model step with model exit 0. The independent closed-run audit is
PASS_SCOPED: original run receipts bind inputs, source/build/executable and
required traces, including PR67. Strict completed-stage density, pairedness,
PSD and number-conversion admission passes across 2,533,440 active cells per
arm. All 12 compared native pre/post fields bit-match the stage records.

The earlier v16 runs completed too, but their original receipts omitted PR67
from the trace inventory. Their overall audit remains INCOMPLETE_OR_FAIL.
The common collector was fixed and regression-tested, then v17 reran the same
physics with fresh build/run receipts. Original records are unchanged.

The full canonical suite passed on frozen v9. Final v16 focused physics
validation and v17 collector delta tests are separately hash-bound; the v9
suite does not validate every later source byte. Pinned Intel ifx 2026.0 O0
and true O2 component replays complete and have byte-identical post dumps.
Earlier nominal O2 checked-build records and caller-constant mismatches carry
explicit scope corrections, rather than being silently reclassified.

Source-bound local process decoding records actual 200-micrometre conversions:
7,065 OFF events and 7,066 COUPLED events, with one unrepresented positive
snow increment per arm. Cold/warm no-op predicates and column ledgers have
separate meanings and units. The cold source writer has two zero padding
columns omitted from its historic header; its schema addendum binds the
actual source offsets used by the decoder. Matching v17 ledger bytes permit
reuse of the validated arm-specific v16 diagnostics.

The research configuration uses one domain/rank/thread/tile and a preserved
partial-host build with eight replaced archive members. Selected first-order
air transport and deferred physical/settling packets change effective physics.
Native cutoff losses remain numerical terms. None of these results establish
global hybrid-carrier dry-mass/water/energy closure, independent observation
fit, native force/mass-wind acceptance, matched 10/30/60-minute response or
forecast efficacy. Overall physical approval remains FAIL_OPEN.

Full private model inputs, raw arrays, binaries and retained KDM baseline stay
outside Git and are referenced by hash. This compact bundle contains receipts,
audit code, logs and small diagnostic reports. bundle_source_map.json binds
each collected file to its original path, byte count and SHA-256; manifest.json
covers all bundle members. Final integration and package/publication receipts
live outside the ZIP to avoid recursive hash dependencies.
