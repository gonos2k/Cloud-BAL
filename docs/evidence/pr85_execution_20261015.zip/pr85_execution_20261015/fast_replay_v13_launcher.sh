#!/usr/bin/env bash
set -euo pipefail
if [[ $# != 2 ]]; then
  echo 'usage: run_fast_replay.sh NEW_SCRATCH_DIR CAPTURED_KDM6_PRETRACE.raw' >&2
  exit 2
fi
work=$(realpath -m "$1")
trace=$(realpath -e "$2")
[[ ! -e $work && ! -L $work ]] || { echo "scratch already exists: $work" >&2; exit 2; }
mkdir -p "$work"
root=/NHNHOME/WORKSPACE/26weather002_A/yhlee/KLAPS50/scratch/pr85_joint_moment_update_20261013/Cloud-BAL
candidate=/var/tmp/pr85_native_joint_candidate_20261015v13
source "$root/tests/intel_toolchain.sh"
export LD_LIBRARY_PATH=/NHNHOME/WORKSPACE/26weather002_A/Library/WRF_LIBS/lib:${LD_LIBRARY_PATH:-}
ulimit -s unlimited
cp "$(dirname "$0")/module_mp_kdm6_instrumented.f90" "$work/module_mp_kdm6_instrumented.f90"
cp "$(dirname "$0")/driver.f90" "$work/driver.f90"
cd "$work"
"$CLOUD_BAL_FC" "${CLOUD_BAL_FREE_FLAGS[@]}" -qopenmp -convert big_endian \
  -I"$candidate/kdm6_compile" -I/var/tmp/pr84_ice_entry_guard_final_1efgtcsn/compile \
  -I/var/tmp/pr61_ccn_origin_20261006/hostcopy/phys \
  -I/var/tmp/pr61_ccn_origin_20261006/hostcopy/frame \
  -c module_mp_kdm6_instrumented.f90 -o instrumented_kdm6.o >compile_kdm.log 2>&1
"$CLOUD_BAL_FC" "${CLOUD_BAL_FREE_FLAGS[@]}" -convert big_endian \
  -I"$candidate/kdm6_compile" -I/var/tmp/pr84_ice_entry_guard_final_1efgtcsn/compile \
  -I/var/tmp/pr61_ccn_origin_20261006/hostcopy/phys \
  -I/var/tmp/pr61_ccn_origin_20261006/hostcopy/frame \
  -c driver.f90 -o driver.o >compile_driver.log 2>&1
python3 - "$candidate/pr85_native_transport_build.json" "$candidate" "$work" <<'PY'
import json,pathlib,subprocess,sys
receipt=pathlib.Path(sys.argv[1]);candidate=pathlib.Path(sys.argv[2]);work=pathlib.Path(sys.argv[3])
a=list(json.loads(receipt.read_text())['link_argv'])
a[a.index('-o')+1]=str(work/'replay.exe')
remove={str(candidate/'link/main/wrf.o'),str(candidate/'link/main/module_wrf_top.o'),str(candidate/'compile/pr85_joint_stage_observer.o')}
a=[x for x in a if x not in remove]
archive=str(candidate/'link/main/libwrflib_pr85.a')
a.insert(a.index(archive),str(work/'driver.o'))
a.insert(a.index(archive),str(work/'instrumented_kdm6.o'))
with (work/'link.log').open('wb') as log:
    subprocess.run(a,cwd=work,check=True,stdout=log,stderr=subprocess.STDOUT)
PY
set +e
./replay.exe "$trace" >run.log 2>&1
rc=$?
set -e
if ! rg -q '^PR77_FIRST,KDM62D_SLOPE_04,rain,1,180,2,16,' pr77_native_species.raw; then
  echo "expected first SLOPE_04 capture missing (replay rc=$rc)" >&2
  exit 1
fi
printf 'REPLAY_FIRST_KDM6_FAILURE_REPRODUCED exit=%s\n' "$rc"
