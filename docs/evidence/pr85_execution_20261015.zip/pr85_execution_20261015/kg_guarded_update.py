#!/usr/bin/env python3
"""Guarded selected-path Graphify/KG update for PR85 joint moment update. External scratch utility; do not commit."""
from __future__ import annotations
import argparse, hashlib, importlib.metadata, importlib.util, json, os, re, shutil, stat, subprocess, sys, time
from datetime import date, datetime, timezone
from pathlib import Path

ROOT=Path('/NHNHOME/WORKSPACE/26weather002_A/yhlee/KLAPS50')
MAINT=ROOT/'Cloud-BAL'
SOURCE=ROOT/'scratch/pr85_joint_moment_update_20261013/Cloud-BAL'
OUT=MAINT/'scratch/pr85_joint_moment_update_20261015'
BASE='042e354c04f433abf90331276f5872fef7c93dd5'
PRIOR=MAINT/'scratch/pr84_ice_representation_20261013/kg_receipt.json'
PRIOR_SHA='3c10c7e34620359969f538aff10954747154ac03a2e8d7cf17152cdca96ac6e4'
PRIOR_ALIAS=SOURCE/'docs/evidence/pr84_kg_20261013.json'

OLD_AUDIT=MAINT/'scratch/pr59_team_audit_20261006'
OLD_PUBLISH=MAINT/'scratch/pr59_publish_kg_20261002'
PR='PENDING (supply actual PR85 URL with --pr-url)'
INTEGRATION_PATH='docs/evidence/pr85_integration_20261015.json'
HELPER=Path(__file__).resolve()
GRAPHIFY_PY=Path('/home/korea_keun/.local/share/uv/tools/graphifyy/bin/python3')
GRAPHIFY_CLI=Path('/home/korea_keun/.local/share/uv/tools/graphifyy/bin/graphify')

def sha_bytes(b:bytes)->str:return hashlib.sha256(b).hexdigest()
def sha(p:Path)->str:return sha_bytes(p.read_bytes())
def git(*args,cwd=SOURCE):return subprocess.check_output(['git',*args],cwd=cwd,text=True).rstrip()
def fail(msg):raise RuntimeError('guard failed: '+msg)
def regular_file(path:Path):
    if not stat.S_ISREG(path.lstat().st_mode):fail(f'non-regular selected artifact: {path}')
def reject_symlink_ancestors(path:Path):
    for part in (path,*path.parents):
        if part.is_symlink():fail(f'symlinked output component: {part}')

def guard_destination(path:Path,root:Path=ROOT):
    reject_symlink_ancestors(path)
    if not path.resolve().is_relative_to(root.resolve()):
        fail(f'destination escapes expected root {root}: {path}')
    if path.exists():regular_file(path)

def guard_directory(path:Path,root:Path=ROOT):
    reject_symlink_ancestors(path)
    if not path.resolve().is_relative_to(root.resolve()):
        fail(f'directory escapes expected root {root}: {path}')
    if not path.is_dir():fail(f'expected directory: {path}')

def copy_checked(source:Path,target:Path):
    guard_destination(source)
    guard_destination(target)
    source_hash=sha(source)
    shutil.copy2(source,target)
    regular_file(target)
    if sha(source)!=source_hash or sha(target)!=source_hash:
        fail(f'copy verification failed: {source} -> {target}')

def restore_automatic_snapshots(snapshots):
    for directory,members in snapshots.items():
        previous=Path(directory)
        guard_directory(previous)
        for created in previous.iterdir():
            guard_destination(created)
            if created.name not in members:created.unlink()
        for name,record in members.items():
            backup=Path(record['backup'])
            if sha(backup)!=record['sha256']:fail('prior automatic snapshot backup drift')
            copy_checked(backup,previous/name)
        if {p.name for p in previous.iterdir()}!=set(members):fail('prior snapshot membership changed')
        for name,record in members.items():
            if sha(previous/name)!=record['sha256']:fail('prior snapshot content changed')

def snapshot_path(path:Path,root:Path)->dict:
    relative=path.relative_to(root).as_posix()
    info=path.lstat()
    if stat.S_ISLNK(info.st_mode):
        return {'kind':'symlink','target':os.readlink(path)}
    if not stat.S_ISREG(info.st_mode):
        fail(f'non-regular active maintained path: {path}')
    return {'kind':'file','sha256':sha(path)}

def maintained_source_snapshot()->dict:
    """Hash active source/docs/config and tracked root files without traversing scratch trees."""
    allowed_wiki={"wiki/graph-report.md","wiki/graph-report-klaps50.md","wiki/graph-report-cloud-bal.md","wiki/index.md","wiki/log.md"}
    result={}
    for root in (ROOT,MAINT):
        root_git_dir=Path(git('rev-parse','--show-toplevel',cwd=root)).resolve()
        if not root.resolve().is_relative_to(root_git_dir):fail(f'maintained path escapes its Git root: {root}')
        for dirname in ('src','tests','docs','config'):
            base=root/dirname
            if not base.exists() and not base.is_symlink():continue
            if base.is_symlink():
                result[f'{root.name}/{dirname}']=snapshot_path(base,root)
                continue
            for current,dirs,files in os.walk(base,followlinks=False):
                current_path=Path(current)
                for name in list(dirs):
                    child=current_path/name
                    if name in {'scratch','worktrees','.git','graphify-out'}:
                        dirs.remove(name)
                        continue
                    if child.is_symlink():
                        result[f'{root.name}/{child.relative_to(root).as_posix()}']=snapshot_path(child,root)
                        dirs.remove(name)
                for name in files:
                    child=current_path/name
                    rel=child.relative_to(root).as_posix()
                    if root==ROOT and rel in allowed_wiki:continue
                    if child.is_symlink() or child.is_file():
                        result[f'{root.name}/{rel}']=snapshot_path(child,root)
        root_prefix=root.resolve().relative_to(root_git_dir).as_posix()
        # Include immediate tracked root files only; never recurse into scratch/worktrees.
        for child in root.iterdir():
            if not (child.is_file() or child.is_symlink()):continue
            rel=child.relative_to(root).as_posix()
            tracked_path=f'{root_prefix}/{rel}' if root_prefix!='.' else rel
            tracked=subprocess.run(['git','ls-files','--cached','--error-unmatch','--',tracked_path],cwd=root_git_dir,stdout=subprocess.DEVNULL,stderr=subprocess.DEVNULL,check=False)
            if tracked.returncode==0:
                result[f'{root.name}/{rel}']=snapshot_path(child,root)
    for path in sorted((p for p in MAINT.glob('wiki/*') if p.is_file() or p.is_symlink())):
        rel=path.relative_to(MAINT).as_posix()
        if rel in allowed_wiki:continue
        result[f'Cloud-BAL/{rel}']=snapshot_path(path,MAINT)
    return result

def show(commit,path):return subprocess.check_output(['git','show',f'{commit}:{path}'],cwd=SOURCE)

def make_plan(commit:str):
    os.environ['TZ']='Asia/Seoul'
    time.tzset()
    if date.today().isoformat()!='2026-10-15':fail('Graphify local snapshot day differs from declared session day')
    if importlib.metadata.version('graphifyy')!='0.9.53':fail('Graphify package must be exactly 0.9.53')
    if Path(sys.executable).resolve()!=GRAPHIFY_PY.resolve():fail('run through pinned Graphify Python')
    if Path(shutil.which('graphify') or '').resolve()!=GRAPHIFY_CLI.resolve():fail('pinned Graphify CLI must be first on PATH')
    if git('rev-parse','HEAD')!=commit:fail('candidate HEAD differs from requested frozen SHA')
    if git('status','--porcelain'):fail('candidate source worktree is not clean')
    subprocess.run(['git','merge-base','--is-ancestor',BASE,commit],cwd=SOURCE,check=True)
    changed=git('diff','--name-status','--find-renames',BASE,commit).splitlines()
    items=[]
    for row in changed:
        fields=row.split('\t')
        status=fields[0]
        if status not in ('A','M') or len(fields)!=2:fail(f'unsupported selected path change: {row}')
        rel=fields[1]
        if rel=='config/cp01_private_host_profile.json':fail('private profile cannot enter selected extraction')
        old=subprocess.run(['git','show',f'{BASE}:{rel}'],cwd=SOURCE,capture_output=True,check=False)
        oldbytes=old.stdout if old.returncode==0 else None
        candidate=SOURCE/rel
        reject_symlink_ancestors(candidate)
        if not candidate.resolve().is_relative_to(SOURCE.resolve()):fail(f'selected candidate escapes source root: {candidate}')
        regular_file(candidate)
        maintained=MAINT/rel
        guard_destination(maintained,MAINT)
        from graphify.extract import _get_extractor
        extractor_available=_get_extractor(candidate) is not None
        items.append({'path':rel,'change':status,'base_sha256':sha_bytes(oldbytes) if oldbytes is not None else None,
          'candidate_sha256':sha(candidate),'maintained_before_sha256':sha(maintained) if maintained.is_file() else None,
          'graphify_extraction':'AST_OR_MARKDOWN_HEADING' if extractor_available else 'NON_EXTRACTABLE_HASH_ONLY'})
    if not items:fail('no source paths changed since declared base')
    guard_destination(PRIOR);guard_destination(PRIOR_ALIAS)
    if sha(PRIOR)!=PRIOR_SHA:fail('latest maintained PR84 receipt hash drift')
    if sha(PRIOR_ALIAS)!=PRIOR_SHA:fail('candidate PR84 alias differs from maintained previous receipt')
    base_alias=subprocess.check_output(['git','show',f'{BASE}:docs/evidence/pr84_kg_20261013.json'],cwd=SOURCE)
    if sha_bytes(base_alias)!=PRIOR_SHA:fail('frozen BASE does not carry the exact preceding PR84 receipt alias')
    prior=json.loads(PRIOR.read_text())
    if prior.get('frozen_source_commit')!='ae038cfd7800923c7e7c24401231a30173bcd583':fail('previous PR84 receipt source identity mismatch')
    if prior.get('graphify_version')!='graphify 0.9.53':fail('previous receipt Graphify version mismatch')
    expected_graphs={
      'KLAPS50':{'snapshot':'2026-10-13-ice-representation','sha256':'004ec038867a6a1cb75d0630be378f7218136026b78c47a620a9222ae45cd842','nodes':35941,'edges':76674,'communities':2898},
      'Cloud-BAL':{'snapshot':'2026-10-13-ice-representation','sha256':'cedc22fcc6860660eee5ea62218985ed3cc7303d422f3d42c302d44af5e4448a','nodes':10113,'edges':18242,'communities':886},
    }
    for label,record in expected_graphs.items():
        prior_record=prior.get('corpora',{}).get(label,{})
        if any(prior_record.get(key)!=value for key,value in record.items() if key!='snapshot'):
            fail(f'{label} preceding receipt graph identity mismatch')
        directory=ROOT if label=='KLAPS50' else MAINT
        live=directory/'graphify-out/graph.json';guard_destination(live,directory)
        if sha(live)!=record['sha256']:fail(f'{label} live graph differs from the latest PR84 baseline')
        for name in ('graph.json','GRAPH_REPORT.md','manifest.json'):
            artifact=directory/'graphify-out/2026-10-13-ice-representation'/name;guard_destination(artifact,directory)
            expected=prior.get('dated_snapshots',{}).get(label,{}).get(name,{}).get('after_sha256')
            if not expected or sha(artifact)!=expected:fail(f'{label} latest dated PR84 snapshot drift: {name}')
        prior_record['snapshot']=record['snapshot']
    for rel,expected in prior.get('wiki_sha256',{}).items():
        path=ROOT/rel;guard_destination(path)
        if sha(path)!=expected:fail(f'wiki differs from latest PR84 receipt: {rel}')
    prior['corpora']=expected_graphs
    prior['prior_immutable_receipts']=prior.get('prior_immutable_receipts',{})
    immutable={PRIOR:PRIOR_SHA,PRIOR_ALIAS:PRIOR_SHA,
      OLD_PUBLISH/'update.py':'7c626b398f44a4013a607e2a5ae932528d2caaf41e37a479366aa80e0b146aa0',
      OLD_AUDIT/'update_kg.py':'bfe6242618e8ca1b60ab1304221d1fd215476d7f23281b69e48963611c0b76e1',
      OLD_AUDIT/'kg_receipt.json':'b07681e59678761ded5e1bd986ff0fe7f57cfb35a345f92ffc96b58424bab7ef',
      OLD_PUBLISH/'kg_receipt.json':'0e6ba4056e1edbcf542a35fe54c81fe88501245b63447324dd4c01c29655020a'}
    for p,h in immutable.items():
        guard_destination(p,Path('/var/tmp') if p.is_relative_to(Path('/var/tmp')) else ROOT)
        if sha(p)!=h:fail(f'previous helper/tool pin changed: {p}')
    for label,files in prior.get('dated_snapshots',{}).items():
        for name,record in files.items():
            artifact=Path(record['path']);guard_destination(artifact)
            if sha(artifact)!=record['after_sha256']:fail(f'previous immutable dated snapshot drift: {label}/{name}')
            immutable[artifact]=record['after_sha256']
    for path,expected in prior['prior_immutable_receipts'].items():
        previous_path=Path(path);guard_destination(previous_path,Path('/var/tmp') if previous_path.is_relative_to(Path('/var/tmp')) else ROOT)
        if sha(previous_path)!=expected:fail(f'previous immutable evidence drift: {path}')
        immutable[previous_path]=expected
    # Retain all 137 prior immutable pins and all dated graph artifacts.
    if len(prior['prior_immutable_receipts'])!=137:fail('previous PR84 receipt must preserve exactly 137 prior immutable pins')
    immutable[HELPER]=sha(HELPER)
    return items,prior,immutable

def find_validation_evidence(document:dict)->dict:
    found={'cp06a_real_scopes':[],'native_pair_errors':[]}
    def walk(value,path=()):
        if isinstance(value,dict):
            for key,item in value.items():
                next_path=path+(str(key),)
                normalized=' '.join(next_path).lower().replace('-','_')
                if 'scope' in normalized and ('real' in normalized or 'cp06a' in normalized):
                    found['cp06a_real_scopes'].append({'path':'.'.join(next_path),'value':item})
                elif 'native' in normalized and 'pair' in normalized and 'error' in normalized:
                    found['native_pair_errors'].append({'path':'.'.join(next_path),'value':item})
                elif isinstance(item,(dict,list)):walk(item,next_path)
        elif isinstance(value,list):
            for index,item in enumerate(value):
                if isinstance(item,(dict,list)):walk(item,path+(str(index),))
    walk(document)
    if not found['cp06a_real_scopes']:fail('validation receipt lacks CP06A real-scope evidence')
    if not found['native_pair_errors']:fail('validation receipt lacks native-pair error evidence')
    return found

def validation_summary(document:dict)->str:
    checks=document.get('checks')
    scoped=checks.get('scoped_unit') if isinstance(checks,dict) else None
    status=scoped.get('status') if isinstance(scoped,dict) else None
    if not isinstance(status,str) or not status.strip():
        fail('validation receipt must contain checks.scoped_unit.status')
    evidence=find_validation_evidence(document)
    rendered=json.dumps(evidence,sort_keys=True,separators=(',',':'),ensure_ascii=True)
    return f"CP06A scoped-unit status `{status.strip()}`; recorded real-scope and native-pair error fields {rendered}. Full details are in the bound validation receipt."


INHERITED_ACCEPTANCE_GATES=[
    "Whole host/thread FP policy beyond the selected single-thread cold start",
    "Joint Q/N/B validity during subsequent evolution beyond the validated first 20-second step",
    "PBL DEL versus native dry-carrier global budget connection",
    "Physical justification and broader validation of conditional freezing and transient QG/BG admission",
    "Water and energy closure",
]
OPEN_SAME_CANDIDATE_INTEGRATION_CONDITIONS=[
    "Independently justify observation/background covariance and validate observation fit",
    "Same-carrier dry-mass, water, and energy closure",
    "Spatial mass-wind compatibility at cells and shared faces after native initialization",
    "Physical compatibility after WPS/metgrid/real handoff",
    "Fixed-setting 10/30/60-minute response and independent observation signal preservation",
]

def load_validation_receipt(argument:str|None,items:list[dict],commit:str):
    if argument is None:return None
    relative=Path(argument)
    if relative.is_absolute() or ".." in relative.parts or not relative.parts:
        fail("validation receipt path must stay relative to the candidate source root")
    relative_text=relative.as_posix()
    source=SOURCE/relative
    reject_symlink_ancestors(source)
    if not source.resolve().is_relative_to(SOURCE.resolve()):
        fail("validation receipt escapes candidate source root")
    regular_file(source)
    selected=next((item for item in items if item["path"]==relative_text),None)
    if selected is None:
        fail("validation receipt must be a changed, selected path in the frozen source commit")
    digest=sha(source)
    if digest!=selected["candidate_sha256"]:
        fail("validation receipt hash differs from the selected frozen-source hash")
    committed=subprocess.check_output(["git","show",f"{commit}:{relative_text}"],cwd=SOURCE)
    if sha_bytes(committed)!=digest:
        fail("validation receipt bytes differ from the frozen commit")
    try:document=json.loads(source.read_text(encoding="utf-8"))
    except (UnicodeDecodeError,json.JSONDecodeError) as exc:
        fail(f"validation receipt is not valid UTF-8 JSON: {exc}")
    if not isinstance(document,dict):
        fail("validation receipt root must be a JSON object")
    checks=document.get("checks")
    summary=validation_summary(document)
    scoped=checks.get("scoped_unit") if isinstance(checks,dict) else None
    return {"path":relative_text,"sha256":digest,"source_commit":commit,
      "checks":{"scoped_unit":{"status":scoped['status']}},
      "cp06a_evidence":find_validation_evidence(document),'summary':summary}

def load_integration_receipt(items:list[dict],commit:str)->dict:
    """Bind current PR85 native statuses to the final committed integration receipt."""
    source=SOURCE/INTEGRATION_PATH
    reject_symlink_ancestors(source)
    if not source.resolve().is_relative_to(SOURCE.resolve()):
        fail('PR85 integration receipt escapes candidate source root')
    regular_file(source)
    selected=next((item for item in items if item['path']==INTEGRATION_PATH),None)
    if selected is None:
        fail('final PR85 integration receipt must be a changed, selected path in the frozen source commit')
    digest=sha(source)
    if digest!=selected['candidate_sha256']:
        fail('PR85 integration receipt hash differs from the selected frozen-source hash')
    committed=subprocess.check_output(['git','show',f'{commit}:{INTEGRATION_PATH}'],cwd=SOURCE)
    if sha_bytes(committed)!=digest:
        fail('PR85 integration receipt bytes differ from the frozen commit')
    try:
        document=json.loads(source.read_text(encoding='utf-8'))
    except (UnicodeDecodeError,json.JSONDecodeError) as exc:
        fail(f'PR85 integration receipt is not valid UTF-8 JSON: {exc}')
    if not isinstance(document,dict):
        fail('PR85 integration receipt root must be a JSON object')
    if document.get('schema')!='pr85_joint_moment_update_integration_v1':
        fail('PR85 integration receipt schema mismatch')
    if document.get('base_commit')!=BASE:
        fail('PR85 integration receipt base commit mismatch')
    for field in ('initialization','completed_air_updates','latest_actual_host',
                  'validation','candidate_scientific_gates'):
        if not isinstance(document.get(field),dict) or not document[field]:
            fail(f'PR85 integration receipt lacks status object: {field}')
    if document.get('physical_approval')!='FAIL_OPEN':
        fail('PR85 physical approval requires separate scientific acceptance evidence')
    embedded_commit=document.get('source_commit') or document.get('frozen_source_commit')
    if embedded_commit is not None and embedded_commit!=commit:
        fail('PR85 integration receipt identifies a different source commit')
    return {'path':INTEGRATION_PATH,'sha256':digest,'source_commit':commit,'document':document}


def main():
    ap=argparse.ArgumentParser(description=__doc__)
    ap.add_argument('--commit',required=True,help='exact clean frozen source commit SHA')
    ap.add_argument('--pr-url',default=None,help='PR URL once assigned; optional while the PR is pending')
    ap.add_argument('--validation-receipt',default=None,help='optional changed JSON receipt path relative to the candidate source root')
    mode=ap.add_mutually_exclusive_group(required=True)
    mode.add_argument('--check-only',action='store_true',help='read-only guard/preflight; never updates graphs/wiki')
    mode.add_argument('--apply',action='store_true',help='perform Graphify update and derived wiki sync')
    args=ap.parse_args()
    global PR
    PR=args.pr_url or PR
    if args.pr_url and not re.fullmatch(r'https://github\.com/gonos2k/Cloud-BAL/pull/85',args.pr_url):
        fail('--pr-url must be the actual Cloud-BAL pull-request URL')
    if args.apply and not args.pr_url:fail('apply requires the actual PR URL via --pr-url')
    items,prior,immutable=make_plan(args.commit)
    maintained_snapshot_verified=False
    maintained_before=maintained_source_snapshot()
    maintained_before_digest=sha_bytes(json.dumps(maintained_before,sort_keys=True,separators=(',',':')).encode())
    previous_source_snapshot=prior.get('maintained_source_snapshot',{})
    if len(maintained_before)!=627 or previous_source_snapshot.get('entry_count')!=627:
        fail('maintained source inventory must remain at the PR84-bound 627 entries')
    if maintained_before_digest!=previous_source_snapshot.get('before_sha256'):
        fail('maintained source inventory differs from the exact PR84-bound snapshot')
    validation=load_validation_receipt(args.validation_receipt,items,args.commit)
    integration=load_integration_receipt(items,args.commit)
    native_binding=integration
    pending_candidate_gates=integration['document'].get('candidate_scientific_gates',{})
    if args.check_only:
        print(json.dumps({'ready':True,'mode':'CHECK_ONLY_NO_WRITES','source':str(SOURCE),'commit':args.commit,'base':BASE,
          'selected_paths':items,'non_extractable_paths':[x['path'] for x in items if x['graphify_extraction']=='NON_EXTRACTABLE_HASH_ONLY'],'previous_receipt_sha256':PRIOR_SHA,
          'baseline_graphs':{k:{x:prior['corpora'][k][x] for x in ('snapshot','nodes','edges','communities','sha256')} for k in ('KLAPS50','Cloud-BAL')},
          'validation_receipt':validation,'native_receipt_binding':native_binding,'candidate_scientific_gates':pending_candidate_gates,'maintained_source_snapshot':{'entry_count':len(maintained_before),'symlink_entries':sum(v.get('kind')=='symlink' for v in maintained_before.values()),'before_sha256':maintained_before_digest,'sha256':maintained_before_digest,'verified_pre_post_equal':False},'new_output_path':str(OUT),'output_exists':OUT.exists()},indent=2));return
    # This output directory may contain only this external helper before the run.
    reject_symlink_ancestors(OUT)
    if OUT.exists() and set(p.name for p in OUT.iterdir())!={HELPER.name}:
        fail('new PR85 joint moment update output directory is not fresh; refuses overwrite')
    protected={}
    for rel in ('wiki/hot.md','wiki/overview.md'):
        p=ROOT/rel
        guard_destination(p)
        protected[rel]=sha(p)
    protected_dirs=('wiki/.schema','wiki/.schema-proposals','wiki/.research-queue','wiki/entities','wiki/concepts','wiki/sources','wiki/decisions',
      'wiki/heuristics','wiki/experiences','wiki/procedures','wiki/queries')
    for rel in protected_dirs:
        p=ROOT/rel
        if p.exists():
            guard_directory(p)
            files=sorted(x for x in p.rglob('*') if x.is_file())
            for f in files:guard_destination(f)
            entries=[(f.relative_to(ROOT).as_posix(),sha(f)) for f in files]
            protected[rel]=sha_bytes(json.dumps(entries,separators=(',',':')).encode())
    if protected!=prior.get('protected_content_before_sha256'):
        fail('protected wiki content differs from the preceding PR84 receipt')
    OUT.mkdir(parents=True,exist_ok=True)
    sys.path.insert(0,str(OLD_PUBLISH))
    import update as graph_update
    graph_update.SOURCE=SOURCE;graph_update.OUT=OUT;graph_update.BASE_COMMIT=BASE;graph_update.PR=PR
    graph_update.PATHS=tuple(x['path'] for x in items)
    spec=importlib.util.spec_from_file_location('pr59_audit_util',OLD_AUDIT/'update_kg.py')
    audit=importlib.util.module_from_spec(spec);sys.modules[spec.name]=audit;spec.loader.exec_module(audit)
    audit.ROOT=ROOT;audit.MAINTAINED=MAINT;audit.OUT=OUT;audit.PATHS=tuple(x['path'] for x in items)
    # Guard every destination the delegated Graphify/writer batch may create.
    for directory in (ROOT,MAINT):
        for rel in graph_update.GRAPH_FILES:
            guard_destination(directory/'graphify-out'/rel,directory)
        for name in ('graph.json','GRAPH_REPORT.md','manifest.json'):
            guard_destination(directory/'graphify-out/2026-10-15-joint-moment-update'/name,directory)
    for rel in graph_update.WIKI_FILES:guard_destination(ROOT/'wiki'/rel)
    before={label:json.loads((directory/'graphify-out/graph.json').read_text()) for label,directory in (('KLAPS50',ROOT),('Cloud-BAL',MAINT))}
    # Back up every graph/report/manifest and allowed wiki artifact before mutation.
    baseline_presence={}
    rollback_backup_sha256={}
    for label,directory in (('KLAPS50',ROOT),('Cloud-BAL',MAINT)):
        for rel in graph_update.GRAPH_FILES:
            p=directory/'graphify-out'/rel
            baseline_presence[str(p)]=p.exists()
            if p.exists():
                regular_file(p)
                target=OUT/'backups'/label/rel;target.parent.mkdir(parents=True,exist_ok=True);copy_checked(p,target)
                rollback_backup_sha256[str(target)]=sha(target)
    for rel in graph_update.WIKI_FILES:
        p=ROOT/'wiki'/rel
        baseline_presence[str(p)]=p.exists()
        if p.exists():
            regular_file(p)
            target=OUT/'backups/wiki'/rel;target.parent.mkdir(parents=True,exist_ok=True);copy_checked(p,target)
            rollback_backup_sha256[str(target)]=sha(target)
    dated_names=('graph.json','GRAPH_REPORT.md','manifest.json')
    dated_before={}
    for label,directory in (('KLAPS50',ROOT),('Cloud-BAL',MAINT)):
        dated_before[label]={}
        for name in dated_names:
            p=directory/'graphify-out/2026-10-15-joint-moment-update'/name
            target=OUT/'backups'/label/'dated_2026-10-15-joint-moment-update'/name
            target.parent.mkdir(parents=True,exist_ok=True)
            existed=p.exists()
            if existed:
                copy_checked(p,target)
                rollback_backup_sha256[str(target)]=sha(target)
            dated_before[label][name]={'path':str(p),'before_sha256':sha(p) if existed else None,'backup_path':str(target),'existed_before':existed}
    automatic_snapshot_backups={}
    for label,directory in (('KLAPS50',ROOT),('Cloud-BAL',MAINT)):
        previous=directory/'graphify-out/2026-10-15'
        if not previous.exists():
            continue
        guard_directory(previous,directory)
        members={}
        for original in sorted(previous.iterdir()):
            guard_destination(original,directory)
            backup=OUT/'backups'/label/'prior_auto_2026-10-15'/original.name
            backup.parent.mkdir(parents=True,exist_ok=True)
            copy_checked(original,backup)
            members[original.name]={'backup':str(backup),'sha256':sha(backup)}
        automatic_snapshot_backups[str(previous)]=members
    sync={'base_commit':BASE,'frozen_commit':args.commit,'paths':items}
    source_sync_path=OUT/'source_sync.json'
    guard_destination(source_sync_path)
    source_sync_path.write_text(json.dumps(sync,indent=2)+'\n')
    try:
        records={'KLAPS50':graph_update.update_graph('KLAPS50',ROOT,'Cloud-BAL',items),
                 'Cloud-BAL':graph_update.update_graph('Cloud-BAL',MAINT,'',items)}
        for label,directory in (('KLAPS50',ROOT),('Cloud-BAL',MAINT)):
            ext=json.loads((OUT/f'{label.lower().replace("-","_")}_extraction.json').read_text())
            audit.record_snapshot(label,directory,before[label],ext)
        # Preserve every old date-directory member, including hidden labels/analysis.
        restore_automatic_snapshots(automatic_snapshot_backups)
        private=audit.verify_private_profile(before)
        if private['Cloud-BAL']['nodes']!=134 or private['Cloud-BAL']['incident_links']!=133 or not private['Cloud-BAL']['unchanged'] or private['KLAPS50']['nodes']!=0:
            fail('private profile preservation guard failed')
        if git('rev-parse','HEAD')!=args.commit or git('status','--porcelain'):fail('source checkout changed during graph build')
        for x in items:
            if sha(SOURCE/x['path'])!=x['candidate_sha256']:fail(f'candidate source changed during build: {x["path"]}')
            p=MAINT/x['path'];guard_destination(p,MAINT);after=sha(p) if p.is_file() else None
            if after!=x['maintained_before_sha256']:fail(f'maintained source path changed: {x["path"]}')
        for label,r in records.items():
            r['previous_graph_sha256']=prior['corpora'][label]['sha256']
        for label,directory in (('KLAPS50',ROOT),('Cloud-BAL',MAINT)):
            report_path=directory/'graphify-out/GRAPH_REPORT.md'
            guard_destination(report_path,directory)
            old_report=report_path.read_text()
            new_section=(f"## Graph Freshness\n\n"
                f"- Selected candidate overlay: `{args.commit}` against `{BASE}`; "
                f"{len(items)} committed changed paths hash-bound, {sum(x['graphify_extraction']=='AST_OR_MARKDOWN_HEADING' for x in items)} structurally extractable.\n"
                f"- Non-extractable selected artifacts remain hash-bound in the receipt and are not parsed.\n"
                f"- Snapshot: {records[label]['snapshot']}. Maintained checkout HEAD is a separate base, "
                f"not the source identity of this selected extraction.\n"
                f"- The persistent graph combines earlier corpus snapshots and selected overlays. "
                f"This is not a full extraction of the candidate tree.\n"
                f"- AST/Markdown headings only; cross-file Fortran CALL extraction is partial. "
                f"Freshness is navigation evidence, not runtime/scientific validation.\n"
                f"- External source trees and runtime artifacts outside the selected repository paths are not represented.\n")
            new_report,count=re.subn(r"## Graph Freshness\n.*?(?=\n## |\Z)",new_section,old_report,flags=re.S)
            if count!=1:fail(f'{label} derived freshness section missing or duplicated')
            report_path.write_text(new_report)
        for label,directory in (('KLAPS50',ROOT),('Cloud-BAL',MAINT)):
            for name in dated_names:
                source=directory/'graphify-out'/name
                target=directory/'graphify-out/2026-10-15-joint-moment-update'/name
                guard_destination(target,directory)
                target.parent.mkdir(parents=True,exist_ok=True)
                copy_checked(source,target)
                dated_before[label][name]['after_sha256']=sha(target)
                if sha(source)!=sha(target):fail(f'{label} final dated copy differs: {name}')
        for label,directory in (('KLAPS50',ROOT),('Cloud-BAL',MAINT)):
            records[label]['snapshot']=datetime.fromtimestamp((directory/'graphify-out/GRAPH_REPORT.md').stat().st_mtime,timezone.utc).isoformat()
        copy_checked(ROOT/'graphify-out/GRAPH_REPORT.md',ROOT/'wiki/graph-report-klaps50.md')
        copy_checked(MAINT/'graphify-out/GRAPH_REPORT.md',ROOT/'wiki/graph-report-cloud-bal.md')
        idx=ROOT/'wiki/graph-report.md';lines=idx.read_text().splitlines()
        for i,line in enumerate(lines):
            for label,r in records.items():
                if line.startswith(f'| {label} |'):
                    folder='.' if label=='KLAPS50' else 'Cloud-BAL/';mirror='graph-report-klaps50' if label=='KLAPS50' else 'graph-report-cloud-bal'
                    lines[i]=f"| {label} | `{folder}` | {r['snapshot']} (PR85 joint moment update candidate overlay) | {r['nodes']} | {r['edges']} | {r['communities']} | [[{mirror}]] |"
        guard_destination(idx)
        idx.write_text('\n'.join(lines)+'\n')
        page=ROOT/'wiki/index.md';before_text=page.read_text();start=before_text.index('## Graph snapshot');end=before_text.find('\n## ',start+3);has_tail=end>=0
        if not has_tail:end=len(before_text)
        section='## Graph snapshot\n\n'
        for label,r in records.items():
            section+=(f"- {label}: {r['snapshot']}; {r['nodes']} nodes / {r['edges']} edges / {r['communities']} communities; "
              f"PR84 ice-representation baseline delta [{r['delta_nodes']}, {r['delta_edges']}].\n")
        section+='- [[graph-report|Separate corpus reports]] retain extraction limits. Graph freshness is navigation evidence only, not runtime or scientific validation.\n'
        after_text=before_text[:start]+section+before_text[end:]
        if before_text[:start]!=after_text[:start]:fail('index prefix changed outside Graph snapshot section')
        if has_tail:
            new_end=after_text.find('\n## ',after_text.index('## Graph snapshot')+3)
            if new_end<0 or before_text[end:]!=after_text[new_end:]:fail('index suffix changed outside Graph snapshot section')
        guard_destination(page)
        after_text=re.sub(r'(?m)^date_modified: .*$', 'date_modified: 2026-10-15', after_text, count=1)
        page.write_text(after_text)
        stamp=datetime.now(timezone.utc)
        log=ROOT/'wiki/log.md'
        entry=f"\n## [{stamp.strftime('%Y-%m-%d')}] kg-update | PR85 joint moment update selected-path overlay ({stamp.strftime('%H:%M UTC')})\n"
        entry+=f"- PR {PR}; frozen source commit `{args.commit}` against `{BASE}`. {len(items)} committed changed paths were hash-captured; {sum(x['graphify_extraction']=='AST_OR_MARKDOWN_HEADING' for x in items)} supported files were structurally extracted. Non-extractable selected artifacts are hash-only. Maintained source files were not copied or replaced.\n"
        for label,r in records.items():
            entry+=(f"- {label} snapshot {r['snapshot']}: {r['nodes']} nodes / {r['edges']} edges / {r['communities']} communities; "
              f"PR85 joint-moment-update overlay delta [{r['delta_nodes']}, {r['delta_edges']}], added/removed IDs {r['added_ids']}/{r['removed_ids']}; "
              f"previous graph SHA-256 `{r['previous_graph_sha256']}`.\n")
        entry+='- Cloud-BAL private profile remains 134 nodes / 133 incident links; KLAPS50 carries zero nodes from this private source. Graph integrity diagnostics passed.\n'
        entry+='- Graphify 0.9.53 selected-source AST/Markdown-heading extraction and separate `cluster-only --no-viz --no-label`; no semantic refresh. Fortran cross-file CALL extraction is partial; corpora overlap and counts are separate.\n'
        entry+=f"- Graph freshness is navigation-only; selected-source AST/Markdown headings have no semantic refresh, and cross-file Fortran CALL extraction is partial. Physical approval carries forward `{prior['physical_approval']}`.\n"
        entry+=f"- Durable preceding PR84 KG receipt: `{PRIOR.relative_to(ROOT)}` (SHA-256 `{PRIOR_SHA}`); its immutable prior-receipt chain remains pinned.\n"
        if validation:
            entry+=f"- Validation evidence: {validation['summary']} Receipt `{validation['path']}` SHA-256 `{validation['sha256']}` at `{args.commit}`.\n"
        else:
            entry+='- CP06A validation receipt not supplied; no new runtime-validation claims recorded.\n'
        entry+=f"- Overall physical approval remains `{prior['physical_approval']}`. PR85 native and scientific status fields are taken from the bound final integration receipt; graph freshness does not establish runtime or scientific acceptance.\n"
        entry+=f"- PR85 integration statuses are bound from `{INTEGRATION_PATH}` (SHA-256 `{integration['sha256']}`); graph freshness establishes no physical or scientific acceptance.\n"
        guard_destination(log)
        with log.open('a') as f:f.write(entry)
        for rel,expected in protected.items():
            p=ROOT/rel
            if p.is_file():
                guard_destination(p)
                if sha(p)!=expected:fail(f'protected wiki file changed: {rel}')
            else:
                guard_directory(p)
                files=sorted(x for x in p.rglob('*') if x.is_file())
                for q in files:guard_destination(q)
                rows=[(q.relative_to(ROOT).as_posix(),sha(q)) for q in files]
                if sha_bytes(json.dumps(rows,separators=(',',':')).encode())!=expected:fail(f'protected wiki directory changed: {rel}')
        maintained_after=maintained_source_snapshot()
        if maintained_after!=maintained_before:fail('maintained non-graph source, wiki content, profile, or prior receipt changed during Graphify refresh')
        maintained_snapshot_verified=True
        for p,h in immutable.items():
            if p!=HELPER:guard_destination(p,Path('/var/tmp') if p.parent==Path('/var/tmp') else ROOT)
            if sha(p)!=h:fail(f'prior immutable receipt changed: {p}')
        receipt={
          'schema':'pr85_joint_moment_update_selected_path_graphify_kg_receipt_v1','dated_snapshot_day':'2026-10-15','dated_snapshot_timezone':'Asia/Seoul (session day)','recorded_utc':datetime.now(timezone.utc).isoformat(),
          'pr':PR,'base_commit':BASE,'frozen_source_commit':args.commit,'source_path':str(SOURCE),'selected_path_count':len(items),
          'selected_paths':items,'non_extractable_selected_paths':[x['path'] for x in items if x['graphify_extraction']=='NON_EXTRACTABLE_HASH_ONLY'],'source_sync_sha256':sha(OUT/'source_sync.json'),
          'maintained_source_snapshot':{'verified_pre_post_equal':maintained_snapshot_verified,
            'entry_count':len(maintained_before),'symlink_entries':sum(v.get('kind')=='symlink' for v in maintained_before.values()),'before_sha256':maintained_before_digest,
            'scope':'active src/, tests/, docs/, config/ in KLAPS50 and Cloud-BAL; immediate tracked root files; remaining wiki content is separately protected by page/directory hashes',
            'excluded':'scratch/worktrees, .git, graphify-out, and the five intentionally refreshed derived wiki files (three graph reports, index.md, log.md)'},
          'previous_pr84_kg_receipt_sha256':PRIOR_SHA,
          'previous_pr84_kg_receipt_path':str(PRIOR),
          'previous_pr84_source_commit':prior['frozen_source_commit'],
          'previous_physical_approval':prior['physical_approval'],
          'physical_approval':prior['physical_approval'],
          'remaining_scientific_gates':prior.get('remaining_scientific_gates',[]),
          'remaining_acceptance_gates':INHERITED_ACCEPTANCE_GATES,
          'same_candidate_integration_conditions_open':OPEN_SAME_CANDIDATE_INTEGRATION_CONDITIONS,
          'validation_receipt_binding':validation,
          'native_receipt_binding':native_binding,
          'candidate_scientific_gates':pending_candidate_gates,
          'graphify_version':subprocess.check_output(['graphify','--version'],text=True).strip(),'python_executable':sys.executable,
          'mode':'guarded selected-path overlay extraction/build_merge, cluster-only, derived wiki sync',
          'extraction':'Graphify AST and Markdown headings only; no semantic/LLM refresh; unsupported/binary selected files are hash-bound but not parsed',
          'corpora':records,'private_profile_preservation':private,
          'dated_snapshots':dated_before,'dated_snapshot_directory':'2026-10-15-joint-moment-update',
          'automatic_snapshot_preservation':automatic_snapshot_backups,'baseline_artifact_presence':baseline_presence,
          'rollback_backup_sha256':rollback_backup_sha256,'protected_content_before_sha256':protected,
          'wiki':{'updated':['graph-report.md','graph-report-klaps50.md','graph-report-cloud-bal.md','index.md#Graph-snapshot','log.md (append-only)'],
            'protected_unchanged':list(protected),'schema_and_content_pages_touched':False},
          'prior_immutable_receipts':{str(p):h for p,h in immutable.items()},
          'limitations':['Graph counts are separate for overlapping KLAPS50 and Cloud-BAL corpora.','Markdown semantic extraction was not performed; Markdown contributes heading structure only.',
            'Fortran cross-file CALL extraction is partial.','External source trees and runtime artifacts outside selected repository paths are not represented.',
            'Candidate overlay graphs and freshness are structural navigation evidence, not runtime or scientific validation.',
            'Non-extractable or binary selected paths are recorded by SHA-256 and passed to the pinned Graphify extractor, which returns no extractor for their suffix; their contents are not parsed.',
            'The preceding PR84 receipt chain remains immutable; this structural update does not establish end-to-end runtime or scientific acceptance.']}
        receipt['wiki_sha256']={rel:sha(ROOT/rel) for rel in ('wiki/graph-report.md','wiki/graph-report-klaps50.md','wiki/graph-report-cloud-bal.md','wiki/index.md','wiki/log.md')}
        rp=OUT/'kg_receipt.json';guard_destination(rp);rp.write_text(json.dumps(receipt,indent=2,sort_keys=True)+'\n')
        print(json.dumps({'receipt':str(rp),'receipt_sha256':sha(rp),'corpora':records,'private_profile':private},indent=2))
    except BaseException:
        restore_automatic_snapshots(automatic_snapshot_backups)
        for label,directory in (('KLAPS50',ROOT),('Cloud-BAL',MAINT)):
            for rel in graph_update.GRAPH_FILES:
                b=OUT/'backups'/label/rel;t=directory/'graphify-out'/rel
                if b.exists():
                    if sha(b)!=rollback_backup_sha256[str(b)]:fail(f'rollback backup changed: {b}')
                    copy_checked(b,t)
                elif not baseline_presence.get(str(t),True) and t.exists():
                    guard_destination(t,directory);t.unlink()
        for label,directory in (('KLAPS50',ROOT),('Cloud-BAL',MAINT)):
            for name in dated_names:
                b=OUT/'backups'/label/'dated_2026-10-15-joint-moment-update'/name
                if b.exists():
                    if sha(b)!=rollback_backup_sha256[str(b)]:fail(f'rollback backup changed: {b}')
                    copy_checked(b,directory/'graphify-out/2026-10-15-joint-moment-update'/name)
                elif not dated_before[label][name]['existed_before']:
                    target=directory/'graphify-out/2026-10-15-joint-moment-update'/name
                    if target.exists():guard_destination(target,directory);target.unlink()
        for rel in graph_update.WIKI_FILES:
            b=OUT/'backups/wiki'/rel;t=ROOT/'wiki'/rel
            if b.exists():
                if sha(b)!=rollback_backup_sha256[str(b)]:fail(f'rollback backup changed: {b}')
                copy_checked(b,t)
            elif not baseline_presence.get(str(t),True) and t.exists():
                guard_destination(t);t.unlink()
        if maintained_source_snapshot()!=maintained_before:
            fail('rollback did not preserve maintained source/wiki/profile content')
        for pinned_path,pinned_sha in immutable.items():
            if sha(pinned_path)!=pinned_sha:fail(f'rollback changed an immutable prior receipt/source pin: {pinned_path}')
        if git('rev-parse','HEAD')!=args.commit or git('status','--porcelain'):
            fail('candidate source worktree changed during failed graph build')
        for selected in items:
            if sha(SOURCE/selected['path'])!=selected['candidate_sha256']:
                fail(f'candidate source bytes changed during failed graph build: {selected["path"]}')
        raise

if __name__=='__main__':main()
