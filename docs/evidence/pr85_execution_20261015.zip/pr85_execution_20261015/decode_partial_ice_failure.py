from pathlib import Path
import struct,numpy as np,json,hashlib
p=Path('/var/tmp/pr85_same13_OFF_joint_v11_20261015a/pr67_kdm6_process.raw')
raw=p.read_bytes(); before=hashlib.sha256(raw).hexdigest();o=0; rec=[]
for wanted in [0,1]:
 assert raw[o:o+8]==b'PR67P001';o+=8
 stage,lat,its,ite,kts,kte=struct.unpack_from('>6i',raw,o);o+=24
 dt=struct.unpack_from('>f',raw,o)[0];o+=4
 assert stage==wanted
 n=(ite-its+1)*(kte-kts+1);d={'stage':stage,'call_lat_index':lat,'bounds':[its,ite,kts,kte],'dt':dt,'data':{}}
 for name,kind in ([('rate','>f8'),('dz','>f4'),('rho','>f4'),('qi','>f4')] if stage==0 else [('qi','>f4'),('flux','>f4'),('fall','>f4')]):
  a=np.frombuffer(raw,dtype=kind,count=n,offset=o).reshape(kte-kts+1,ite-its+1);o+=n*np.dtype(kind).itemsize
  d['data'][name]=a
 rec.append(d)
assert o==len(raw) and hashlib.sha256(p.read_bytes()).hexdigest()==before
rows=[]
for k in range(6,11):
 x={'i':120,'call_lat_index':2,'k':k}
 for r in rec:
  for name,a in r['data'].items():x[f'{name}_stage{r["stage"]}']=float(a[k-kts,120-its])
 rows.append(x)
row9=next(r for r in rows if r['k']==9); row8=next(r for r in rows if r['k']==8)
ideal_rate=row9['rho_stage0']*row9['qi_stage0']*row9['rate_stage0']
ideal_receipt=ideal_rate*dt*row9['dz_stage0']/(row8['dz_stage0']*row8['rho_stage0'])
d={'schema':'pr85_partial_ice_process_failure_replay_v1','classification':'INCOMPLETE_PROCESS_CAPTURE_NOT_ACCEPTANCE','raw_path':str(p),'raw_sha256':before,'bytes':len(raw),'records':[{'stage':r['stage'],'call_lat_index':r['call_lat_index'],'bounds':r['bounds'],'dt':r['dt']} for r in rec], 'rows':rows,'ideal_mass_rate_kg_m3_s_before_mstep_division':ideal_rate,'incoming_dry_mixing_ratio_upper_bound_mstep_at_least_one':ideal_receipt,'stored_float32_incoming':float(np.float32(ideal_receipt)), 'minimum_positive_float32':float(np.nextafter(np.float32(0),np.float32(1))), 'limitations':['Only stages 0 and 1 of the first latitude slice are present; no stage 2 or completed-call budget.', 'NCI and number fall-rate arrays are not in this stream; the internal number witness is recorded separately in PR77.', 'The actual column mstep is not encoded. Using mstep=1 gives an upper bound; any valid larger integer only decreases the incoming packet, which is already below half the minimum positive REAL32.']}
print(json.dumps(d,indent=2))
