#!/usr/bin/env python3
"""Independent check of the PR85 v20i PSD boundary ledger.

This is a read-only decoder for one immutable partial replay. It reconstructs
species PID constants using the pinned source expressions and REAL32 operation
order, then recomputes the R64 lambda bounds and directed REAL32 endpoint.
It makes no integrated hydrometeor mass or accepted-run claim.
"""
from __future__ import annotations

import csv
import hashlib
import importlib.util
import json
import math
import re
from pathlib import Path
import struct
import sys
from collections import Counter, defaultdict

sys.dont_write_bytecode = True

SOURCE = Path('/var/tmp/pr85_kdm6_candidate_v20i_final_20261015/phys/module_mp_kdm6.F')
MANIFEST = Path('/var/tmp/pr85_kdm6_candidate_v20i_final_20261015/manifest.json')
RAW = Path('/var/tmp/pr85_kdm6_fast_replay_v20i_sourceonly_20261015a/pr85_kdm6_psd_boundary.raw')
RUN_DIR = RAW.parent
DRIVER = RUN_DIR / 'driver.f90'
EXIT_CODE = RUN_DIR / 'replay_exit_code.txt'
RUN_LOG = RUN_DIR / 'run.log'
CONSTANTS = Path('/NHNHOME/WORKSPACE/26weather002_A/yhlee/KLAPS/wrf_v4_8_kfarms_work/WRF-v4.8.0/share/module_model_constants.F')
TRANSITION = RUN_DIR / 'pr85_ice_transition_branch.raw'
TRANSITION_DECODER = Path('/var/tmp/pr85_kdm6_cold_ledger_decode_20261015_v3.py')
OUT = Path('/var/tmp/pr85_psd_boundary_v20i_report_20261015.json')
EXPECTED_MANIFEST = '525d06e789c222c76fbb4d2a108c5260d5421e87dcae2949030c2540fc34d9a2'
EXPECTED_SOURCE = '12cf8ebb06e6e0351774e5fd20852a536494f4442bac758b9948068b4bb6619b'
EXPECTED_RAW = '9653924d6bab8ab0e22116e8f984e77cb341c0747f9ea68eb1158731d8a98ada'


def sha256(path: Path) -> str:
    h = hashlib.sha256()
    with path.open('rb') as stream:
        for block in iter(lambda: stream.read(1024 * 1024), b''):
            h.update(block)
    return h.hexdigest()


def f32(value: float) -> float:
    return struct.unpack('<f', struct.pack('<f', value))[0]


def f32_bits(value: float) -> int:
    return struct.unpack('<I', struct.pack('<f', value))[0]


def f32_from_bits(value: int) -> float:
    return struct.unpack('<f', struct.pack('<I', value))[0]


def next_positive_f32(value: float, toward_positive: bool) -> float:
    if value <= 0.0 or not math.isfinite(value):
        raise ValueError('directed endpoint requires a finite positive REAL32')
    bits = f32_bits(value)
    return f32_from_bits(bits + (1 if toward_positive else -1))


def validate_source() -> dict[str, object]:
    source = SOURCE.read_text()
    compact = ''.join(source.lower().split())
    required = (
        'real,parameter,private::deni=500.',
        'real,parameter,private::mur=1.',
        'real,parameter,private::muc=2.',
        'real,parameter,private::mui=0.',
        'real,parameter,private::dmr=3.',
        'real,parameter,private::dmc=3.',
        'real,parameter,private::dmi=3.0',
        'pi=4.*atan(1.)',
        'cmc=pi*denr/6.',
        'cmr=pi*denr/6.',
        'cmi=pi*deni/6.',
        'pidnc=cmc*rgmma(1.+dmc/(muc+1.))',
        'pidnr=cmr*g1pdrmr/g1pmr',
        'pidni=cmi*g1pdimi/g1pmi',
        'exact_min=(rho64*lmin64**3)/pid64*q64',
        'exact_max=(rho64*lmax64**3)/pid64*q64',
        'if(side==1)then',
        'if(dble(rounded_bound)<exact_min)rounded_bound=nearest(rounded_bound,1.0)',
        'if(dble(rounded_bound)>exact_max)rounded_bound=nearest(rounded_bound,-1.0)',
        "write(ledger_unit,'(a,\",\",a,\",\",a,4(\",\",i0),1p,11(\",\",es24.16e3),\",\",l1)'",
        "'pr85_kdm6_psd_boundary',species,stage,cell_i,lat,k,side,",
    )
    missing = [token for token in required if token not in compact]
    if missing:
        raise ValueError(f'v20i source binding failed: {missing}')
    manifest = json.loads(MANIFEST.read_text())
    if manifest.get('applied_source_sha256') != EXPECTED_SOURCE:
        raise ValueError('manifest applied source hash mismatch')
    if sha256(SOURCE) != EXPECTED_SOURCE or sha256(MANIFEST) != EXPECTED_MANIFEST:
        raise ValueError('immutable v20i source or manifest hash mismatch')
    return {
        'source_path': str(SOURCE),
        'source_sha256': sha256(SOURCE),
        'manifest_path': str(MANIFEST),
        'manifest_sha256': sha256(MANIFEST),
        'source_contract': 'PR85 v20i source expressions for REAL32 species constants, R64 exact bounds, directed nearest REAL32 endpoint, and CSV field order verified.',
        'species_inputs': {
            'rhowater': '1000 REAL32 from module_model_constants.F, passed as denr by replay driver',
            'deni': '500 REAL32 private KDM6 parameter',
            'shape_parameters': {'dmr': 3, 'dmc': 3, 'dmi': 3, 'mur': 1, 'muc': 2, 'mui': 0},
            'source_pid_expressions': {
                'rain': 'cmr*Gamma(5)/Gamma(2)',
                'cloud': 'cmc*Gamma(2)',
                'ice': 'cmi*Gamma(4)/Gamma(1)',
            },
        },
    }


def species_pids() -> dict[str, float]:
    # Match the source's default REAL operation order: pi=4*atan(1), then
    # cm*=pi*density/6, then PID products. Integral Gamma values are exact.
    pi32 = f32(4.0 * f32(math.atan(1.0)))
    cmr32 = f32(f32(pi32 * f32(1000.0)) / f32(6.0))
    cmc32 = cmr32
    cmi32 = f32(f32(pi32 * f32(500.0)) / f32(6.0))
    return {
        'rain': f32(f32(cmr32 * f32(24.0)) / f32(1.0)),
        'cloud': f32(cmc32 * f32(1.0)),
        'ice': f32(f32(cmi32 * f32(6.0)) / f32(1.0)),
    }


def decode_boundary(pids: dict[str, float]) -> dict[str, object]:
    count = 0
    invalid: list[dict[str, object]] = []
    stats: dict[tuple[str, str, int], dict[str, float | int]] = defaultdict(lambda: {
        'rows': 0, 'native_outside_exact_cone': 0, 'directed_changed_native': 0,
        'nonzero_native_delta': 0, 'positive_storage_correction': 0,
        'negative_storage_correction': 0, 'max_abs_storage_correction': 0.0,
    })
    max_bound_error = {'min_abs': 0.0, 'max_abs': 0.0}
    native_formula_mismatches = 0
    directed_endpoint_mismatches = 0
    illegal_directed = 0
    native_delta_mismatches = 0
    storage_delta_mismatches = 0
    legacy_unavailable = 0

    with RAW.open(newline='') as stream:
        reader = csv.reader(stream, skipinitialspace=True)
        header = next(reader)
        if not header or not header[0].startswith('# PR85_KDM6_PSD_BOUNDARY species') or 'Ndirected;' not in ','.join(header):
            raise ValueError('PSD ledger header does not match v20i schema')
        for line_no, row in enumerate(reader, 2):
            if not row:
                continue
            if row[0].startswith('#'):
                continue
            if len(row) != 19 or row[0] != 'PR85_KDM6_PSD_BOUNDARY':
                invalid.append({'line': line_no, 'fields': len(row), 'tag': row[0]})
                continue
            try:
                species, stage = row[1], row[2]
                i, lat, k, side = map(int, row[3:7])
                if species not in pids or side not in (1, 2):
                    raise ValueError('unknown species or side')
                q, rho, lmin, lmax, nb, nn, nd, delta, correction, logged_min, logged_max = map(float, row[7:18])
                available_token = row[18].strip().upper()
                if available_token not in ('T', 'F'):
                    raise ValueError('bad legacy-available logical')
                available = available_token == 'T'
                vals = (q, rho, lmin, lmax, nb, nn, nd, delta, correction, logged_min, logged_max)
                if not all(math.isfinite(value) for value in vals):
                    raise ValueError('nonfinite row value')
                if q <= 0 or rho <= 0 or lmin <= 0 or lmax < lmin or nb < 0 or nd < 0:
                    raise ValueError('invalid physical input or negative moment')
            except (ValueError, OverflowError) as error:
                invalid.append({'line': line_no, 'error': str(error)})
                continue

            # Serialized q/rho/lambda values are REAL32; promote those values to
            # binary64 and follow the source's exact operation order.
            q64 = float(f32(q)); rho64 = float(f32(rho))
            lmin64 = float(f32(lmin)); lmax64 = float(f32(lmax))
            pid64 = float(pids[species])
            exact_min = (rho64 * lmin64 ** 3) / pid64 * q64
            exact_max = (rho64 * lmax64 ** 3) / pid64 * q64
            if exact_min != logged_min or exact_max != logged_max:
                # Values are emitted with 16 decimal digits; permit only round-trip
                # serialization noise, not a changed source formula or PID.
                if not (math.isclose(exact_min, logged_min, rel_tol=2e-15, abs_tol=0.0)
                        and math.isclose(exact_max, logged_max, rel_tol=2e-15, abs_tol=0.0)):
                    invalid.append({'line': line_no, 'error': 'independently recomputed R64 bounds differ from ledger'})
                    continue
            max_bound_error['min_abs'] = max(max_bound_error['min_abs'], abs(exact_min - logged_min))
            max_bound_error['max_abs'] = max(max_bound_error['max_abs'], abs(exact_max - logged_max))

            edge = exact_min if side == 1 else exact_max
            directed = f32(edge)
            if side == 1 and directed < edge:
                directed = next_positive_f32(directed, True)
            elif side == 2 and directed > edge:
                directed = next_positive_f32(directed, False)
            if f32_bits(directed) != f32_bits(nd):
                directed_endpoint_mismatches += 1
            if not (exact_min <= float(f32(nd)) <= exact_max):
                illegal_directed += 1

            lam = lmin64 if side == 1 else lmax64
            if available:
                # Independently emulate each default REAL intermediate in the
                # legacy source expression rho*q*lambda**exponent/pid.
                native_formula = f32(f32(f32(rho64 * q64) * f32(lam ** 3)) / pids[species])
                if f32_bits(native_formula) != f32_bits(nn):
                    native_formula_mismatches += 1
            else:
                legacy_unavailable += 1
                native_formula = None

            if available and nn - nb != delta:
                native_delta_mismatches += 1
            if nd - nn != correction:
                storage_delta_mismatches += 1

            key = (species, stage, side)
            group = stats[key]
            group['rows'] += 1
            if available and not (exact_min <= float(f32(nn)) <= exact_max):
                group['native_outside_exact_cone'] += 1
            if nd != nn:
                group['directed_changed_native'] += 1
            if delta != 0:
                group['nonzero_native_delta'] += 1
            if correction > 0:
                group['positive_storage_correction'] += 1
            elif correction < 0:
                group['negative_storage_correction'] += 1
            group['max_abs_storage_correction'] = max(float(group['max_abs_storage_correction']), abs(correction))
            count += 1

    return {
        'path': str(RAW),
        'sha256': sha256(RAW),
        'source_header': ','.join(header),
        'field_count': 19,
        'bytes': RAW.stat().st_size,
        'record_count': count,
        'invalid_record_count': len(invalid),
        'invalid_records': invalid[:20],
        'species_pid_real32': pids,
        'recomputed_exact_bound_max_abs_difference': max_bound_error,
        'independent_checks': {
            'directed_endpoint_bit_mismatches': directed_endpoint_mismatches,
            'directed_values_outside_exact_R64_cone': illegal_directed,
            'legacy_native_formula_bit_mismatches': native_formula_mismatches,
            'legacy_native_delta_mismatches': native_delta_mismatches,
            'directed_minus_native_storage_delta_mismatches': storage_delta_mismatches,
            'legacy_unavailable_rows': legacy_unavailable,
        },
        'by_species_stage_side': {
            f'{species}/{stage}/side{side}': values
            for (species, stage, side), values in sorted(stats.items())
        },
        'interpretation': {
            'exact_bound_equation': '(R64(rhoDry)*R64(lambda)**3)/R64(PID)*R64(Q)',
            'directed_endpoint': 'REAL32 ceil(Nmin) for side 1; REAL32 floor(Nmax) for side 2, including bitwise verification',
            'native_delta': 'legacy REAL32 expression result minus Nbefore, independently checked against native formula',
            'storage_correction': 'directed legal REAL32 endpoint minus legacy native result',
            'legality': 'every directed REAL32 number is checked against independently recomputed exact R64 [Nmin,Nmax]',
            'global_budget_claim': 'none; rows are per-cell local number-density adjustments, not integrated mass or domain closure',
        },
    }


def decode_transition_if_available() -> dict[str, object] | None:
    if not TRANSITION.is_file() or not TRANSITION_DECODER.is_file():
        return None
    spec = importlib.util.spec_from_file_location('pr85_ledger_v3', TRANSITION_DECODER)
    module = importlib.util.module_from_spec(spec)
    assert spec and spec.loader
    spec.loader.exec_module(module)
    source_binding = module.bind_source(SOURCE)
    return {
        'decoder_path': str(TRANSITION_DECODER),
        'decoder_sha256': sha256(TRANSITION_DECODER),
        'source_binding': source_binding,
        'transition_ledger': module.decode_transition(TRANSITION),
    }


def main() -> None:
    before = {str(p): sha256(p) for p in (SOURCE, MANIFEST, RAW, EXIT_CODE, RUN_LOG, DRIVER, CONSTANTS, TRANSITION)}
    if before[str(SOURCE)] != EXPECTED_SOURCE or before[str(MANIFEST)] != EXPECTED_MANIFEST or before[str(RAW)] != EXPECTED_RAW:
        raise SystemExit('immutable input hash mismatch')
    if EXIT_CODE.read_text().strip() != '128':
        raise SystemExit('partial replay exit status differs from expected RC128')
    source_info = validate_source()
    constants_text = CONSTANTS.read_text().lower()
    if not re.search(r'rhowater\s*=\s*1000\.', constants_text):
        raise SystemExit('module_model_constants does not bind denr/rhowater to 1000')
    pids = species_pids()
    result = {
        'decoder_path': str(Path(__file__).resolve()),
        'decoder_sha256': sha256(Path(__file__)),
        'scope': 'PARTIAL_CALL_NOT_ACCEPTED',
        'replay': {
            'exit_code': int(EXIT_CODE.read_text().strip()),
            'failure': 'KDM6 nongraupel admission search failed (RC128)',
            'run_log_tail': RUN_LOG.read_text(errors='replace').splitlines()[-1:],
            'driver_path': str(DRIVER),
            'driver_sha256': sha256(DRIVER),
            'constants_path': str(CONSTANTS),
            'constants_sha256': sha256(CONSTANTS),
        },
        'source_binding': source_info,
        'psd_boundary_ledger': decode_boundary(pids),
        'ice_transition_200um': decode_transition_if_available(),
        'limitations': [
            'Replay ended at the later nongraupel search failure and is not accepted as a complete call.',
            'PSD and transition rows are local state diagnostics; no kg-weighted domain closure is claimed.',
            'The 200um event count is read from explicit emitted event rows, never inferred from threshold candidates.',
        ],
    }
    after = {str(p): sha256(p) for p in (SOURCE, MANIFEST, RAW, EXIT_CODE, RUN_LOG, DRIVER, CONSTANTS, TRANSITION)}
    if before != after:
        raise SystemExit('one or more frozen inputs changed while decoding')
    result['frozen_input_sha256_pre_post_match'] = before
    OUT.write_text(json.dumps(result, indent=2, sort_keys=True) + '\n')
    print(json.dumps({'report': str(OUT), 'report_sha256': sha256(OUT),
                      'records': result['psd_boundary_ledger']['record_count'],
                      'boundary_checks': result['psd_boundary_ledger']['independent_checks'],
                      'ice_events': (result['ice_transition_200um'] or {}).get('transition_ledger', {}).get('event_count')}, sort_keys=True))


if __name__ == '__main__':
    main()
