#!/usr/bin/env python3
"""Bind closed v17 model-run ledgers to arm-specific validated v16 ledger hashes."""
import hashlib
import json
import os
from pathlib import Path

RUNTIME = Path('/var/tmp')
V17 = {
    'OFF': RUNTIME / 'pr85_same13_OFF_joint_v17_20261015a',
    'COUPLED': RUNTIME / 'pr85_same13_COUPLED_joint_v17_20261015a',
}
V16 = {
    'OFF': {
        'run': RUNTIME / 'pr85_same13_OFF_joint_v16_20261015a/pr83_same13_native_initialization.json',
        'binding': RUNTIME / 'pr85_kdm6_OFF_actual_v16_ledger_binding_20261015.json',
        'validated_receipt_sha256': '466646e08ea421566384a007b7cde07ec4d70218046186189a34c573d7249097',
    },
    'COUPLED': {
        'run': RUNTIME / 'pr85_same13_COUPLED_joint_v16_20261015a/pr83_same13_native_initialization.json',
        'binding': RUNTIME / 'pr85_kdm6_COUPLED_actual_v16_ledger_receipt_20261015.json',
        'validated_receipt_sha256': '11defb4ce25cd8f1213d6fae421bed6a00430581845a9209b34ee9f3d0350125',
    },
}
BUILD = {
    'v16': RUNTIME / 'pr85_native_joint_candidate_20261015v16/pr85_native_transport_build.json',
    'v17': RUNTIME / 'pr85_native_joint_candidate_20261015v17/pr85_native_transport_build.json',
}
OUTPUT = RUNTIME / 'pr85_kdm6_actual_v17_ledger_identity_binding_20261015_v2.json'
EXPECTED_V17_RECEIPTS = {
    'OFF': '65fe21132d20292d9a6e20209e42fa63d96e7680b9ed1e29d0b1b6ee1a187a3e',
    'COUPLED': '8dc7aa4c8b1cdffc72ab29da5a8db255ee96a271bb452fb5bd73a1e62f32d675',
}
EXPECTED_PR67 = {
    'OFF': {'bytes': 83442240, 'sha256': 'b0a4c23cf2f8c089168057276390f4d1f9ca6a27663bd849290f7e404b2b812e'},
    'COUPLED': {'bytes': 83442240, 'sha256': 'de494913c850b0bc477e3068b5e35ac931ac130e7536015fed045776e89a7c7f'},
}
COLLECTOR_DELTA_TEST_SHA256 = 'ab597f107b0307eabfd380a8e009f7c9064fd2693f343727bf4dc98fe9aa54bb'
LEDGER_NAMES = {
    'cold': 'pr85_kdm6_cold_budget.raw',
    'warm': 'pr85_kdm6_warm_budget.raw',
    'graupel': 'pr85_graupel_sedimentation_budget.raw',
    'ice': 'pr85_ice_sedimentation_budget.raw',
    'transition_200um': 'pr85_ice_transition_branch.raw',
}


def sha256(path):
    h = hashlib.sha256()
    with open(path, 'rb') as f:
        for block in iter(lambda: f.read(8 * 1024 * 1024), b''):
            h.update(block)
    return h.hexdigest()


def read_json(path):
    with open(path, encoding='utf-8') as f:
        return json.load(f)


def freeze_hash(path):
    p = Path(path)
    return {'path': str(p), 'bytes': p.stat().st_size, 'sha256': sha256(p)}


def require(condition, message):
    if not condition:
        raise SystemExit('FAIL: ' + message)


def trace_map(receipt):
    return receipt.get('native_trace_outputs', {})


def validated_v16_ledger_hashes(arm, run_receipt, validated):
    if arm == 'OFF':
        bindings = validated['ledger_byte_bindings']
        return {k: bindings[k]['actual_run_raw_sha256'] for k in LEDGER_NAMES}
    rows = validated['raw_ledgers']
    return {k: rows[k]['sha256_before_after_and_runner_receipt'] for k in LEDGER_NAMES}


def source_identity(build):
    key_hashes = {}
    for key, value in build.items():
        if key.endswith('_patch_sha256') or key in {
            'kernel_sha256', 'native_update_fragment_sha256',
            'source_attribution_source_sha256', 'pbl_capture_source_sha256',
            'observer_source_sha256', 'retained_pr84_archive_sha256',
            'retained_pr83_compile_receipt_sha256', 'parent_archive_sha256',
        }:
            key_hashes[key] = value
    kim = {k: v['sha256'] for k, v in build.get('retained_kim_sources', {}).items()}
    compiled_sources = {
        row['member']: {
            'source_sha256': row.get('source_sha256'),
            'generated_source_sha256': row.get('generated_source_sha256'),
        }
        for row in build.get('compiled_objects', [])
    }
    return {'patch_and_source_hashes': key_hashes,
            'retained_kim_source_hashes': kim,
            'compiled_source_hashes_by_member': compiled_sources}


require(not OUTPUT.exists(), f'output already exists; refusing overwrite: {OUTPUT}')
script_path = Path(__file__)
script_hash_before = sha256(script_path)

build16_path, build17_path = BUILD['v16'], BUILD['v17']
build16_digest, build17_digest = sha256(build16_path), sha256(build17_path)
b16, b17 = read_json(build16_path), read_json(build17_path)
require(b16['status'] == 'PASS_SCOPED_BUILD', 'v16 build is not PASS_SCOPED_BUILD')
require(b17['status'] == 'PASS_SCOPED_BUILD', 'v17 build is not PASS_SCOPED_BUILD')
id16, id17 = source_identity(b16), source_identity(b17)
require(id16 == id17, 'physical source/patch hashes differ between validated v16 and v17 builds')
require(b17['compiler_sha256'] == b16['compiler_sha256'], 'compiler binary differs')
require(b17['compiler_version'] == b16['compiler_version'], 'compiler version differs')
require(b17['compiler_profile_sha256'] == b16['compiler_profile_sha256'], 'compiler profile differs')

arm_results = {}
for arm, run_dir in V17.items():
    run_path = run_dir / 'pr83_same13_native_initialization.json'
    run = read_json(run_path)
    run_digest = sha256(run_path)
    require(run_digest == EXPECTED_V17_RECEIPTS[arm], f'{arm} run receipt digest differs from closure message')
    require(run.get('initialization_gate') == 'PASS_SCOPED_INITIALIZATION_READBACK', f'{arm} initialization gate failed')
    require(run.get('first_step_gate') == 'PASS', f'{arm} first-step gate failed')
    require(run.get('native_trace_output_integrity') == 'PASS', f'{arm} trace-integrity gate failed')
    require(not run.get('native_trace_output_issues'), f'{arm} receipt lists trace-integrity issues')
    require(run.get('artifact_class') == 'RESEARCH_DIAGNOSTIC', f'{arm} scope classification changed')

    build_binding = run['consumer_build_binding']
    require(run['native_executable_sha256'] == b17['candidate_executable_sha256'], f'{arm} run receipt executable differs from v17 build receipt')
    require(build_binding['candidate_executable_sha256'] == b17['candidate_executable_sha256'], f'{arm} embedded build executable differs')
    require(build_binding['candidate_archive_sha256'] == b17['candidate_archive_sha256'], f'{arm} embedded archive differs')
    require(sha256(b17['candidate_executable_path']) == b17['candidate_executable_sha256'], f'{arm} v17 executable on disk hash mismatch')
    require(sha256(b17['candidate_archive_path']) == b17['candidate_archive_sha256'], f'{arm} v17 archive on disk hash mismatch')

    manifest_path = run_dir / 'runtime_reference_manifest.json'
    manifest = read_json(manifest_path)
    manifest_hash = sha256(manifest_path)
    listed = manifest.get('input_inventory', [])
    require(isinstance(listed, list) and len(listed) > 0, f'{arm} runtime input inventory absent')
    runtime_external = {row['path']: row['sha256'] for row in manifest.get('external_runtime_inputs', [])}

    old_run = read_json(V16[arm]['run'])
    old_run_hash = sha256(V16[arm]['run'])
    require(old_run_hash == V16[arm]['validated_receipt_sha256'], f'{arm} v16 run receipt no longer matches validated receipt')
    old_validated = read_json(V16[arm]['binding'])
    expected_old = validated_v16_ledger_hashes(arm, old_run, old_validated)
    new_trace = trace_map(run)
    old_trace = trace_map(old_run)
    require(set(expected_old) == set(LEDGER_NAMES), f'{arm} v16 ledger validation does not name all five ledgers')
    ledger_bindings = {}
    for key, filename in LEDGER_NAMES.items():
        now = new_trace.get(filename)
        old = old_trace.get(filename)
        require(now is not None and old is not None, f'{arm} missing trace manifest entry for {filename}')
        require(now['sha256'] == expected_old[key], f'{arm} {key} digest differs from validated v16 arm')
        require(old['sha256'] == expected_old[key], f'{arm} v16 run receipt and validation disagree for {key}')
        raw_path = run_dir / filename
        require(raw_path.is_file() and raw_path.stat().st_size == now['bytes'], f'{arm} {filename} missing or byte size mismatch')
        ledger_bindings[key] = {
            'filename': filename,
            'v16_validated_sha256': expected_old[key],
            'v16_run_receipt_sha256': old['sha256'],
            'v17_run_receipt_sha256': now['sha256'],
            'v17_manifest_bytes': now['bytes'],
            'exact_receipt_hash_identity': True,
            'v17_raw_present_and_size_checked': True,
            'raw_content_independently_rehashed_in_this_binder': False,
        }

    pr67 = new_trace.get('pr67_kdm6_process.raw')
    require(pr67 == EXPECTED_PR67[arm], f'{arm} PR67 output inventory differs from expected closed receipt')
    require((run_dir / 'pr67_kdm6_process.raw').is_file(), f'{arm} PR67 trace is missing')
    require((run_dir / 'pr67_kdm6_process.raw').stat().st_size == pr67['bytes'], f'{arm} PR67 size mismatch')

    same_input_fields = [
        'candidate_wrfinput_sha256', 'candidate_wrfbdy_sha256',
        'native_namelist_effective_sha256', 'native_namelist_source_sha256',
        'initial_wrfo_sha256',
    ]
    old_inputs, new_inputs = {}, {}
    for key in same_input_fields:
        old_inputs[key] = old_run.get(key)
        new_inputs[key] = run.get(key)
        require(old_inputs[key] == new_inputs[key], f'{arm} run input identity differs for {key}')
    old_manifest_path = Path(V16[arm]['run']).parent / 'runtime_reference_manifest.json'
    old_manifest = read_json(old_manifest_path)
    require(old_manifest.get('base_archive_sha256') == manifest.get('base_archive_sha256'), f'{arm} runtime base archive differs')
    require(old_manifest.get('input_inventory') == listed, f'{arm} named runtime input inventory differs')
    require(old_manifest.get('external_runtime_inputs') == manifest.get('external_runtime_inputs'), f'{arm} external runtime library input hashes differ')

    arm_results[arm] = {
        'run_directory': str(run_dir),
        'run_receipt': freeze_hash(run_path),
        'runtime_reference_manifest': freeze_hash(manifest_path),
        'run_gates': {
            'initialization': run['initialization_gate'],
            'first_step': run['first_step_gate'],
            'trace_integrity': run['native_trace_output_integrity'],
            'issues': run.get('native_trace_output_issues', []),
            'scope': run['cold_start_scope_guard'],
        },
        'v17_build_binding': {
            'build_receipt': freeze_hash(build17_path),
            'build_status': b17['status'],
            'candidate_archive_path': b17['candidate_archive_path'],
            'candidate_archive_sha256': b17['candidate_archive_sha256'],
            'candidate_executable_path': b17['candidate_executable_path'],
            'candidate_executable_sha256': b17['candidate_executable_sha256'],
            'run_receipt_executable_sha256': run['native_executable_sha256'],
            'compiler_path': b17['compiler_path'],
            'compiler_sha256': b17['compiler_sha256'],
            'compiler_version': b17['compiler_version'],
            'compiler_profile_sha256': b17['compiler_profile_sha256'],
        },
        'physical_source_and_patch_identity': id17,
        'input_identity': {
            **new_inputs,
            'base_archive_sha256': manifest.get('base_archive_sha256'),
            'external_runtime_inputs': runtime_external,
            'named_runtime_input_inventory_count': len(listed),
            'named_runtime_input_inventory_sha256': hashlib.sha256(json.dumps(listed, separators=(',', ':'), ensure_ascii=False).encode()).hexdigest(),
        },
        'five_validated_ledger_bindings': ledger_bindings,
        'pr67_process_trace_inventory': {
            'path': str(run_dir / 'pr67_kdm6_process.raw'),
            'receipt_bytes': pr67['bytes'],
            'receipt_sha256': pr67['sha256'],
            'source_observer_sha256': b17.get('observer_source_sha256'),
            'observer_object_sha256': b17.get('observer_object_sha256'),
            'note': 'Included in run trace inventory and size-checked. Not decoded or used to make physical-budget claims in this binder.'
        },
        'pr67_collector_delta_validation_sha256': COLLECTOR_DELTA_TEST_SHA256,
        'other_selected_trace_outputs': {
            name: entry for name, entry in new_trace.items()
            if name in {'kdm6_first_call_pre.raw', 'kdm6_first_call_post.raw'}
        },
        'validated_v16_source_run_receipt': {
            'path': str(V16[arm]['run']),
            'sha256': old_run_hash,
            'ledger_validation_artifact': freeze_hash(V16[arm]['binding']),
        },
    }

# Recheck immutable inputs after building the report data.
require(sha256(script_path) == script_hash_before, 'binder code changed during execution')
require(sha256(build16_path) == build16_digest, 'v16 build receipt changed while binding')
require(sha256(build17_path) == build17_digest, 'v17 build receipt changed while binding')
for arm in V17:
    run_path = V17[arm] / 'pr83_same13_native_initialization.json'
    require(sha256(run_path) == arm_results[arm]['run_receipt']['sha256'], f'{arm} run receipt changed while binding')
    require(sha256(V17[arm] / 'runtime_reference_manifest.json') == arm_results[arm]['runtime_reference_manifest']['sha256'], f'{arm} runtime manifest changed while binding')

report = {
    'binder_script': freeze_hash(script_path),
    'schema': 'pr85_kdm6_actual_v17_ledger_identity_binding_v1',
    'status': 'PASS_EXACT_FIVE_LEDGER_HASH_IDENTITY',
    'created_utc_date': '2026-10-15',
    'scope': 'Closed v17 actual-run receipt, input/build/source identity, and exact five-ledger hash binding to previously validated same-arm v16 ledgers. No re-decode, no physical budgets, and no scientific/forecast claim.',
    'method': 'Each v17 run receipt reports PASS_SCOPED_INITIALIZATION_READBACK, first_step PASS, and trace integrity PASS. Its five ledger hashes are compared with both its v16 same-arm run receipt and the previously validated v16 ledger artifact. Runtime files are checked present and sizes match; bulk raw bytes are not rehashed or reparsed by this binder.',
    'v17_collector_delta_validation': {
        'status': 'PASS (root-supplied validation result)',
        'artifact_sha256': COLLECTOR_DELTA_TEST_SHA256,
        'effect': 'Confirms the v17 collector inventory includes PR67; exact per-arm PR67 raw bytes and hashes are independently recorded from the original run receipts below.'
    },
    'v16_to_v17_build_differences': {
        'same_physical_source_and_patch_hashes': True,
        'same_compiler_binary_version_and_profile': True,
        'candidate_executable_hash_equal_across_versions': b16['candidate_executable_sha256'] == b17['candidate_executable_sha256'],
        'v16_candidate_executable_sha256': b16['candidate_executable_sha256'],
        'v17_candidate_executable_sha256': b17['candidate_executable_sha256'],
        'candidate_archive_hash_equal_across_versions': b16['candidate_archive_sha256'] == b17['candidate_archive_sha256'],
        'v16_candidate_archive_sha256': b16['candidate_archive_sha256'],
        'v17_candidate_archive_sha256': b17['candidate_archive_sha256'],
        'build_path_differences_are_not_used_as_physics_identity': True,
        'note': 'v17 executable and archive are bound to their own build and run receipt; equality to the v16 executable is not required.'
    },
    'arms': arm_results,
}
with open(OUTPUT, 'x', encoding='utf-8') as f:
    json.dump(report, f, indent=2, sort_keys=True)
    f.write('\n')
os.chmod(OUTPUT, 0o444)
print(OUTPUT)
print('sha256', sha256(OUTPUT))
print('status', report['status'])
for arm, result in arm_results.items():
    print(arm, 'five ledgers exact; PR67', result['pr67_process_trace_inventory']['receipt_bytes'], result['pr67_process_trace_inventory']['receipt_sha256'])
