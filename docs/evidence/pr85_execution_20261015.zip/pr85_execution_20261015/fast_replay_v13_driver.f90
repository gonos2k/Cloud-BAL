program kdm6_firstcall_fulltile_replay
  use module_mp_kdm6, only: kdm6,kdm6init
  use module_mp_radar, only: xam_g
  implicit none
  integer :: b(20),ierr,n,ios,u,stage,timestep
  integer :: ids,ide,jds,jde,kds,kde,ims,ime,jms,jme,kms,kme,its,ite,jts,jte,kts,kte
  real :: params(5),dt,ccn,scale_h,land_mult,sea_mult
  real, allocatable, target :: state(:,:,:,:)
  real, pointer, contiguous :: th(:,:,:),pii(:,:,:),den(:,:,:),p(:,:,:),delz(:,:,:)
  real, pointer, contiguous :: q(:,:,:),qc(:,:,:),qr(:,:,:),qi(:,:,:),qs(:,:,:),qg(:,:,:)
  real, pointer, contiguous :: nn(:,:,:),nc(:,:,:),ni(:,:,:),nr(:,:,:),bg(:,:,:),diag_rhog(:,:,:)
  real, allocatable :: xland(:,:),rain(:,:),rainncv(:,:),snow(:,:),snowncv(:,:),sr(:,:),graupel(:,:),graupelncv(:,:)
  real, allocatable :: refl(:,:,:),re_cloud(:,:,:),re_ice(:,:,:),re_snow(:,:,:)
  character(len=8) :: name
  character(len=1024) :: input_path
  character(len=8), parameter :: expected(17)=[character(len=8) :: &
    'TH','PII','DEN','P','DELZ','Q','QC','QR','QI','QS','QG','NN','NC','NI','NR','BG','DIAGRHOG']
  call get_command_argument(1,input_path)
  if (len_trim(input_path)==0) error stop 'usage: replay.exe kdm6_first_call_pre.raw'
  open(newunit=u,file=trim(input_path),access='stream',form='unformatted',status='old',convert='big_endian')
  read(u) name
  if (name/='KDM6TRC1') error stop 'wrong raw trace signature'
  read(u) b
  stage=b(1);timestep=b(2)
  ids=b(3);ide=b(4);jds=b(5);jde=b(6);kds=b(7);kde=b(8)
  ims=b(9);ime=b(10);jms=b(11);jme=b(12);kms=b(13);kme=b(14)
  its=b(15);ite=b(16);jts=b(17);jte=b(18);kts=b(19);kte=b(20)
  read(u) params
  dt=params(1);ccn=params(2);scale_h=params(3);land_mult=params(4);sea_mult=params(5)
  if (stage/=1 .or. timestep<1) error stop 'expected first-call pre trace'
  allocate(state(ims:ime,kms:kme,jms:jme,17))
  do n=1,17
    read(u) name
    if (name/=expected(n)) then
      write(*,*) 'FIELD_ORDER',n,trim(expected(n)),trim(name)
      error stop 'raw field order mismatch'
    endif
    read(u) state(:,:,:,n)
  enddo
  read(u) name
  if (name/='XLAND') error stop 'expected XLAND field'
  allocate(xland(ims:ime,jms:jme));read(u)xland
  close(u)
  th=>state(:,:,:,1);pii=>state(:,:,:,2);den=>state(:,:,:,3);p=>state(:,:,:,4);delz=>state(:,:,:,5)
  q=>state(:,:,:,6);qc=>state(:,:,:,7);qr=>state(:,:,:,8);qi=>state(:,:,:,9);qs=>state(:,:,:,10);qg=>state(:,:,:,11)
  nn=>state(:,:,:,12);nc=>state(:,:,:,13);ni=>state(:,:,:,14);nr=>state(:,:,:,15);bg=>state(:,:,:,16);diag_rhog=>state(:,:,:,17)
  allocate(rain(ims:ime,jms:jme),rainncv(ims:ime,jms:jme),snow(ims:ime,jms:jme),snowncv(ims:ime,jms:jme))
  allocate(sr(ims:ime,jms:jme),graupel(ims:ime,jms:jme),graupelncv(ims:ime,jms:jme))
  allocate(refl(ims:ime,kms:kme,jms:jme),re_cloud(ims:ime,kms:kme,jms:jme),re_ice(ims:ime,kms:kme,jms:jme),re_snow(ims:ime,kms:kme,jms:jme))
  rain=0.;rainncv=0.;snow=0.;snowncv=0.;sr=0.;graupel=0.;graupelncv=0.
  refl=-777.;re_cloud=-777.;re_ice=-777.;re_snow=-777.
  xam_g=acos(-1.)*500./6.
  call kdm6init(1.28,1000.,100.,4190.,1846.4,0.,0,.true.)
  call kdm6(th=th,q=q,qc=qc,qr=qr,qi=qi,qs=qs,qg=qg,nn=nn,nc=nc,ni=ni,nr=nr,bg=bg,diag_rhog=diag_rhog, &
    den=den,pii=pii,p=p,delz=delz,delt=dt,g=9.81,cpd=1004.5,cpv=1846.4,ccn0=ccn,rd=287.04,rv=461.5,t0c=273.15, &
    ep1=.608,ep2=.622,qmin=1.e-12,xls=2.834e6,xlv0=2.5e6,xlf0=3.34e5,den0=1.28,denr=1000.,scale_h=scale_h, &
    qnn_land_mult=land_mult,qnn_sea_mult=sea_mult,ncmin_land=10.,ncmin_sea=10.,cliq=4190.,cice=1846.4,psat=610.78, &
    xland=xland,rain=rain,rainncv=rainncv,snow=snow,snowncv=snowncv,sr=sr,refl_10cm=refl,diagflag=.true., &
    do_radar_ref=1,graupel=graupel,graupelncv=graupelncv,itimestep=timestep,has_reqc=1,has_reqi=1,has_reqs=1, &
    re_cloud=re_cloud,re_ice=re_ice,re_snow=re_snow,ids=ids,ide=ide,jds=jds,jde=jde,kds=kds,kde=kde, &
    ims=ims,ime=ime,jms=jms,jme=jme,kms=kms,kme=kme,its=its,ite=ite,jts=jts,jte=jte,kts=kts,kte=kte)
  write(*,'(A)') 'REPLAY COMPLETED FULL FIRST KDM6 CALL'
end program
