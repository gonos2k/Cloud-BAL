#!/usr/bin/env python3
"""Streaming source-bound decoder for closed PR85 KDM6 k8b ledgers."""
from __future__ import annotations
import argparse, hashlib, json, math, re, statistics
from pathlib import Path

SOURCE=Path('/var/tmp/pr85_kdm6_candidate_sourcehold_v20k8b_20261015/source/phys/module_mp_kdm6.F')
SOURCE_SHA='b5e61526dc1e3d3384b9c87a423affc1cc2182faa18a904468114ec52b6781b8'
RATES=('pracw','piacw','pmulcs','pmulcg','pmulrs','pmulrg','prevp','psdep','pidep','pinud','psaut','psaci','nccol','nracw','niacw','ninud','nmulcs','nmulcg','nmulrs','nmulrg','nsaci','nsaut','nrcol','praut','nraut','paacw','naacw','pracs','praci','piacr','psacr','pgacr','pgdep','pgaci','pgaut','pgacs','nraci','niacr','nsacr','ngacr','ngaci')
WRATES=('praut','pracw','paacw','nraut','nccol','nracw','naacw','prevp','pseml','pgeml','psevp','pgacs','pgevp','nrcol','nseml','ngeml')
COLD_HEADER=('# PR85_KDM6_COLD fields: i,lat,k,loop,ngSearchStatus,autSearchStatus,gSearchStatus,compositeRetry,storedNoop; '
 'then dtcld,rhoDry,compositeGamma,scaledRates(41) REAL32,alphaNG,alphaAUT,alphaG; '
 'Qbefore(5),QafterNG_AUT(5),QGrequest(5),Qafter(5); Nbefore(3),NafterNG_AUT(3),NGrequest(3),Nafter(3); '
 'BGbefore,BGafterNG_AUT,BGrequest,BGafter; Tbefore,TafterNG_AUT,TGrequest,Tafter; '
 'QVbefore,QVafterNG_AUT,QVGrequest,QVafter; CCN3before,CCN3transfer,CCN3after; '
 'NG proposal/approved/withheld: Q(5),N(3),BG,T,QV; AUT proposal/approved/withheld: Q(5),N(3),BG,T,QV; '
 'G proposal/approved/withheld: Q(5),N(3),BG,T,QV; '
 'stored-minus-approved R32 residuals Q(5),N(3),CCN3,BG,T,QV; Q kg/kgdry, N #/m3, B m3/kgdry, QV kg/kgdry, T K')
WARM_HEADER=('# PR85_KDM6_WARM i,lat,k,loop,searchStatus,retry,progbStatus,rateNoop,stateNoop; '
 'retry 0=full helper fraction,1-32=adjacent REAL32 steps downward,33-56=halving; '
 'dtcld,rhoDry,cpm,xl,xlf,rhox,alpha; postcapPrimitiveRates(16),scaledREAL32PrimitiveRates(16); '
 'Qbefore(5),Qafter(5),Nbefore(3),Nafter(3),BGbefore,BGafter,Tbefore,Tafter,QVbefore,QVafter,CCN3before,CCN3after; '
 'requestedPostcapQ(5),requestedPostcapN(3),requestedBG,T,QV; admittedAlphaQ(5),N(3),BG,T,QV; '
 'storedDeltaQ(5),N(3),BG,T,QV; storedMinusAdmittedQ(5),N(3),BG,T,QV; '
 'units Q/QV kg/kgdry, N #/m3, B m3/kgdry, T K, rates per second')
G_HEADER='# PR85_G_SED: i,lat,substep,nlevels; proposed/approved/withheld Q kg m-2, B m3 m-2; ground sink Q/B; stored delta Q/B on local dend*delz basis; R32 residual Q/B'
ICE_HEADER='# PR85_ICE_SED: cell_i,lat,substep,nlevels; proposed/approved/withheld Q kg m-2, N # m-2; ground sink Q/N; stored delta Q/N on local dend*delz basis; R32 residual Q/N'
TRANS_HEADER='# PR85_ICE_TRANSITION: rows follow a per-loop KDM6 reach marker; event fields i,lat,k,loop,dtcld,Tbefore,Tafter,Dm,preQI,preQS,preNI,executedQI,removedQI, storedSnowGain,postQI,postQS,postNI'

class Stat:
 def __init__(self): self.n=0;self.nz=0;self.lo=None;self.hi=None;self.ma=0.;self.total=0.
 def add(self,x):
  self.n+=1;self.nz+=x!=0;self.lo=x if self.lo is None else min(self.lo,x);self.hi=x if self.hi is None else max(self.hi,x);self.ma=max(self.ma,abs(x));self.total+=x
 def out(self): return {'count':self.n,'nonzero':self.nz,'min':self.lo,'max':self.hi,'max_abs':self.ma,'mean':self.total/self.n if self.n else None}
def stats_dict(d): return {k:v.out() for k,v in d.items()}
def sha(p):
 h=hashlib.sha256()
 with p.open('rb') as f:
  for b in iter(lambda:f.read(1<<20),b''):h.update(b)
 return h.hexdigest()
def compact(s):return re.sub(r'[\s&]+','',re.sub(r'!.*$','',s,flags=re.M)).lower()
def source_contract():
 if sha(SOURCE)!=SOURCE_SHA:raise ValueError('immutable k8b source SHA mismatch')
 s=SOURCE.read_text(); c=compact(s)
 req=("write(pr85_cold_unit,'(a,8i8,1x,l1,1p,*(1x,e24.16))'","rain_composite_stored_noop,dtcld,dry_carrier_density(i,k),rain_composite_gamma,","rain_composite_rate_base*rain_composite_gamma,","write(pr85_warm_unit,'(a,7i8,1x,2l1,1p,*(1x,e24.16))'","rain_warm_rate_trial=rain_warm_alpha*rain_warm_rate_base","write(budget_unit,'(a,4i8,1p,12es24.16)'","'pr85_g_sed'","'pr85_ice_sed'","if(avedia(i,k,3).ge.200.e-6)then","pr85_trace_removed_qi=dble(pr85_trace_qi)-dble(qci(i,k,2))","pr85_trace_snow_gain=dble(qrs(i,k,2))-dble(pr85_trace_qs)")
 miss=[x for x in req if x.lower() not in c]
 if miss:raise ValueError(f'k8b source contract mismatch: {miss}')
 a=c.index('rain_composite_rate_base=[');b=c.index(']',a)
 if tuple(re.findall(r'([a-z0-9_]+)\(i,k\)',c[a:b]))!=RATES:raise ValueError('cold rate order changed')
 a=c.index('rain_warm_rate_base=[');b=c.index(']',a)
 if tuple(re.findall(r'([a-z0-9_]+)\(i,k\)',c[a:b]))!=WRATES:raise ValueError('warm rate order changed')
 return {'path':str(SOURCE),'sha256':SOURCE_SHA,'cold_format':'a,8i8,1x,l1,1p,*(1x,e24.16)','cold_reals':207,'cold_tokens':217,'warm_format':'a,7i8,1x,2l1,1p,*(1x,e24.16)','warm_reals':107,'warm_tokens':116,'sediment_format':'a,4i8,1p,12es24.16','cold_rate_order':RATES,'warm_rate_order':WRATES,'sediment_second_inventory_units':{'ICE':'number per area (#/m2)','G':'specific volume per area (m3/m2)'},'transition_binding':'source condition avedia(i,k,3)>=200 micrometres; source logs stored-state QI removal and QS gain'}
def finite_values(tokens,n,ctx):
 if len(tokens)!=n:raise ValueError(f'{ctx}: expected {n} reals; got {len(tokens)}')
 v=[float(x.replace('D','E').replace('d','e')) for x in tokens]
 if not all(math.isfinite(x) for x in v):raise ValueError(f'{ctx}: nonfinite real')
 return v
def need_header(got,expected,name):
 if got!=expected:raise ValueError(f'{name} header mismatch')
def path_hash_before(path):return sha(path)
def verify_unchanged(path,before):
 after=sha(path)
 if after!=before:raise ValueError(f'input changed while reading: {path}')
 return after

def decode_cold(path):
 before=path_hash_before(path); header=None; n=0; malformed=[]; statuses={}; source_noop=rate_zero=state_same=recomputed_noop=0; counts={'ratezero_statesame':0,'ratezero_statechanged':0,'ratenonzero_statesame':0,'source_flag_mismatch':0}
 ag={k:Stat() for k in ('gamma','alphaNG','alphaAUT','alphaG')}; residual={k:Stat() for k in [*(f'Q{i}' for i in range(1,6)),*(f'N{i}' for i in range(1,4)),'CCN3','BG','T','QV']}; rates={k:Stat() for k in RATES}
 packet={g:{s:{q:Stat() for q in ('Q','N','B','T','QV')} for s in ('request','approved','withheld')} for g in ('NG','AUT','G')}
 with path.open(errors='strict') as f:
  for ln,line in enumerate(f,1):
   line=line.rstrip('\n')
   if line.startswith('# PR85_KDM6_COLD'):header=line;continue
   if not line.startswith('PR85_KDM6_COLD'):continue
   t=line.split()
   try:
    if len(t)!=217:raise ValueError(f'token count {len(t)}')
    ids=[int(x) for x in t[1:9]]; flag=t[9]
    if flag not in ('T','F'):raise ValueError('bad stored-noop logical')
    v=finite_values(t[10:],207,f'line {ln}')
   except Exception as e:
    if len(malformed)<20:malformed.append({'line':ln,'error':str(e)})
    continue
   n+=1; source_noop+=flag=='T'; rz=all(x==0 for x in v[3:44]); rate_zero+=rz
   before_state=[*v[47:52],*v[67:70],v[79],v[83],v[87],v[91]]
   after_state=[*v[62:67],*v[76:79],v[82],v[86],v[90],v[93]]; ss=before_state==after_state;state_same+=ss
   counts['ratezero_statesame']+=rz and ss;counts['ratezero_statechanged']+=rz and not ss;counts['ratenonzero_statesame']+=(not rz) and ss
   ng=v[94:127];aut=v[127:160];gg=v[162:195]
   req_ng=any(x!=0 for x in (*ng[0:5],*ng[15:18],ng[24],ng[27],ng[30]))
   req_aut=any(x!=0 for x in (*aut[0:5],*aut[15:18]))
   req_g=any(x!=0 for x in (*gg[0:5],*gg[15:18],gg[24],gg[27],gg[30]))
   calc_noop=rz and ((v[44]>0 and req_ng) or (v[45]>0 and req_aut) or (v[46]>0 and req_g))
   recomputed_noop+=calc_noop;counts['source_flag_mismatch']+=(flag=='T')!=calc_noop
   for key,val in zip(('gamma','alphaNG','alphaAUT','alphaG'),(v[2],v[44],v[45],v[46])):ag[key].add(val)
   for name,val in zip(rates,v[3:44]):rates[name].add(val)
   for j,name in enumerate(residual):residual[name].add(v[195+j])
   sk=','.join(map(str,ids[4:7]));statuses[sk]=statuses.get(sk,0)+1
   for g,start,width in (('NG',94,33),('AUT',127,35),('G',162,33)):
    p=v[start:start+33]
    for si,stage in enumerate(('request','approved','withheld')):
     for x in p[si*5:si*5+5]:packet[g][stage]['Q'].add(x)
     for x in p[15+si*3:18+si*3]:packet[g][stage]['N'].add(x)
     packet[g][stage]['B'].add(p[24+si]);packet[g][stage]['T'].add(p[27+si]);packet[g][stage]['QV'].add(p[30+si])
 after=verify_unchanged(path,before);need_header(header,COLD_HEADER,'cold')
 if not n or malformed:raise ValueError(f'cold records malformed={len(malformed)}, accepted={n}, examples={malformed[:3]}')
 return {'path':str(path),'sha256_before_and_after':after,'header':header,'records':n,'status_counts_ng_aut_g':statuses,'stored_noop_source_flag_true':source_noop,'recomputed_group_source_noop':recomputed_noop,'all41_scaled_primitive_rates_zero':rate_zero,'tracked_final_state_numerically_equal_to_pre':state_same,**counts,'stored_minus_approved_R32_residuals':stats_dict(residual),'scaled_primitive_rate_stats':stats_dict(rates),'alpha_gamma_stats':stats_dict(ag),'packet_process_values':{g:{st:stats_dict(vals) for st,vals in groups.items()} for g,groups in packet.items()},'scope':'local unweighted fields; not global water or carrier conservation'}

def decode_warm(path):
 before=path_hash_before(path);header=None;n=0;bad=[];status={};retries={};rate_flag=state_flag=rate_zero=state_same=0; mismatch_r=mismatch_s=0
 residual={k:Stat() for k in [*(f'Q{i}' for i in range(1,6)),*(f'N{i}' for i in range(1,4)),'BG','T','QV']}; rates={k:Stat() for k in WRATES}; physical={k:Stat() for k in ('dt','rhoDry','cpm','xl','xlf','rhox','alpha')}
 with path.open(errors='strict') as f:
  for ln,line in enumerate(f,1):
   line=line.rstrip('\n')
   if line.startswith('# PR85_KDM6_WARM'):header=line;continue
   if not line.startswith('WARM'):continue
   t=line.split()
   try:
    if len(t)!=116:raise ValueError(f'token count {len(t)}')
    ids=[int(x) for x in t[1:8]];flags=t[8]
    if len(flags)!=2 or any(c not in 'TF' for c in flags):raise ValueError('bad adjacent logicals')
    v=finite_values(t[9:],107,f'line {ln}')
   except Exception as e:
    if len(bad)<20:bad.append({'line':ln,'error':str(e)})
    continue
   n+=1;status[str(ids[4])]=status.get(str(ids[4]),0)+1;retries[str(ids[5])]=retries.get(str(ids[5]),0)+1
   for k,x in zip(physical,v[:7]):physical[k].add(x)
   for k,x in zip(rates,v[23:39]):rates[k].add(x)
   rz=all(x==0 for x in v[23:39]);rate_zero+=rz;rf=flags[0]=='T';sf=flags[1]=='T';rate_flag+=rf;state_flag+=sf;mismatch_r+=rf!=rz
   # Native endpoint pairs begin after physical(7)+base16+trial16 = index 39.
   qb,qa=v[39:44],v[44:49];nb,na=v[49:52],v[52:55];bb,ba=v[55:57];tb,ta=v[57:59];vb,va=v[59:61];cb,ca=v[61:63]
   ss=[*qb,*nb,bb,tb,vb,cb]==[*qa,*na,ba,ta,va,ca];state_same+=ss;mismatch_s+=sf!=ss
   for j,k in enumerate(residual):residual[k].add(v[96+j])
 after=verify_unchanged(path,before);need_header(header,WARM_HEADER,'warm')
 if not n or bad:raise ValueError(f'warm records malformed={len(bad)}, accepted={n}, examples={bad[:3]}')
 return {'path':str(path),'sha256_before_and_after':after,'header':header,'records':n,'search_status_counts':status,'retry_index_counts':retries,'source_rateNoop_flag_true':rate_flag,'recomputed_all16_scaled_rates_zero':rate_zero,'source_stateNoop_flag_true':state_flag,'recomputed_tracked_endpoint_numerically_equal':state_same,'rateNoop_flag_mismatch_vs_recomputed':mismatch_r,'stateNoop_flag_mismatch_vs_recomputed':mismatch_s,'physical_parameters':stats_dict(physical),'scaled_primitive_rates':stats_dict(rates),'stored_minus_admitted_residuals':stats_dict(residual),'scope':'local unweighted states/rates; not global water or carrier conservation'}

def decode_sed(path,kind):
 before=path_hash_before(path);expected=G_HEADER if kind=='G' else ICE_HEADER;tag='PR85_G_SED' if kind=='G' else 'PR85_ICE_SED';header=None;n=0;bad=[];ids_unique=set();stats={k:Stat() for k in ('proposed_Q','approved_Q','withheld_Q','proposed_second','approved_second','withheld_second','ground_approved_Q','ground_approved_second','stored_delta_Q','stored_delta_second','Q_residual','second_residual')}
 with path.open(errors='strict') as f:
  for ln,line in enumerate(f,1):
   line=line.rstrip('\n')
   if line.startswith('# PR85_'+kind+'_SED'):header=line;continue
   if not line.startswith(tag):continue
   t=line.split()
   try:
    if len(t)!=17:raise ValueError(f'token count {len(t)}')
    ids=tuple(int(x) for x in t[1:5]);v=finite_values(t[5:],12,f'line {ln}')
   except Exception as e:
    if len(bad)<20:bad.append({'line':ln,'error':str(e)})
    continue
   n+=1;ids_unique.add(ids)
   for k,x in zip(stats,v):stats[k].add(x)
 after=verify_unchanged(path,before);need_header(header,expected,kind+' sediment')
 if not n or bad:raise ValueError(f'{kind} sediment malformed={len(bad)}, accepted={n}, examples={bad[:3]}')
 return {'path':str(path),'sha256_before_and_after':after,'header':header,'records':n,'unique_cell_substeps':len(ids_unique),'values':stats_dict(stats),'second_inventory_unit':'B m3/m2' if kind=='G' else 'N #/m2','scope':'column-local inventory/residual only'}

def decode_transition(path):
 before=path_hash_before(path);header=None;loops=events=transfer=0;stats={k:Stat() for k in ('diameter_m','QI_before','QI_after','QS_before','QS_after','NI_before','NI_after','QI_removed','serialized_QS_gain','stored_QI_delta','stored_QS_delta','stored_NI_delta','stored_pair_sum_delta','serialized_transfer_residual','stored_transfer_residual_R64')};bad=[];samples=[]
 with path.open(errors='strict') as f:
  for ln,line in enumerate(f,1):
   line=line.rstrip('\n')
   if line.startswith('# PR85_ICE_TRANSITION:'):header=line[2:].strip();continue
   if line.startswith('PR85_ICE_TRANSITION_LOOP'):loops+=1;continue
   if not line.startswith('PR85_ICE_TRANSITION'):continue
   t=line.split()
   try:
    if len(t)!=18:raise ValueError(f'token count {len(t)}')
    idx=[int(x) for x in t[1:5]];v=finite_values(t[5:],13,f'line {ln}')
   except Exception as e:
    if len(bad)<20:bad.append({'line':ln,'error':str(e)})
    continue
   events+=1;dt,tb,ta,d,qib,qsb,nib,qiexec,qirem,qsgain,qia,qsa,nia=v
   transfer+=qirem>0 and qsgain>0
   vals={'diameter_m':d,'QI_before':qib,'QI_after':qia,'QS_before':qsb,'QS_after':qsa,'NI_before':nib,'NI_after':nia,'QI_removed':qirem,'serialized_QS_gain':qsgain,'stored_QI_delta':qia-qib,'stored_QS_delta':qsa-qsb,'stored_NI_delta':nia-nib,'stored_pair_sum_delta':(qia+qsa)-(qib+qsb),'serialized_transfer_residual':qsgain-qirem,'stored_transfer_residual_R64':(qsa-qsb)-(qib-qia)}
   for k,x in vals.items():stats[k].add(x)
   if len(samples)<20:samples.append({'i':idx[0],'lat':idx[1],'k':idx[2],'loop':idx[3],'diameter_m':d,'QI_removed':qirem,'stored_QS_gain':qsa-qsb,'stored_pair_sum_delta':(qia+qsa)-(qib+qsb)})
 after=verify_unchanged(path,before);need_header('# '+header if header else None,TRANS_HEADER,'transition')
 if bad:raise ValueError(f'transition malformed: {bad[:3]}')
 return {'path':str(path),'sha256_before_and_after':after,'header':header,'loop_markers':loops,'event_count':events,'positive_transfer_event_count':transfer,'first_events':samples,'local_deltas':stats_dict(stats),'scope':'200-micrometre branch local unweighted states; not integrated physical mass'}

def main():
 p=argparse.ArgumentParser();p.add_argument('--closed-confirmed',action='store_true');p.add_argument('--arm',choices=('OFF','COUPLED'),required=True);p.add_argument('--runtime-dir',type=Path,required=True);p.add_argument('--run-receipt',type=Path,required=True);p.add_argument('--cold',type=Path);p.add_argument('--warm',type=Path);p.add_argument('--ice',type=Path);p.add_argument('--graupel',type=Path);p.add_argument('--transition',type=Path);p.add_argument('--out',type=Path,required=True)
 a=p.parse_args()
 if not a.closed_confirmed:p.error('require --closed-confirmed after runner closure')
 receipt_sha=sha(a.run_receipt);run_receipt=json.loads(a.run_receipt.read_text())
 if run_receipt.get('initialization_gate')!='PASS_SCOPED_INITIALIZATION_READBACK' or run_receipt.get('first_step_gate')!='PASS' or run_receipt.get('native_trace_output_integrity')!='PASS':
  raise ValueError('run receipt does not establish scoped initialization, first-step gate, and trace integrity')
 report={'schema':'pr85_kdm6_closed_ledgers_k8b_v3','source_contract':source_contract(),'inputs':{}}
 inputs=[('cold',a.cold,decode_cold),('warm',a.warm,decode_warm),('ice',a.ice,lambda x:decode_sed(x,'ICE')),('graupel',a.graupel,lambda x:decode_sed(x,'G')),('transition_200um',a.transition,decode_transition)]
 name_map={'cold':'pr85_kdm6_cold_budget.raw','warm':'pr85_kdm6_warm_budget.raw','ice':'pr85_ice_sedimentation_budget.raw','graupel':'pr85_graupel_sedimentation_budget.raw','transition_200um':'pr85_ice_transition_branch.raw'}
 for key,path,fn in inputs:
  if path:
   if path.name!=name_map[key]:raise ValueError(f'{key} input basename does not match source receipt')
   report['inputs'][key]=fn(path)
   expected=run_receipt.get('native_trace_outputs',{}).get(path.name,{}).get('sha256')
   if expected is None or report['inputs'][key]['sha256_before_and_after']!=expected:
    raise ValueError(f'{key} bytes do not match full-run receipt')
 report['execution']={'arm':a.arm,'runtime_dir':str(a.runtime_dir),'run_receipt':str(a.run_receipt),'run_receipt_sha256':receipt_sha,'initialization_gate':run_receipt['initialization_gate'],'first_step_gate':run_receipt['first_step_gate'],'native_trace_output_integrity':run_receipt['native_trace_output_integrity'],'native_executable_sha256':run_receipt.get('native_executable_sha256'),'scope':'Full run receipt reports initialized actual run with first-step gate PASS; this ledger report is limited to decoded local diagnostics and does not claim a forecast.'}
 report['replay_scope']='Closed full-run native ledger records bound by exact byte hashes to the actual run receipt; summary quantities remain local/unweighted.'
 a.out.write_text(json.dumps(report,indent=2,sort_keys=True)+'\n')
 print(json.dumps({'report':str(a.out),'report_sha256':sha(a.out),'decoder_sha256':sha(Path(__file__)),'source_sha256':SOURCE_SHA,'arm':a.arm,'counts':{k:v.get('records',v.get('event_count')) for k,v in report['inputs'].items()}},sort_keys=True))
if __name__=='__main__':main()
