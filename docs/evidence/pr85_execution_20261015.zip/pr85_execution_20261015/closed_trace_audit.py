#!/usr/bin/env python3
"""Offline PR85 closed-run audit: strict grouped-state parser plus native KDM6 bit-match.

This script is intentionally external to the source tree. It reads only completed run
artifacts, requires an explicit closed-run confirmation, and writes a hash-bound report.
"""
from __future__ import annotations

import argparse
import hashlib
import importlib
import json
import os
from pathlib import Path
import struct
import sys
from typing import Any

import numpy as np

STAGE_PARSER_SHA256 = "ebd89e3775036653d8da85557efccea92d68b8fb9ee120693b13604628876c3e"
NATIVE_PARSER_SHA256 = "6a33128956352a1298943dba338dd56b06c1d7ea818067edd8c797457a8dd77b"
BUILD_CONTRACT_SHA256 = "fc2bd25a0977b00c97d62c167a65c2d1d290c411b93cdc8cfbdba6d96dbefba2"
POLICY_SHA256 = "7f0176742d736c9dbe2be127f43eb00ed35ebda89f0b792a51220efb7d4d7e92"
PARENT_EXE_SHA256 = "4912d0f5c6b91d8e57bd0ff91adab2938ed4f74b9e8fa417903202dbf1c9d55a"
STATE_FIELDS = ("DEN", "Q", "QC", "QI", "QR", "QS", "QG", "NN", "NC", "NI", "NR", "BG")
ACTIVE_BOUNDS = ("its", "ite", "jts", "jte", "kts", "kte")
KDM_FIELD_NAMES = {name: name for name in STATE_FIELDS}
PROBE = (120, 2, 8)  # public (i,j,k); call_lat is separate metadata, never an array offset.


class AuditError(RuntimeError):
    pass


def sha256_bytes(data: bytes) -> str:
    return hashlib.sha256(data).hexdigest()


def sha256_file(path: Path) -> str:
    digest = hashlib.sha256()
    with path.open("rb") as stream:
        for block in iter(lambda: stream.read(1024 * 1024), b""):
            digest.update(block)
    return digest.hexdigest()


def regular_file_hash(path: Path) -> str:
    meta = path.lstat()
    if path.is_symlink() or not path.is_file():
        raise AuditError(f"not a regular non-symlink file: {path}")
    return sha256_file(path)


def stable_module_hash(path: Path, expected: str, label: str) -> str:
    actual = regular_file_hash(path)
    if actual != expected:
        raise AuditError(f"{label} changed: expected {expected}, found {actual}")
    return actual


def import_pinned_modules(cloud_bal: Path) -> tuple[Any, Any, Any]:
    tools = cloud_bal / "tools"
    stage_path = tools / "pr85_joint_stage_trace.py"
    native_path = tools / "native_kdm6_trace.py"
    build_path = tools / "pr85_consumer_build_contract.py"
    stable_module_hash(stage_path, STAGE_PARSER_SHA256, "stage parser")
    stable_module_hash(native_path, NATIVE_PARSER_SHA256, "native KDM6 parser")
    stable_module_hash(build_path, BUILD_CONTRACT_SHA256, "consumer build contract")
    policy_path = cloud_bal / "docs/PR84_NATIVE_MOMENT_POLICY_20261013.json"
    stable_module_hash(policy_path, POLICY_SHA256, "moment policy")
    sys.path.insert(0, str(tools))
    stage_parser = importlib.import_module("pr85_joint_stage_trace")
    native_parser = importlib.import_module("native_kdm6_trace")
    build_contract = importlib.import_module("pr85_consumer_build_contract")
    return stage_parser, native_parser, build_contract


def stable_parse(path: Path, parser: Any) -> tuple[Any, dict[str, Any]]:
    before = regular_file_hash(path)
    parsed = parser(path)
    after = regular_file_hash(path)
    if before != after:
        raise AuditError(f"artifact changed while read: {path}")
    return parsed, {"path": str(path.resolve()), "sha256": before, "bytes": path.stat().st_size}


def bounds_triplet(bounds: dict[str, int]) -> dict[str, list[int]]:
    return {
        "i": [int(bounds["its"]), int(bounds["ite"])],
        "j": [int(bounds["jts"]), int(bounds["jte"])],
        "k": [int(bounds["kts"]), int(bounds["kte"])],
    }


def _state_record(records: list[dict[str, Any]], label: str) -> dict[str, Any] | None:
    found = [record for record in records
             if record["kind"] == 1 and record["stage"] == label]
    return found[0] if len(found) == 1 else None


def _bitmatch(stage_record: dict[str, Any] | None, native_record: dict[str, Any] | None,
              stage_label: str, native_label: str) -> dict[str, Any]:
    if stage_record is None or native_record is None:
        return {"status": "INCOMPLETE", "reason": "required stage or native record missing"}
    if int(stage_record["timestep"]) != int(native_record["itimestep"]):
        return {"status": "FAIL", "reason": "stage/native timestep differs",
                "stage_timestep": int(stage_record["timestep"]),
                "native_timestep": int(native_record["itimestep"])}
    sb, nb = stage_record["bounds"], native_record["bounds"]
    if any(int(sb[key]) != int(nb[key]) for key in ACTIVE_BOUNDS):
        return {
            "status": "FAIL",
            "reason": "active coordinate bounds differ",
            "stage_active_bounds": bounds_triplet(sb),
            "native_active_bounds": bounds_triplet(nb),
        }
    fields: dict[str, Any] = {}
    mismatch_total = 0
    first_mismatch = None
    for name in STATE_FIELDS:
        left = np.ascontiguousarray(stage_record["fields"][name], dtype=np.dtype(">f4"))
        right = np.ascontiguousarray(native_record["fields"][KDM_FIELD_NAMES[name]],
                                     dtype=np.dtype(">f4"))
        if left.shape != right.shape:
            fields[name] = {"status": "FAIL", "reason": "array shape differs",
                            "stage_shape_jki": list(left.shape),
                            "native_shape_jki": list(right.shape)}
            mismatch_total += 1
            continue
        left_bits = left.view(np.dtype(">u4"))
        right_bits = right.view(np.dtype(">u4"))
        unequal = left_bits != right_bits
        count = int(unequal.sum())
        fields[name] = {"status": "PASS" if count == 0 else "FAIL",
                        "bit_mismatch_cells": count,
                        "stage_shape_jki": list(left.shape)}
        mismatch_total += count
        if count and first_mismatch is None:
            jloc, kloc, iloc = (int(x) for x in np.argwhere(unequal)[0])
            first_mismatch = {
                "field": name,
                "i": int(sb["its"]) + iloc,
                "j": int(sb["jts"]) + jloc,
                "k": int(sb["kts"]) + kloc,
                "call_lat_label": None,
                "stage_float32": float(left[jloc, kloc, iloc]),
                "native_float32": float(right[jloc, kloc, iloc]),
                "stage_bits": f"0x{int(left_bits[jloc, kloc, iloc]):08x}",
                "native_bits": f"0x{int(right_bits[jloc, kloc, iloc]):08x}",
            }
    return {
        "status": "PASS_BITMATCH" if mismatch_total == 0 else "FAIL",
        "stage": stage_label,
        "native_dump_stage": native_label,
        "active_bounds": bounds_triplet(sb),
        "coordinate_lookup": "For public (i,j,k), use array slot (j-jts,k-kts,i-its); call_lat_label is metadata only.",
        "fields": fields,
        "bit_mismatch_total": mismatch_total,
        "first_mismatch": first_mismatch,
    }


def _probe_values(record: dict[str, Any] | None, coordinates: tuple[int, int, int]) -> dict[str, Any]:
    if record is None:
        return {"status": "MISSING"}
    i, j, k = coordinates
    bounds = record["bounds"]
    if not (bounds["its"] <= i <= bounds["ite"] and
            bounds["jts"] <= j <= bounds["jte"] and
            bounds["kts"] <= k <= bounds["kte"]):
        return {"status": "OUTSIDE_SUPPORT", "coordinates_ijk": [i, j, k],
                "active_bounds": bounds_triplet(bounds)}
    # Do not use KDM6's call_lat argument to index the j axis.
    slots = (j - bounds["jts"], k - bounds["kts"], i - bounds["its"])
    values = {name: float(record["fields"][name][slots]) for name in STATE_FIELDS}
    return {"status": "READ", "coordinates_ijk": [i, j, k],
            "array_offsets_jki": list(slots), "call_lat_label_used_for_indexing": False,
            "values": values}


def _read_call_lat_label(run_dir: Path) -> dict[str, Any]:
    path = run_dir / "pr67_kdm6_process.raw"
    try:
        digest = regular_file_hash(path)
        with path.open("rb") as stream:
            header = stream.read(8 + 6 * 4 + 4)
        if len(header) != 36 or header[:8] != b"PR67P001":
            raise AuditError("missing/invalid first PR67 record header")
        stage, call_lat, its, ite, kts, kte = struct.unpack(">6i", header[8:32])
        dt = struct.unpack(">f", header[32:36])[0]
        if stage != 0:
            raise AuditError(f"first PR67 record is stage {stage}, expected pre-sedimentation stage 0")
        if its > ite or kts > kte or not np.isfinite(dt) or dt <= 0:
            raise AuditError("invalid PR67 call metadata")
        if regular_file_hash(path) != digest:
            raise AuditError("PR67 process trace changed while read")
        return {"status": "PASS_LABEL_ONLY", "path": str(path.resolve()), "sha256": digest,
                "call_lat_label": call_lat, "bounds_its_ite_kts_kte": [its, ite, kts, kte],
                "dt_s": float(dt),
                "meaning": "separate call metadata; it is not substituted for global j in array indexing"}
    except FileNotFoundError:
        return {"status": "MISSING", "path": str(path)}


def _native_pair(run_dir: Path, native_parser: Any) -> tuple[dict[str, Any], dict[str, Any] | None, dict[str, Any] | None]:
    pre_path = run_dir / "kdm6_first_call_pre.raw"
    post_path = run_dir / "kdm6_first_call_post.raw"
    report: dict[str, Any] = {"status": "INCOMPLETE", "pre": None, "post": None}
    pre = post = None
    try:
        pre, report["pre"] = stable_parse(pre_path, native_parser.read_dump)
        if pre["stage"] != 1:
            raise AuditError(f"native pre dump has stage={pre['stage']}, expected 1")
    except FileNotFoundError:
        report["pre"] = {"status": "MISSING", "path": str(pre_path)}
        return report, None, None
    except Exception as exc:
        report["pre"] = {"status": "ERROR", "path": str(pre_path), "error": str(exc)}
        return report, None, None
    try:
        post, report["post"] = stable_parse(post_path, native_parser.read_dump)
        if post["stage"] != 2:
            raise AuditError(f"native post dump has stage={post['stage']}, expected 2")
    except FileNotFoundError:
        report["post"] = {"status": "MISSING", "path": str(post_path)}
        report["pre"] = {"status": "PASS", **report["pre"]}
        report["status"] = "PRE_ONLY"
        return report, pre, None
    except Exception as exc:
        report["post"] = {"status": "ERROR", "path": str(post_path), "error": str(exc)}
        report["pre"] = {"status": "PASS", **report["pre"]}
        report["status"] = "PRE_ONLY"
        return report, pre, None
    report["pre"] = {"status": "PASS", **report["pre"]}
    report["post"] = {"status": "PASS", **report["post"]}
    same_header = pre["bounds"] == post["bounds"] and pre["params"] == post["params"] and \
                  pre["itimestep"] == post["itimestep"]
    report["pre_post_native_header_match"] = same_header
    report["status"] = "PASS_NATIVE_DUMPS" if same_header else "FAIL_NATIVE_HEADER"
    return report, pre, post


def _stage_result(trace: Path, stage_parser: Any, build_contract: Any,
                  build_receipt: Path | None) -> tuple[dict[str, Any], dict[str, Any] | None]:
    result: dict[str, Any] = {"input_path": str(trace), "strict_stage_coverage": None,
                              "strict_state_admission": None, "state_stage_sequence": None,
                              "completed_rk_sequence": None, "first_violation": None}
    if not trace.exists():
        result["status"] = "MISSING"
        return result, None
    try:
        trace_hash_before = regular_file_hash(trace)
        build_binding = {"status": "NOT_PROVIDED"}
        if build_receipt is not None:
            receipt_data = json.loads(build_receipt.read_text(encoding="utf-8"))
            expected_exe = Path(receipt_data["candidate_executable_path"])
            build_binding = build_contract.validate_consumer_build(
                build_receipt, expected_exe, PARENT_EXE_SHA256)
        kwargs = {}
        if build_receipt is not None:
            kwargs = {"build_receipt": build_receipt,
                      "expected_executable": expected_exe,
                      "expected_parent_executable_sha256": PARENT_EXE_SHA256}
        summary = stage_parser.summarize(trace, **kwargs)
        if regular_file_hash(trace) != trace_hash_before:
            raise AuditError("stage trace changed while parser summarized it")
        result.update({
            "status": "PARSED",
            "trace_sha256": trace_hash_before,
            "trace_bytes": trace.stat().st_size,
            "consumer_build_binding": build_binding,
            "strict_stage_coverage": summary["strict_stage_coverage"],
            "strict_state_admission": summary["strict_completed_state_admission"],
            "state_stage_sequence": summary["state_stage_sequence"],
            "completed_rk_sequence": summary["completed_rk_sequence"],
            "all_record_sequence": summary["all_record_sequence"],
            "first_violation": summary["earliest_observed_completed_state_violation"],
            "per_stage_metrics": summary["completed_state_summaries"],
            "kind2_tendency_metrics": summary["kind2_tendency_records"],
            "policy_path": summary["field_semantics"]["cone_policy_path"],
            "policy_sha256": summary["field_semantics"]["cone_policy_sha256"],
        })
        records = stage_parser.read_records(trace)["records"]
        if regular_file_hash(trace) != trace_hash_before:
            raise AuditError("stage trace changed while records were loaded")
        return result, {"records": records, "sha256": trace_hash_before}
    except Exception as exc:
        result["status"] = "ERROR"
        result["error"] = f"{type(exc).__name__}: {exc}"
        return result, None


def audit_arm(label: str, run_dir: Path, stage_parser: Any, native_parser: Any,
              build_contract: Any, build_receipt: Path | None) -> dict[str, Any]:
    if not run_dir.is_dir():
        raise AuditError(f"{label} run directory does not exist: {run_dir}")
    trace = run_dir / "pr85_joint_moment_stages.raw"
    stage_report, stage_data = _stage_result(trace, stage_parser, build_contract, build_receipt)
    native_report, native_pre, native_post = _native_pair(run_dir, native_parser)
    call_lat = _read_call_lat_label(run_dir)
    state_pre = _state_record(stage_data["records"], "PRE_KDM6") if stage_data else None
    state_post = _state_record(stage_data["records"], "POST_KDM6") if stage_data else None
    pre_match = _bitmatch(state_pre, native_pre, "PRE_KDM6", "kdm6_first_call_pre.raw")
    post_match = _bitmatch(state_post, native_post, "POST_KDM6", "kdm6_first_call_post.raw")
    for match in (pre_match, post_match):
        mismatch = match.get("first_mismatch")
        if mismatch is not None:
            mismatch["call_lat_label"] = call_lat.get("call_lat_label")
    stage_probe = {}
    if stage_data:
        for label_probe in ("PRE_RK", "RK_STAGE_END", "PRE_KDM6", "POST_KDM6"):
            rec = _state_record(stage_data["records"], label_probe)
            stage_probe[label_probe] = _probe_values(rec, PROBE)
    native_probe = {
        "PRE_KDM6": _probe_values(
            {"bounds": native_pre["bounds"], "fields": native_pre["fields"]}
            if native_pre else None, PROBE),
        "POST_KDM6": _probe_values(
            {"bounds": native_post["bounds"], "fields": native_post["fields"]}
            if native_post else None, PROBE),
    }
    return {
        "run_directory": str(run_dir.resolve()),
        "build_receipt": ({"path": str(build_receipt.resolve()),
                           "sha256": regular_file_hash(build_receipt)}
                          if build_receipt is not None else {"status": "NOT_PROVIDED"}),
        "stage_parser": stage_report,
        "native_kdm6_dump": native_report,
        "pr67_call_lat_label": call_lat,
        "native_dump_matches_stage": {
            "PRE_KDM6": pre_match,
            "POST_KDM6": post_match,
        },
        "probe_public_ijk": list(PROBE),
        "probe_stage_values": stage_probe,
        "probe_native_values": native_probe,
    }


def _canonical_sha256(value: dict[str, Any]) -> str:
    return sha256_bytes(json.dumps(value, sort_keys=True, separators=(",", ":"),
                                   allow_nan=False).encode("utf-8"))


def write_exclusive(path: Path, text: str) -> None:
    path = path.resolve()
    if path.exists() or path.is_symlink():
        raise FileExistsError(path)
    path.parent.mkdir(parents=True, exist_ok=True)
    with path.open("x", encoding="utf-8") as stream:
        stream.write(text)


def main() -> int:
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--cloud-bal", type=Path, required=True,
                        help="frozen Cloud-BAL source root supplying the pinned v11 parsers")
    parser.add_argument("--off-run", type=Path,
                        default=Path("/var/tmp/pr85_same13_OFF_joint_v13_20261015a"))
    parser.add_argument("--coupled-run", type=Path,
                        default=Path("/var/tmp/pr85_same13_COUPLED_joint_v13_20261015a"))
    parser.add_argument("--off-build-receipt", type=Path)
    parser.add_argument("--coupled-build-receipt", type=Path)
    parser.add_argument("--output", type=Path, required=True)
    parser.add_argument("--runs-closed-by-root", action="store_true",
                        help="required acknowledgement that both actual runs are closed")
    args = parser.parse_args()
    if not args.runs_closed_by_root:
        parser.error("refusing to inspect native artifacts without --runs-closed-by-root")
    try:
        cloud_bal = args.cloud_bal.resolve(strict=True)
        stage_parser, native_parser, build_contract = import_pinned_modules(cloud_bal)
        script_path = Path(__file__).resolve()
        script_sha = regular_file_hash(script_path)
        report: dict[str, Any] = {
            "schema": "pr85_closed_trace_audit_v1",
            "status": "INCOMPLETE",
            "scope": "closed-run full active-footprint audit; strict stage parser and native KDM6 bit-match are separate results",
            "base_commit": "042e354c04f433abf90331276f5872fef7c93dd5",
            "closed_run_acknowledgement": "explicit --runs-closed-by-root supplied",
            "code_bindings": {
                "audit_script_path": str(script_path),
                "audit_script_sha256": script_sha,
                "stage_parser_path": str(cloud_bal / "tools/pr85_joint_stage_trace.py"),
                "stage_parser_sha256": STAGE_PARSER_SHA256,
                "native_dump_parser_path": str(cloud_bal / "tools/native_kdm6_trace.py"),
                "native_dump_parser_sha256": NATIVE_PARSER_SHA256,
                "consumer_build_contract_path": str(cloud_bal / "tools/pr85_consumer_build_contract.py"),
                "consumer_build_contract_sha256": BUILD_CONTRACT_SHA256,
                "moment_policy_path": str(cloud_bal / "docs/PR84_NATIVE_MOMENT_POLICY_20261013.json"),
                "moment_policy_sha256": POLICY_SHA256,
            },
            "coordinate_convention": {
                "array_slot_for_public_i_j_k": "(j-jts, k-kts, i-its)",
                "call_lat": "reported as a separate PR67 call label; never used as the global j offset",
                "complete_pair_and_cone_checks": "delegated to the pinned strict stage parser for every recorded whole active-tile state",
                "cone_tolerance": "exact residuals are reported; admission threshold is eight float32 ULP per source bound",
            },
        }
        report["arms"] = {
            "OFF": audit_arm("OFF", args.off_run.resolve(), stage_parser, native_parser,
                             build_contract, args.off_build_receipt),
            "COUPLED": audit_arm("COUPLED", args.coupled_run.resolve(), stage_parser, native_parser,
                                 build_contract, args.coupled_build_receipt),
        }
        off = report["arms"]["OFF"]
        coupled = report["arms"]["COUPLED"]
        stage_pass = all(arm["stage_parser"].get("strict_stage_coverage", {}).get("status") == "PASS" and
                         arm["stage_parser"].get("strict_state_admission", {}).get("status") == "PASS"
                         for arm in (off, coupled))
        native_pass = all(arm["native_kdm6_dump"].get("status") == "PASS_NATIVE_DUMPS" and
                          arm["native_dump_matches_stage"]["PRE_KDM6"].get("status") == "PASS_BITMATCH" and
                          arm["native_dump_matches_stage"]["POST_KDM6"].get("status") == "PASS_BITMATCH"
                          for arm in (off, coupled))
        build_pass = all(arm["build_receipt"].get("sha256") for arm in (off, coupled))
        report["status"] = "PASS_SCOPED" if stage_pass and native_pass and build_pass else "INCOMPLETE_OR_FAIL"
        report["strict_stage_parser_status"] = "PASS" if stage_pass else "INCOMPLETE_OR_FAIL"
        report["direct_native_bitmatch_status"] = "PASS" if native_pass else "INCOMPLETE_OR_FAIL"
        report["build_receipt_presence_status"] = "PRESENT" if build_pass else "MISSING"
        payload_hash = _canonical_sha256(report)
        report["report_payload_sha256_before_self_binding"] = payload_hash
        encoded = json.dumps(report, indent=2, sort_keys=True, allow_nan=False) + "\n"
        output = args.output.resolve()
        write_exclusive(output, encoded)
        output_hash = regular_file_hash(output)
        sidecar = output.with_suffix(output.suffix + ".sha256")
        write_exclusive(sidecar, f"{output_hash}  {output.name}\n")
        print(json.dumps({"report_path": str(output), "report_sha256": output_hash,
                          "sidecar_path": str(sidecar), "script_sha256": script_sha},
                         sort_keys=True))
        return 0 if report["status"] == "PASS_SCOPED" else 2
    except Exception as exc:
        parser.error(f"{type(exc).__name__}: {exc}")
    return 2


if __name__ == "__main__":
    raise SystemExit(main())

