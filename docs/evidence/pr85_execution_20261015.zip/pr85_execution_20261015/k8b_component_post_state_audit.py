#!/usr/bin/env python3
"""Strict stored-state readback of the closed k8b OFF component call."""
import hashlib
import json
from pathlib import Path
import sys
import numpy as np
ROOT=Path('/var/tmp/pr85_frozen_validation_20261015_v16/Cloud-BAL')
RUN=Path('/var/tmp/pr85_kdm6_fast_replay_v20k8b_20261015a')
OUT=Path('/var/tmp/pr85_component_post_state_audit_k8b_20261015.json')
def sha(path):
    h=hashlib.sha256()
    with path.open('rb') as f:
        for b in iter(lambda:f.read(1048576),b''):h.update(b)
    return h.hexdigest()
assert not OUT.exists()
assert (RUN/'run.rc').read_text().strip()=='0'
assert sha(ROOT/'tools/pr85_joint_stage_trace.py')=='5c2e9ccb3537a6bc251845e2b87c3efb991002ebbc1db5232d475e29f6c31720'
assert sha(ROOT/'tools/native_kdm6_trace.py')=='6a33128956352a1298943dba338dd56b06c1d7ea818067edd8c797457a8dd77b'
sys.dont_write_bytecode=True
sys.path.insert(0,str(ROOT/'tools'))
import native_kdm6_trace as native
import pr85_joint_stage_trace as state
path=RUN/'kdm6_first_call_post.raw'; before=sha(path); post=native.read_dump(path); assert post['stage']==2
fields=post['fields']; policy=state._load_policy()
scalars={name:state._stats(fields[name]) for name in state.STATE_FIELDS}
pairs=state._pair_stats(fields,policy)
conversions=state._conversion_stats(fields,'AUTHORITATIVE_DRY_FROM_AL_ALB')
caps=state._entry_caps(fields,policy,'AUTHORITATIVE_DRY_FROM_AL_ALB')
positive={name:bool(np.all(np.isfinite(fields[name]) & (fields[name]>0))) for name in ('DEN','TH','PII','P','DELZ')}
assert sha(path)==before
fail=[]
for name,s in scalars.items():
    if s['negative'] or s['nonfinite']:fail.append('invalid scalar '+name)
for name,s in pairs.items():
    if any(s[k] for k in ('positive_mass_zero_moment','positive_moment_zero_mass','negative_mass','negative_moment','nonfinite_mass_or_moment')) or s['feasible_cone']['outside_beyond_8_float32_ulp_cells']:fail.append('invalid pair '+name)
if not all(positive.values()):fail.append('nonpositive thermodynamics')
report={'schema':'pr85_closed_component_post_state_v1','status':'PASS_SCOPED_STATE' if not fail else 'FAIL_STATE','source_sha256':'b5e61526dc1e3d3384b9c87a423affc1cc2182faa18a904468114ec52b6781b8','post_path':str(path),'post_sha256':before,'run_rc_sha256':sha(RUN/'run.rc'),'audit_script_sha256':sha(Path(__file__)),'bounds':post['bounds'],'cell_count':int(fields['Q'].size),'scalar_stats':scalars,'pairs':pairs,'conversions':conversions,'entry_caps':caps,'positive_thermodynamic_fields':positive,'failures':fail,'scope':'Stored public post-state only, after a closed component call. Build/run identity, full host model step, global budgets and science require separate evidence.'}
with OUT.open('x') as f:json.dump(report,f,indent=2,allow_nan=False);f.write('\n')
OUT.chmod(0o444)
print(json.dumps({'status':report['status'],'failures':fail,'report':str(OUT),'sha256':sha(OUT),'conversions':conversions,'caps':caps}))
