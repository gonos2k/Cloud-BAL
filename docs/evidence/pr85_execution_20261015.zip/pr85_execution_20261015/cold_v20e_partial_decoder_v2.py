#!/usr/bin/env python3
"""Decode PR85 KDM6 transaction and 200-micron transition ledgers.

The record offsets below are bound to the source's WRITE argument list and
format; unweighted state-space sums are diagnostics only, never a physical
domain mass budget.
"""
from __future__ import annotations

import argparse
import hashlib
import json
import math
from pathlib import Path
import re
import statistics
import sys

RATES = (
    "pracw", "piacw", "pmulcs", "pmulcg", "pmulrs", "pmulrg", "prevp",
    "psdep", "pidep", "pinud", "psaut", "psaci", "nccol", "nracw",
    "niacw", "ninud", "nmulcs", "nmulcg", "nmulrs", "nmulrg", "nsaci",
    "nsaut", "nrcol", "praut", "nraut", "paacw", "naacw", "pracs",
    "praci", "piacr", "psacr", "pgacr", "pgdep", "pgaci", "pgaut",
    "pgacs", "nraci", "niacr", "nsacr", "ngacr", "ngaci",
)

PREFIX = (
    "i", "lat", "k", "loop", "ngStatus", "autStatus", "gStatus", "retry",
    "storedNoop", "dtcld", "rhoDry", "gamma",
)

GROUPS = ("NG", "AUT", "G")
COMPONENTS = (
    "Qbefore", "QafterNG_AUT", "QGrequest", "Qafter",
    "Nbefore", "NafterNG_AUT", "NGrequest", "Nafter",
    "BGbefore", "BGafterNG_AUT", "BGrequest", "BGafter",
    "Tbefore", "TafterNG_AUT", "TGrequest", "Tafter",
    "QVbefore", "QVafterNG_AUT", "QVGrequest", "QVafter",
    "CCN3before", "CCN3transfer", "CCN3after",
)


def sha256(path: Path) -> str:
    digest = hashlib.sha256()
    with path.open("rb") as stream:
        for block in iter(lambda: stream.read(1024 * 1024), b""):
            digest.update(block)
    return digest.hexdigest()


def compact_fortran(text: str) -> str:
    text = re.sub(r"!.*$", "", text, flags=re.MULTILINE)
    return re.sub(r"[\s&]+", "", text).lower()


def bind_source(source_path: Path) -> dict[str, object]:
    text = source_path.read_text()
    compact = compact_fortran(text)
    required = (
        "write(pr85_cold_unit,'(a,8i8,1x,l1,1p,*(1x,e24.16))'",
        "'pr85_kdm6_cold',i,lat,k,loop,rain_ng_search_status,",
        "rain_aut_search_status,rain_process_search_status,rain_composite_retry,",
        "rain_composite_stored_noop,dtcld,dry_carrier_density(i,k),rain_composite_gamma,",
        "rain_composite_rate_base*rain_composite_gamma,",
        "rain_ng_alpha,rain_aut_alpha,rain_process_alpha,",
        "dbLE(qci(i,k,2))".lower(),
        "if(qci(i,k,2).ge.qmin.and.t(i,k).lt.273.15)then",
        "if(avedia(i,k,3).ge.200.e-6)then",
        "write(pr85_trace_unit,'(a,4i8,1p,13es24.16)'",
        "pr85_trace_qi,pr85_trace_qs,pr85_trace_ni,",
        "pr85_trace_qi,pr85_trace_removed_qi,pr85_trace_snow_gain,qci(i,k,2),",
    )
    missing = [token for token in required if token not in compact]
    if missing:
        raise ValueError(f"source does not match decoder contract: {missing}")
    rate_start = compact.index("rain_composite_rate_base=[")
    rate_end = compact.index("]", rate_start)
    source_rates = tuple(re.findall(r"([a-z0-9_]+)\(i,k\)", compact[rate_start:rate_end]))
    if source_rates != RATES:
        raise ValueError("source's 41-slot rate snapshot order differs from decoder field map")
    return {
        "path": str(source_path.resolve()),
        "sha256": sha256(source_path),
        "cold_format": "a,8i8,1x,l1,1p,*(1x,e24.16)",
        "cold_integer_positions_1_based": {name: i + 1 for i, name in enumerate(PREFIX[:8])},
        "stored_noop_position_1_based": 10,
        "first_real_position_1_based": 11,
        "rate_slots_1_based": {name: 14 + i for i, name in enumerate(RATES)},
        "effective_alpha_positions_1_based": {"NG": 55, "AUT": 56, "G": 57},
        "ice_transition_format": "a,4i8,1p,13es24.16",
        "note": "Position map derived from source WRITE argument order; source header text is also recorded in report.",
        "cold_header_omissions": ["composite retry index", "stored no-op flag", "common gamma", "41 scaled rate slots"],
    }


def f32(text: str) -> float:
    return float(text.replace("D", "E").replace("d", "e"))


def summarize(values: list[float]) -> dict[str, float | int | None]:
    if not values:
        return {"count": 0, "min": None, "max": None, "max_abs": None}
    return {
        "count": len(values),
        "min": min(values),
        "max": max(values),
        "max_abs": max(abs(v) for v in values),
    }


def update_presence(stats: dict[str, int | float], key: str, values: list[float]) -> None:
    if any(value != 0.0 for value in values):
        stats[f"{key}_nonzero_records"] = int(stats[f"{key}_nonzero_records"]) + 1
    stats[f"{key}_max_abs"] = max(
        float(stats[f"{key}_max_abs"]), max((abs(value) for value in values), default=0.0)
    )


def decode_cold(path: Path) -> dict[str, object]:
    counts: dict[str, int] = {
        "records": 0,
        "stored_noop_true": 0,
        "group_specific_noop_candidate": 0,
        "raw_noop_mismatch": 0,
    }
    status_counts: dict[str, int] = {}
    effective: dict[str, list[float]] = {name: [] for name in ("NG", "AUT", "G", "gamma")}
    rate_stats = {name: {"nonzero": 0, "max_abs": 0.0} for name in RATES}
    residual_stats = {name: {"nonzero": 0, "max_abs": 0.0} for name in (
        *(f"Q{i}" for i in range(1, 6)), *(f"N{i}" for i in range(1, 4)),
        "CCN3", "BG", "T", "QV",
    )}
    packet_stats = {
        group: {
            f"{part}_{stage}_{measure}": 0
            for part, width in (("Q", 5), ("N", 3), ("BG", 1), ("T", 1), ("QV", 1))
            for stage in ("request", "approved", "withheld")
            for measure in ("nonzero_records", "max_abs")
        }
        for group in GROUPS
    }
    schema_header = None
    bad_records: list[dict[str, object]] = []

    with path.open(errors="replace") as stream:
        for line_number, line in enumerate(stream, 1):
            if line.startswith("# PR85_KDM6_COLD fields:"):
                schema_header = line[2:].strip()
                continue
            if not line.startswith("PR85_KDM6_COLD"):
                continue
            fields = line.split()
            if len(fields) != 217:
                bad_records.append({"line": line_number, "field_count": len(fields), "expected": 217})
                continue
            try:
                ints = [int(value) for value in fields[1:9]]
                if fields[9].upper() not in ("T", "F"):
                    raise ValueError("invalid logical stored-noop flag")
                noop = fields[9].upper() == "T"
                values = [f32(value) for value in fields[10:]]
                if not all(math.isfinite(value) for value in values):
                    raise ValueError("nonfinite real field")
            except ValueError as error:
                bad_records.append({"line": line_number, "error": str(error)})
                continue

            counts["records"] += 1
            counts["stored_noop_true"] += int(noop)
            key = "/".join(str(value) for value in ints[4:7])
            status_counts[key] = status_counts.get(key, 0) + 1
            effective["gamma"].append(values[2])
            group_alphas = {"NG": values[44], "AUT": values[45], "G": values[46]}
            for name, alpha in group_alphas.items():
                effective[name].append(alpha)

            group_requests: dict[str, bool] = {}
            for group, base in (("NG", 94), ("AUT", 127), ("G", 162)):
                packet = values[base:base + 33]
                request_values = (
                    *packet[0:5], *packet[15:18], packet[24], packet[27], packet[30]
                )
                group_requests[group] = any(value != 0.0 for value in request_values)
            actual_rates_zero = all(value == 0.0 for value in values[3:44])
            group_specific_noop = actual_rates_zero and any(
                group_alphas[group] > 0.0 and group_requests[group]
                for group in GROUPS
            )
            counts["group_specific_noop_candidate"] += int(group_specific_noop)
            counts["raw_noop_mismatch"] += int(noop != group_specific_noop)

            for index, name in enumerate(RATES):
                rate = values[3 + index]
                if rate != 0.0:
                    rate_stats[name]["nonzero"] += 1
                    rate_stats[name]["max_abs"] = max(float(rate_stats[name]["max_abs"]), abs(rate))

            # Source argument expansion has 94 base values, then NG=33, AUT=35
            # (11 explicit zero values; the first 9 align with BG/T/QV packet slots),
            # G=33, then 12 residuals. Within each packet, each species is written
            # request, approved, withheld. Keep offsets explicit and source-bound.
            for group, base in (("NG", 94), ("AUT", 127), ("G", 162)):
                packet = values[base:base + 33]
                for stage_index, stage in enumerate(("request", "approved", "withheld")):
                    update_presence(packet_stats[group], f"Q_{stage}", packet[stage_index * 5:(stage_index + 1) * 5])
                    update_presence(packet_stats[group], f"N_{stage}", packet[15 + stage_index * 3:18 + stage_index * 3])
                    update_presence(packet_stats[group], f"BG_{stage}", packet[24 + stage_index:25 + stage_index])
                    update_presence(packet_stats[group], f"T_{stage}", packet[27 + stage_index:28 + stage_index])
                    update_presence(packet_stats[group], f"QV_{stage}", packet[30 + stage_index:31 + stage_index])

            for offset, name in enumerate(residual_stats):
                residual = values[195 + offset]
                if residual != 0.0:
                    residual_stats[name]["nonzero"] += 1
                    residual_stats[name]["max_abs"] = max(float(residual_stats[name]["max_abs"]), abs(residual))

    return {
        "path": str(path.resolve()),
        "sha256": sha256(path),
        "source_header_text": schema_header,
        "record_count": counts["records"],
        "raw_stored_noop_true_count": counts["stored_noop_true"],
        "group_specific_noop_candidate_count": counts["group_specific_noop_candidate"],
        "raw_noop_flag_vs_group_specific_candidate_mismatch_count": counts["raw_noop_mismatch"],
        "status_tuple_counts_ng_aut_g": status_counts,
        "effective_alpha_and_gamma": {name: summarize(values) for name, values in effective.items()},
        "rate_values": rate_stats,
        "packet_presence": packet_stats,
        "stored_minus_native_R32_residuals": residual_stats,
        "invalid_records": bad_records[:20],
        "invalid_record_count": len(bad_records),
        "physical_budget_claim": "none; fields are unweighted local tendencies/states and residuals",
    }


def decode_transition(path: Path) -> dict[str, object]:
    header = None
    loops = 0
    events = 0
    removed: list[float] = []
    snow_gain: list[float] = []
    pre_qi: list[float] = []
    post_qi: list[float] = []
    pre_qs: list[float] = []
    post_qs: list[float] = []
    pre_ni: list[float] = []
    post_ni: list[float] = []
    diameters: list[float] = []
    transfer_residuals: list[float] = []
    stored_qs_gain_r64: list[float] = []
    stored_pair_residuals_r64: list[float] = []
    actual_transfer_count = 0
    sample_events: list[dict[str, object]] = []
    invalid: list[dict[str, object]] = []

    with path.open(errors="replace") as stream:
        for line_number, line in enumerate(stream, 1):
            if line.startswith("# PR85_ICE_TRANSITION:"):
                header = line[2:].strip()
                continue
            if not line.startswith("PR85_ICE_TRANSITION"):
                continue
            fields = line.split()
            if fields[0] == "PR85_ICE_TRANSITION_LOOP":
                loops += 1
                continue
            if fields[0] != "PR85_ICE_TRANSITION":
                continue
            if len(fields) != 18:
                invalid.append({"line": line_number, "field_count": len(fields), "expected": 18})
                continue
            try:
                numeric = [f32(value) for value in fields[5:]]
                if not all(math.isfinite(value) for value in numeric):
                    raise ValueError("nonfinite transition value")
            except ValueError as error:
                invalid.append({"line": line_number, "error": str(error)})
                continue
            # Float positions: dt,Tbefore,Tafter,Dm,preQI,preQS,preNI,executedQI,
            # removedQI,snowGain,postQI,postQS,postNI.
            dt, tb, ta, diameter, qib, qsb, nib, qiexec, qiremoved, qsgain, qia, qsa, nia = numeric
            events += 1
            diameters.append(diameter)
            pre_qi.append(qib); post_qi.append(qia)
            pre_qs.append(qsb); post_qs.append(qsa)
            pre_ni.append(nib); post_ni.append(nia)
            removed.append(qiremoved); snow_gain.append(qsgain)
            transfer_residuals.append(qsgain - qiremoved)
            qs_gain_from_stored_states = qsa - qsb
            stored_qs_gain_r64.append(qs_gain_from_stored_states)
            stored_pair_residuals_r64.append((qia + qsa) - (qib + qsb))
            actual_transfer_count += int(qiremoved > 0.0 and qsgain > 0.0)
            if len(sample_events) < 20:
                sample_events.append({
                    "i": int(fields[1]), "lat": int(fields[2]),
                    "k": int(fields[3]), "loop": int(fields[4]),
                    "diameter_m": diameter,
                    "QI_before": qib, "QI_after": qia,
                    "QS_before": qsb, "QS_after": qsa,
                    "NI_before_per_m3": nib, "NI_after_per_m3": nia,
                    "QI_removed_local": qiremoved,
                    "native_R32_QS_gain_subtraction": qsgain,
                    "QS_gain_recomputed_R64_from_stored_states": qs_gain_from_stored_states,
                    "stored_pair_mass_residual_R64": (qia + qsa) - (qib + qsb),
                })

    return {
        "path": str(path.resolve()),
        "sha256": sha256(path),
        "source_header_text": header,
        "loop_marker_count": loops,
        "event_count": events,
        "nonzero_QI_to_QS_transfer_event_count": actual_transfer_count,
        "first_events": sample_events,
        "diameter_m": summarize(diameters),
        "QI_before_kg_per_kg_dry_unweighted": summarize(pre_qi),
        "QI_after_kg_per_kg_dry_unweighted": summarize(post_qi),
        "QS_before_kg_per_kg_dry_unweighted": summarize(pre_qs),
        "QS_after_kg_per_kg_dry_unweighted": summarize(post_qs),
        "NI_before_number_per_m3_unweighted": summarize(pre_ni),
        "NI_after_number_per_m3_unweighted": summarize(post_ni),
        "QI_removed_kg_per_kg_dry_unweighted": summarize(removed),
        "snow_gain_kg_per_kg_dry_unweighted": summarize(snow_gain),
        "native_R32_QS_gain_minus_QI_removed_diagnostic": summarize(transfer_residuals),
        "QS_gain_recomputed_R64_from_stored_states": summarize(stored_qs_gain_r64),
        "stored_pair_mass_residual_R64": summarize(stored_pair_residuals_r64),
        "invalid_records": invalid[:20],
        "invalid_record_count": len(invalid),
        "physical_budget_claim": "none; transfer fields are unweighted local state mixing ratios, not integrated mass",
    }


def main() -> None:
    parser = argparse.ArgumentParser()
    parser.add_argument("--source", required=True, type=Path)
    parser.add_argument("--cold", required=True, type=Path)
    parser.add_argument("--transition", type=Path)
    parser.add_argument("--receipt", type=Path)
    parser.add_argument("--completion-status", default="UNSPECIFIED")
    parser.add_argument("--out", required=True, type=Path)
    args = parser.parse_args()
    report: dict[str, object] = {
        "decoder_sha256": sha256(Path(__file__)),
        "source_binding": bind_source(args.source),
        "cold_ledger": decode_cold(args.cold),
    }
    if args.transition:
        report["ice_200um_transition"] = decode_transition(args.transition)
    if args.receipt:
        report["replay_provenance"] = {
            "receipt_path": str(args.receipt.resolve()),
            "receipt_sha256": sha256(args.receipt),
            "completion_status": args.completion_status,
            "acceptance": "not accepted; diagnostic replay ended before full call completion",
        }
    args.out.write_text(json.dumps(report, indent=2, sort_keys=True) + "\n")
    print(json.dumps({
        "report": str(args.out.resolve()),
        "report_sha256": sha256(args.out),
        "decoder_sha256": sha256(Path(__file__)),
        "cold_record_count": report["cold_ledger"]["record_count"],
        "transition_event_count": report.get("ice_200um_transition", {}).get("event_count"),
    }, sort_keys=True))


if __name__ == "__main__":
    main()
