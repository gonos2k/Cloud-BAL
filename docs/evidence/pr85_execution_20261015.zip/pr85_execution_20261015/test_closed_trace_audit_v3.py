import hashlib
import importlib.util
import json
from pathlib import Path
import tempfile
import unittest

SCRIPT = Path('/var/tmp/pr85_closed_trace_audit_v3_20261015.py')
spec = importlib.util.spec_from_file_location('pr85_audit_v3', SCRIPT)
audit = importlib.util.module_from_spec(spec)
spec.loader.exec_module(audit)


def digest(path):
    return hashlib.sha256(path.read_bytes()).hexdigest()


class RunReceiptBindingTests(unittest.TestCase):
    def setUp(self):
        self.tmp = tempfile.TemporaryDirectory(prefix='pr85-audit-v3-')
        self.addCleanup(self.tmp.cleanup)
        self.root = Path(self.tmp.name)
        self.run = self.root / 'run'
        self.run.mkdir()
        for name, data in {
            'wrfinput_d01': b'input', 'wrfbdy_d01': b'boundary',
            'wrf.exe': b'executable', 'static.dat': b'static',
            'pr85_joint_moment_stages.raw': b'stages',
            'kdm6_first_call_pre.raw': b'pre', 'kdm6_first_call_post.raw': b'post',
            'pr67_kdm6_process.raw': b'process',
            'rsl.error.0000': b'SUCCESS COMPLETE WRF\n',
            'extra_process.raw': b'extra',
            'namelist.input': b'&time_control /\n',
            'namelist.input.source': b'&time_control /\n',
        }.items():
            (self.run / name).write_bytes(data)
        self.build_receipt = self.root / 'build.json'
        self.build_receipt.write_text('{}\n')
        self.build_exe = self.root / 'candidate.exe'
        self.build_exe.write_bytes((self.run / 'wrf.exe').read_bytes())
        audit.EXPECTED_INPUT_SHA256['OFF'] = digest(self.run / 'wrfinput_d01')
        audit.EXPECTED_BOUNDARY_SHA256 = digest(self.run / 'wrfbdy_d01')
        self.build = {
            'status': 'PASS_SCOPED_BUILD',
            'candidate_executable_path': str(self.build_exe.resolve()),
            'candidate_executable_sha256': digest(self.build_exe),
            'receipt_sha256': digest(self.build_receipt),
        }
        names = ('pr85_joint_moment_stages.raw', 'kdm6_first_call_pre.raw',
                 'kdm6_first_call_post.raw', 'pr67_kdm6_process.raw', 'extra_process.raw')
        self.trace_rows = {name: {'sha256': digest(self.run / name),
                                  'bytes': (self.run / name).stat().st_size}
                           for name in names}
        inputs = ['wrfinput_d01', 'wrfbdy_d01', 'wrf.exe', 'static.dat', 'namelist.input', 'namelist.input.source']
        input_rows = []
        for name in inputs:
            path = self.run / name
            input_rows.append({'path': str(path), 'sha256_before': digest(path),
                               'sha256_after': digest(path)})
        h = {name: digest(self.run / name) for name in
             ('wrfinput_d01', 'wrfbdy_d01', 'wrf.exe')}
        source_sha = {'runner': '1' * 64, 'consumer_build_receipt': digest(self.build_receipt)}
        static_sha = {'static.dat': digest(self.run / 'static.dat')}
        self.record = {
            'schema': 'pr83_same13_native_initialization_v1',
            'artifact_class': 'RESEARCH_DIAGNOSTIC', 'science_authority': 'NONE',
            'operational_authority': 'NONE', 'initialization_gate': 'PASS_SCOPED_INITIALIZATION_READBACK',
            'first_step_gate': 'PASS', 'sources_unchanged': True,
            'native_trace_output_integrity': 'PASS', 'native_trace_output_issues': [],
            'candidate_wrfinput_sha256': h['wrfinput_d01'], 'candidate_wrfbdy_sha256': h['wrfbdy_d01'],
            'candidate_input_source_role': 'OFF', 'candidate_input_prior_status': 'RESEARCH_PRIOR_CREATED',
            'cold_start_scope_guard': {'status': 'PASS', 'max_dom': 1, **{
                key: 'disabled; no enabled assignment in source namelist; source-bound WRF default'
                for key in ('restart', 'cycling', 'dfi_opt')}},
            'native_namelist_change': {'run_seconds': {'effective': '20'},
                'time_control_start': 'retained 2026-08-16 13:00:00',
                'time_control_end': {'effective': '2026-08-16 13:00:20'}},
            'candidate_input_source_hashes_before': h, 'candidate_input_source_hashes_after': h,
            'native_executable_sha256': h['wrf.exe'],
            'consumer_build_binding': {
                'candidate_executable_path': str(self.build_exe.resolve()),
                'candidate_executable_sha256': h['wrf.exe'],
                'receipt_sha256': digest(self.build_receipt),
            },
            'run_isolation': {'run_root': str(self.run.resolve()), 'input_integrity': 'PASS',
                              'output_isolation': 'PASS', 'changed_inputs': [], 'input_read_issues': [],
                              'inputs': input_rows,
                              'outputs': [{'path': 'rsl.error.0000', 'sha256': digest(self.run / 'rsl.error.0000')}],
                              'returncode': 0},
            'runner_and_runtime_source_hashes_before': source_sha,
            'runner_and_runtime_source_hashes_after': source_sha,
            'static_runtime_source_hashes': static_sha,
            'static_runtime_source_hashes_after': static_sha,
            'native_trace_outputs': self.trace_rows,
            'native_namelist_effective_sha256': digest(self.run / 'namelist.input'),
            'native_namelist_source_sha256': digest(self.run / 'namelist.input.source'),
            'rsl_error_sha256': digest(self.run / 'rsl.error.0000'),
        }
        self.receipt = self.run / audit.RUN_RECEIPT_NAME
        self._write_receipt()

    def _write_receipt(self):
        self.receipt.write_text(json.dumps(self.record) + '\n')

    def _validate(self):
        return audit.validate_run_receipt(
            'OFF', self.run, self.receipt, self.build_receipt, self.build,
            {'sha256': self.trace_rows['pr85_joint_moment_stages.raw']['sha256']},
            {'pre': self.trace_rows['kdm6_first_call_pre.raw'],
             'post': self.trace_rows['kdm6_first_call_post.raw']})

    def test_matching_receipt_and_completed_process_pass(self):
        self.assertEqual(self._validate()['status'], 'PASS_SCOPED_RUN')

    def test_missing_receipt_fails_closed(self):
        self.assertEqual(audit.validate_run_receipt(
            'OFF', self.run, self.run / 'absent.json', self.build_receipt, self.build,
            None, {})['status'], 'FAIL')

    def test_substituted_run_executable_fails(self):
        (self.run / 'wrf.exe').write_bytes(b'substitute')
        self.assertIn('wrf.exe', self._validate()['error'])

    def test_trace_substitution_fails(self):
        (self.run / 'pr85_joint_moment_stages.raw').write_bytes(b'substitute')
        result = self._validate()
        self.assertEqual(result['status'], 'FAIL')
        self.assertIn('trace', result['error'])

    def test_noncore_trace_substitution_fails(self):
        (self.run / 'extra_process.raw').write_bytes(b'changed extra')
        result = self._validate()
        self.assertEqual(result['status'], 'FAIL')
        self.assertIn('extra_process.raw', result['error'])

    def test_rejected_or_nonzero_model_step_fails_and_is_reported(self):
        self.record['run_isolation']['returncode'] = 128
        self.record['first_step_gate'] = 'REJECTED_OR_ABORTED'
        self._write_receipt()
        result = self._validate()
        self.assertEqual(result['status'], 'FAIL')
        self.assertEqual(result['run_returncode'], 128)
        self.assertEqual(result['first_step_gate'], 'REJECTED_OR_ABORTED')


if __name__ == '__main__':
    unittest.main(verbosity=2)
