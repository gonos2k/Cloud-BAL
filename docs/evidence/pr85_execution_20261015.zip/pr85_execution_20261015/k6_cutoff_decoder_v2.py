#!/usr/bin/env python3
"""Independent read-only decoder for the partial v20k6 cleanup trace."""
from __future__ import annotations
import hashlib, json, math, re
from pathlib import Path

raw = Path('/var/tmp/pr85_kdm6_fast_replay_v20k6_20261015a/pr85_kdm6_cutoff_budget.raw')
receipt_path = Path('/var/tmp/pr85_kdm6_fast_replay_v20k6_20261015a/replay_receipt_v2.json')
source = Path('/var/tmp/pr85_kdm6_candidate_v20k6_cutoff_sourcehold_20261015/module_mp_kdm6.F')
expected = {
 'raw':'e6c976c57db057ffbb88c85a134d6434eceb099c169b069181fcb11c8c47b4e6',
 'receipt':'8f1317e534739dca4f7c758f73a8327d988f95167918b833997fe0a9ea2b7335',
 'source':'3941af2cccdb2a37578532a2704f6e9a03070f6cf67d524045a60260b3a6502c',
 'source_manifest':'3c192b805540707463f3d1184f5ea17e217c980e1c5d926413451e0e1854db8a',
}
def sha(path: Path) -> str: return hashlib.sha256(path.read_bytes()).hexdigest()

assert sha(raw) == expected['raw']
assert sha(receipt_path) == expected['receipt']
assert sha(source) == expected['source']
manifest=source.parent/'source_manifest.json'
assert sha(manifest) == expected['source_manifest']
rec=json.loads(receipt_path.read_text())
assert rec['status']=='DIAGNOSTIC_FAIL' and rec['runtime']['exit_status']==128
assert rec['candidate']['source_sha256']==expected['source']
assert rec['runtime']['cutoff_budget_sha256']==expected['raw']

# Verify the schema from the immutable source WRITE list, not its stale header.
s=source.read_text()
compact=re.sub(r'[\s&]+','',re.sub(r'!.*$','',s,flags=re.M)).lower()
assert "write(pr85_cutoff_unit,'(a,5i8,1p,25es24.16,2i8)'" in compact
writer=compact[compact.index("write(pr85_cutoff_unit,'(a,5i8,1p,25es24.16,2i8)'"):]
assert ("'pr85_kdm6_cutoff',i,lat,k,loop,pr85_cutoff_mask,"
        "dry_carrier_density(i,k),qmin,qcrmin,"
        "pr85_cutoff_q_before,pr85_cutoff_q_after,"
        "pr85_cutoff_n_before,pr85_cutoff_n_after,"
        "pr85_cutoff_bg_before,pr85_cutoff_bg_after,"
        "pr85_cutoff_t_before,pr85_cutoff_t_after,"
        "pr85_cutoff_qv_before,pr85_cutoff_qv_after,"
        "pr85_cutoff_status_before,progb_status(i,k)") in writer

qkeys=('QC','QI','QR','QS','QG')
nkeys=('NC','NI','NR')
qthresholds=(0,0,1,1,1)
bit=(1,2,4,8,16)
counts={'mask_nonzero':0,'q_removed_by_species':{x:0 for x in qkeys},
        'n_removed_by_species':{x:0 for x in nkeys},'bg_removed':0,
        'q_threshold_eligible':{x:0 for x in qkeys},
        'status_changes':0,'q_any_removed':0,'n_any_removed':0}
removed={'Q_by_species':{x:0.0 for x in qkeys},
         'N_by_species':{x:0.0 for x in nkeys},'B':0.0}
seen=set(); rows=0; max_abs_T=0.0; max_abs_QV=0.0
mask_hist={}; qmin_values=set(); qcrmin_values=set()
with raw.open() as f:
    header=next(f).rstrip('\n')
    for lineno,line in enumerate(f,2):
        parts=line.split()
        if not parts or parts[0].startswith('#'): continue
        assert len(parts)==33, (lineno,len(parts))
        assert parts[0]=='PR85_KDM6_CUTOFF', (lineno,parts[0])
        i,lat,k,loop,mask=map(int,parts[1:6])
        values=list(map(float,parts[6:31]))
        stat_before,stat_after=map(int,parts[31:33])
        # format contributes tag + 5I + 25E + 2I = 33 tokens.
        key=(i,lat,k,loop)
        assert key not in seen, ('duplicate cleanup record',key)
        seen.add(key); rows+=1
        rho,qmin,qcrmin=values[:3]
        qb=values[3:8]; qa=values[8:13]
        nb=values[13:16]; na=values[16:19]
        bb,ba,tb,ta,qvb,qva=values[19:25]
        assert all(math.isfinite(v) for v in values)
        assert rho>0 and qmin>0 and qcrmin>0
        qmin_values.add(qmin); qcrmin_values.add(qcrmin)
        expected_mask=0
        for idx,(q,thidx,b) in enumerate(zip(qb,qthresholds,bit)):
            threshold=qmin if thidx==0 else qcrmin
            eligible=(q<=threshold)
            if eligible:
                expected_mask+=b; counts['q_threshold_eligible'][qkeys[idx]]+=1
                assert qa[idx]==0.0, (lineno,qkeys[idx],q,qa[idx],threshold)
            else:
                assert qa[idx]==q, (lineno,qkeys[idx],q,qa[idx])
        assert mask==expected_mask, (lineno,mask,expected_mask)
        # Native cleanup zeroes NC/NI/NR only with QC/QI/QR; QS has no number.
        for idx,source_qidx in enumerate((0,1,2)):
            if mask & bit[source_qidx]: assert na[idx]==0.0, (lineno,nkeys[idx],na[idx])
            else: assert na[idx]==nb[idx], (lineno,nkeys[idx],nb[idx],na[idx])
        if mask & 16:
            assert ba==0.0, (lineno,'graupel B',bb,ba)
        else:
            assert ba==bb, (lineno,'unexpected B change',bb,ba,mask)
        assert ta==tb, (lineno,'cleanup changed T',tb,ta)
        assert qva==qvb, (lineno,'cleanup changed QV',qvb,qva)
        assert any(x!=y for x,y in zip(qb,qa)) or any(x!=y for x,y in zip(nb,na)) or bb!=ba
        if mask: counts['mask_nonzero']+=1
        if mask & 16: assert stat_after==0, (lineno,'QG cleanup did not mark ProgB absent',stat_after)
        elif stat_after!=stat_before: raise AssertionError((lineno,'unexpected ProgB status change',stat_before,stat_after,mask))
        if stat_before!=stat_after: counts['status_changes']+=1
        mask_hist[str(mask)]=mask_hist.get(str(mask),0)+1
        for idx,name in enumerate(qkeys):
            d=qb[idx]-qa[idx]
            if d!=0.0:
                counts['q_removed_by_species'][name]+=1
                removed['Q_by_species'][name]+=d
        for idx,name in enumerate(nkeys):
            d=nb[idx]-na[idx]
            if d!=0.0:
                counts['n_removed_by_species'][name]+=1
                removed['N_by_species'][name]+=d
        if bb!=ba:
            counts['bg_removed']+=1; removed['B']+=bb-ba
        if any(qb[x]!=qa[x] for x in range(5)): counts['q_any_removed']+=1
        if any(nb[x]!=na[x] for x in range(3)): counts['n_any_removed']+=1
        max_abs_T=max(max_abs_T,abs(ta-tb)); max_abs_QV=max(max_abs_QV,abs(qva-qvb))

assert sha(raw)==expected['raw'] and sha(source)==expected['source'] and sha(receipt_path)==expected['receipt'] and sha(manifest)==expected['source_manifest']
report={
 'schema':'pr85_kdm6_cutoff_independent_decode_v2',
 'status':'PARTIAL_CALL_NOT_ACCEPTED',
 'source':{'path':str(source),'sha256':expected['source'],'manifest_sha256':expected['source_manifest']},
 'raw':{'path':str(raw),'sha256':expected['raw'],'rows':rows,'unique_cell_loop_rows':len(seen),
        'header_note':'The header in this v20k6 source is stale: report decodes directly from source WRITE format/argument list; k6b corrects header only.'},
 'receipt':{'path':str(receipt_path),'sha256':expected['receipt'],'exit_status':rec['runtime']['exit_status'],
            'fatal':rec['runtime']['fatal_text'],'fatal_cell':'not captured; last row is not treated as failure cell'},
 'validation':{'source_derived_mask_bits':{'QC':1,'QI':2,'QR':4,'QS':8,'QG':16},
               'unique_index_tuple':'(i,lat,k,loop)','mask_histogram':mask_hist,
               'qmin_values':sorted(qmin_values),'qcrmin_values':sorted(qcrmin_values),
               'changed_rows':rows,'status_change_rows':counts['status_changes'],
               'max_abs_cleanup_delta_T_K':max_abs_T,'max_abs_cleanup_delta_QV_kgkgdry':max_abs_QV,
               'checks':'All selected Q channels were threshold-eligible and became zero; associated NC/NI/NR and graupel BG were cleared only under source-matching mask bits; all other Q/N/B entries unchanged; T/QV bitwise numeric equality; unique rows.'},
 'counts':counts,'local_unweighted_removed':removed,
 'limitations':['Diagnostic run exited 128 before call completion; no post-call state or scientific/runtime pass.',
                'Removed totals are sums of per-cell native-state changes in mixing-ratio / number-density / B units; no dry-air mass, area, dz, or global budget weighting is applied.',
                'No fatal cell inference from last ledger row.',
                'QG/B cleanup additionally resets ProgB and diagnostic fields; those diagnostics are not serialized in cutoff ledger.']}
out=Path('/var/tmp/pr85_kdm6_cutoff_decode_v20k6_20261015_report_v2.json')
out.write_text(json.dumps(report,indent=2,sort_keys=True)+'\n')
print(json.dumps({'report':str(out),'rows':rows,'mask_histogram':mask_hist,'counts':counts,'removed':removed,'report_sha256':sha(out)},indent=2))
