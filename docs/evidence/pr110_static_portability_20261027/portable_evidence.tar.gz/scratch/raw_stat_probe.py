import ctypes
import errno
import os

libc = ctypes.CDLL(None, use_errno=True)
path = b"/NHNHOME/WORKSPACE/26weather002_A/yhlee/local/compiler/2026.0/bin/ifx"
stat_buffer = ctypes.create_string_buffer(512)
for syscall_number in (4, 6):  # x86_64 __NR_stat, __NR_lstat
    ctypes.set_errno(0)
    result = libc.syscall(syscall_number, ctypes.c_char_p(path), ctypes.byref(stat_buffer))
    error = ctypes.get_errno()
    assert result == -1 and error == errno.ENOENT, (syscall_number, result, error)
print("raw stat/lstat return ENOENT")
