import errno
import os
import shutil

paths = [
    "/NHNHOME/WORKSPACE/26weather002_A/yhlee/KIM-meso/KIM_RDPS_MODL_V2026.2/frame/module_driver_constants.o",
    "/NHNHOME/WORKSPACE/26weather002_A/yhlee/KIM-meso/KIM_RDPS_MODL_V2026.2/external/io_grib1/libio_grib1.a",
    "/NHNHOME/WORKSPACE/26weather002_A/yhlee/KIM-meso/deps/netcdf-intel/include/netcdf.mod",
    "/NHNHOME/WORKSPACE/26weather002_A/yhlee/local/compiler/2026.0/bin/ifx",
    "/NHNHOME/WORKSPACE/26weather002_A/yhlee/local/setvars.sh",
    "/NHNHOME/WORKSPACE/26weather002_A/yhlee/local/mpi/2021.18/env/vars.sh",
    "/var/tmp/pr61_ccn_origin_20261006/hostcopy",
    "/var/tmp/pr68_velocity_native_20261007/source/module_mp_kdm6_combined_research.f90",
    "/var/tmp/pr73_native_first_violation.x3bvfn/build/source/module_mp_kdm6.f90",
    "/var/tmp/pr82_native_stage_trace_build1",
]
for path in paths:
    assert not os.path.exists(path), (path, "exists")
    assert not os.access(path, os.F_OK), (path, "access true")
    try:
        os.stat(path)
    except OSError as error:
        assert error.errno == errno.ENOENT, (path, "stat", error.errno)
    else:
        raise AssertionError((path, "stat succeeded"))
    try:
        os.lstat(path)
    except OSError as error:
        assert error.errno == errno.ENOENT, (path, "lstat", error.errno)
    else:
        raise AssertionError((path, "lstat succeeded"))
    try:
        open(path, "rb").close()
    except OSError as error:
        assert error.errno == errno.ENOENT, (path, "open", error.errno)
    else:
        raise AssertionError((path, "open succeeded"))
print(f"absent paths verified: {len(paths)}")
print(f"ifx on PATH: {shutil.which('ifx')}")
assert shutil.which("ifx") is None
