#define _GNU_SOURCE
#include <errno.h>
#include <fcntl.h>
#include <linux/audit.h>
#include <linux/filter.h>
#include <linux/seccomp.h>
#include <poll.h>
#include <signal.h>
#include <stddef.h>
#include <stdint.h>
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <sys/ioctl.h>
#include <sys/prctl.h>
#include <sys/socket.h>
#include <sys/syscall.h>
#include <sys/types.h>
#include <sys/uio.h>
#include <sys/wait.h>
#include <unistd.h>
#include <limits.h>

static const char *blocked_roots[] = {
    "/NHNHOME",
    "/var/tmp/pr61_ccn_origin_20261006",
    "/var/tmp/pr68_velocity_native_20261007",
    "/var/tmp/pr73_native_first_violation.x3bvfn",
    "/var/tmp/pr73_pbl_research",
    "/var/tmp/pr74_shinhong_qni_driver.GvfcGi",
    "/var/tmp/pr78_cp06a_spatial.V9LYrN",
    "/var/tmp/pr83_same13_off_20261013c",
    "/var/tmp/pr84_ice_entry_guard_final_1efgtcsn",
    "/var/tmp/pr85_kdm6_candidate_v20j_prebuild_20261015",
    "/var/tmp/pr85_kdm6_fast_replay_v20j_20261015a",
    "/var/tmp/pr85_kdm6_warm_capture_v20j_20261015a",
    "/var/tmp/pr85_native_joint_candidate_20261015v13",
    "/var/tmp/pr85_native_joint_candidate_20261015v17",
    "/var/tmp/pr87_followup_sources_20261019_v50",
    "/var/tmp/pr87_joint_cycle_sources_20261016_v31",
    "/var/tmp/pr89_native_build_20261019_c5",
    "/var/tmp/pr89_sources_20261019_c1",
    "/var/tmp/pr89_sources_20261019_c5",
    "/var/tmp/pr90_native_build_diag_20261019",
    "/var/tmp/pr90_sources_c7_20261019",
    "/var/tmp/pr91_sources_c10_20261020",
    "/var/tmp/pr91_sources_c11_20261020d",
    "/var/tmp/pr93_sources_c4_20261020",
    "/var/tmp/pr96_native_build_c1_20261021",
    "/var/tmp/pr99-c2-source.2n00oy19",
    "/var/tmp/pr99_c1_three_arm_fallback_20261022",
    "/var/tmp/pr64_qc_channel_20261007",
    "/var/tmp/pr67_budget_capture_20261007",
    "/var/tmp/pr70_native_volume_trace_20261008_v3",
    "/var/tmp/pr71_guarded_native_20261008",
    "/var/tmp/pr71_guarded_native_source.diePOE",
    "/var/tmp/pr71_same_source_native_20261008_v2",
    "/var/tmp/pr77_native_state.dOaJQD",
    "/var/tmp/pr80_kdm6_radar_contract.nsUNuj",
    "/var/tmp/pr81_joint_thermo.HbL5ry",
    "/var/tmp/pr81_native_ksas_smallstep_run1",
    "/var/tmp/pr82_native_stage_trace_build1",
    "/var/tmp/pr82_same13_lapsprep_capture.WA4vyK",
    "/var/tmp/pr82_same13_real_candidate.final20261012",
    "/var/tmp/native-controlled-build",
    NULL
};

static int send_fd(int socket_fd, int fd)
{
    char byte = 'L';
    struct iovec io = { .iov_base = &byte, .iov_len = 1 };
    char control[CMSG_SPACE(sizeof(int))] = {0};
    struct msghdr msg = { .msg_iov = &io, .msg_iovlen = 1,
                          .msg_control = control, .msg_controllen = sizeof(control) };
    struct cmsghdr *cmsg = CMSG_FIRSTHDR(&msg);
    cmsg->cmsg_level = SOL_SOCKET;
    cmsg->cmsg_type = SCM_RIGHTS;
    cmsg->cmsg_len = CMSG_LEN(sizeof(int));
    memcpy(CMSG_DATA(cmsg), &fd, sizeof(fd));
    return sendmsg(socket_fd, &msg, 0) == 1 ? 0 : -1;
}

static int recv_fd(int socket_fd)
{
    char byte;
    struct iovec io = { .iov_base = &byte, .iov_len = 1 };
    char control[CMSG_SPACE(sizeof(int))] = {0};
    struct msghdr msg = { .msg_iov = &io, .msg_iovlen = 1,
                          .msg_control = control, .msg_controllen = sizeof(control) };
    if (recvmsg(socket_fd, &msg, 0) != 1) return -1;
    struct cmsghdr *cmsg = CMSG_FIRSTHDR(&msg);
    if (!cmsg || cmsg->cmsg_level != SOL_SOCKET || cmsg->cmsg_type != SCM_RIGHTS) return -1;
    int fd;
    memcpy(&fd, CMSG_DATA(cmsg), sizeof(fd));
    return fd;
}

static int notify_syscall(int nr)
{
    switch (nr) {
#ifdef __NR_open
    case __NR_open:
#endif
#ifdef __NR_openat
    case __NR_openat:
#endif
#ifdef __NR_openat2
    case __NR_openat2:
#endif
#ifdef __NR_newfstatat
    case __NR_newfstatat:
#endif
#ifdef __NR_stat
    case __NR_stat:
#endif
#ifdef __NR_lstat
    case __NR_lstat:
#endif
#ifdef __NR_statx
    case __NR_statx:
#endif
#ifdef __NR_access
    case __NR_access:
#endif
#ifdef __NR_faccessat
    case __NR_faccessat:
#endif
#ifdef __NR_faccessat2
    case __NR_faccessat2:
#endif
#ifdef __NR_readlink
    case __NR_readlink:
#endif
#ifdef __NR_readlinkat
    case __NR_readlinkat:
#endif
#ifdef __NR_chdir
    case __NR_chdir:
#endif
#ifdef __NR_execve
    case __NR_execve:
#endif
#ifdef __NR_execveat
    case __NR_execveat:
#endif
        return 1;
    default: return 0;
    }
}

static struct sock_filter filter[] = {
    BPF_STMT(BPF_LD | BPF_W | BPF_ABS, offsetof(struct seccomp_data, arch)),
    BPF_JUMP(BPF_JMP | BPF_JEQ | BPF_K, AUDIT_ARCH_X86_64, 1, 0),
    BPF_STMT(BPF_RET | BPF_K, SECCOMP_RET_KILL_PROCESS),
    BPF_STMT(BPF_LD | BPF_W | BPF_ABS, offsetof(struct seccomp_data, nr)),
#define DENY_NR(nr) BPF_JUMP(BPF_JMP | BPF_JEQ | BPF_K, nr, 0, 1), BPF_STMT(BPF_RET | BPF_K, SECCOMP_RET_USER_NOTIF)
#ifdef __NR_open
    DENY_NR(__NR_open),
#endif
#ifdef __NR_openat
    DENY_NR(__NR_openat),
#endif
#ifdef __NR_openat2
    DENY_NR(__NR_openat2),
#endif
#ifdef __NR_newfstatat
    DENY_NR(__NR_newfstatat),
#endif
#ifdef __NR_stat
    DENY_NR(__NR_stat),
#endif
#ifdef __NR_lstat
    DENY_NR(__NR_lstat),
#endif
#ifdef __NR_statx
    DENY_NR(__NR_statx),
#endif
#ifdef __NR_access
    DENY_NR(__NR_access),
#endif
#ifdef __NR_faccessat
    DENY_NR(__NR_faccessat),
#endif
#ifdef __NR_faccessat2
    DENY_NR(__NR_faccessat2),
#endif
#ifdef __NR_readlink
    DENY_NR(__NR_readlink),
#endif
#ifdef __NR_readlinkat
    DENY_NR(__NR_readlinkat),
#endif
#ifdef __NR_chdir
    DENY_NR(__NR_chdir),
#endif
#ifdef __NR_execve
    DENY_NR(__NR_execve),
#endif
#ifdef __NR_execveat
    DENY_NR(__NR_execveat),
#endif
    BPF_STMT(BPF_RET | BPF_K, SECCOMP_RET_ALLOW),
};

static int install_listener(void)
{
    struct sock_fprog program = { .len = (unsigned short)(sizeof(filter) / sizeof(filter[0])),
                                  .filter = filter };
    if (prctl(PR_SET_NO_NEW_PRIVS, 1, 0, 0, 0) < 0) return -1;
    return (int)syscall(SYS_seccomp, SECCOMP_SET_MODE_FILTER,
                        SECCOMP_FILTER_FLAG_NEW_LISTENER, &program);
}

static int read_child_string(pid_t pid, uint64_t address, char *out, size_t capacity)
{
    struct iovec local = { .iov_base = out, .iov_len = capacity - 1 };
    struct iovec remote = { .iov_base = (void *)(uintptr_t)address, .iov_len = capacity - 1 };
    ssize_t n = process_vm_readv(pid, &local, 1, &remote, 1, 0);
    if (n <= 0) return -1;
    out[n] = '\0';
    return memchr(out, '\0', (size_t)n) ? 0 : -1;
}

static int make_absolute(pid_t pid, int dirfd, const char *path, char *out, size_t cap)
{
    char base[PATH_MAX], fdpath[64];
    if (path[0] == '/') {
        if (snprintf(out, cap, "%s", path) >= (int)cap) return -1;
    } else {
        if (dirfd == AT_FDCWD) snprintf(fdpath, sizeof(fdpath), "/proc/%d/cwd", pid);
        else snprintf(fdpath, sizeof(fdpath), "/proc/%d/fd/%d", pid, dirfd);
        ssize_t n = readlink(fdpath, base, sizeof(base) - 1);
        if (n < 0) return -1;
        base[n] = '\0';
        if (snprintf(out, cap, "%s/%s", base, path) >= (int)cap) return -1;
    }
    char *resolved = realpath(out, NULL);
    if (resolved) {
        if (strlen(resolved) + 1 > cap) { free(resolved); return -1; }
        strcpy(out, resolved);
        free(resolved);
    }
    return 0;
}

static int is_blocked(const char *path)
{
    for (int i = 0; blocked_roots[i]; i++) {
        size_t n = strlen(blocked_roots[i]);
        if (strncmp(path, blocked_roots[i], n) == 0 && (path[n] == '\0' || path[n] == '/')) return 1;
    }
    return 0;
}

static int path_for_call(struct seccomp_notif *req, char *path, size_t cap)
{
    int nr = req->data.nr;
    int arg = 0, dirfd = AT_FDCWD;
    switch (nr) {
#ifdef __NR_openat
    case __NR_openat:
#endif
#ifdef __NR_openat2
    case __NR_openat2:
#endif
#ifdef __NR_newfstatat
    case __NR_newfstatat:
#endif
#ifdef __NR_statx
    case __NR_statx:
#endif
#ifdef __NR_faccessat
    case __NR_faccessat:
#endif
#ifdef __NR_faccessat2
    case __NR_faccessat2:
#endif
#ifdef __NR_readlinkat
    case __NR_readlinkat:
#endif
#ifdef __NR_execveat
    case __NR_execveat:
#endif
        dirfd = (int)req->data.args[0]; arg = 1; break;
    default: break;
    }
    if (read_child_string(req->pid, req->data.args[arg], path, cap) < 0) return -1;
    if (path[0] == '\0') return 0;
    char absolute[PATH_MAX];
    if (make_absolute(req->pid, dirfd, path, absolute, sizeof(absolute)) < 0) return -1;
    return is_blocked(absolute);
}

int main(int argc, char **argv)
{
    if (argc < 3 || strcmp(argv[1], "--") != 0) {
        fprintf(stderr, "usage: %s -- command [args...]\n", argv[0]); return 2;
    }
    int sockets[2];
    if (socketpair(AF_UNIX, SOCK_SEQPACKET, 0, sockets) < 0) { perror("socketpair"); return 2; }
    pid_t child = fork();
    if (child < 0) { perror("fork"); return 2; }
    if (child == 0) {
        close(sockets[0]);
        int listener = install_listener();
        if (listener < 0) { perror("seccomp user notification"); _exit(125); }
        if (send_fd(sockets[1], listener) < 0) { perror("send listener"); _exit(125); }
        close(listener); close(sockets[1]);
        execvp(argv[2], &argv[2]);
        perror("execvp"); _exit(127);
    }
    close(sockets[1]);
    int listener = recv_fd(sockets[0]); close(sockets[0]);
    if (listener < 0) { perror("receive listener"); kill(child, SIGKILL); waitpid(child, NULL, 0); return 125; }
    struct seccomp_notif_sizes sizes;
    if (syscall(SYS_seccomp, SECCOMP_GET_NOTIF_SIZES, 0, &sizes) < 0) { perror("notif sizes"); return 125; }
    struct seccomp_notif *req = calloc(1, sizes.seccomp_notif);
    struct seccomp_notif_resp *resp = calloc(1, sizes.seccomp_notif_resp);
    int status = 0;
    for (;;) {
        struct pollfd pfd = { .fd = listener, .events = POLLIN };
        poll(&pfd, 1, 100);
        if (pfd.revents & POLLIN) {
            memset(req, 0, sizes.seccomp_notif);
            if (ioctl(listener, SECCOMP_IOCTL_NOTIF_RECV, req) == 0) {
                memset(resp, 0, sizes.seccomp_notif_resp);
                resp->id = req->id;
                char path[PATH_MAX] = {0};
                int decision = notify_syscall(req->data.nr) ? path_for_call(req, path, sizeof(path)) : 0;
                if (decision > 0) {
                    resp->error = -ENOENT;
                    fprintf(stderr, "ABSENT_PATH pid=%u syscall=%d path=%s\n", req->pid, req->data.nr, path);
                } else if (decision < 0) {
                    resp->error = -EIO;
                    fprintf(stderr, "SUPERVISOR_PATH_READ_FAILED pid=%u syscall=%d\n", req->pid, req->data.nr);
                } else resp->flags = SECCOMP_USER_NOTIF_FLAG_CONTINUE;
                if (ioctl(listener, SECCOMP_IOCTL_NOTIF_SEND, resp) < 0 && errno != ENOENT) perror("notif send");
            } else if (errno != EINTR && errno != ENOENT) perror("notif recv");
        }
        pid_t result = waitpid(child, &status, WNOHANG);
        if (result == child) break;
    }
    close(listener); free(req); free(resp);
    if (WIFEXITED(status)) return WEXITSTATUS(status);
    if (WIFSIGNALED(status)) return 128 + WTERMSIG(status);
    return 125;
}
