#!/usr/bin/env python3
"""Source-contract and pinned-Intel tests for pending ice sublimation."""
from __future__ import annotations

import gzip
import hashlib
import re
import subprocess
import tempfile
from pathlib import Path

ROOT = Path(__file__).resolve().parents[1]
SOURCE_SHA256 = "8679f2e7c51940ab740bbe9e768dbb68156e9c655f459245f522f7983fb99eb9"


def _source_and_overlay() -> tuple[str, str]:
    import runpy

    archive = ROOT / "docs/evidence/pr87_two_step_v21_20261016/module_mp_kdm6.F.gz"
    original = gzip.decompress(archive.read_bytes()).decode("utf-8")
    assert hashlib.sha256(original.encode()).hexdigest() == SOURCE_SHA256
    overlay = runpy.run_path(str(ROOT / "tools/pr87_ice_sublimation.py"))[
        "extend_ice_sublimation_pending"
    ]
    return original, overlay(original)


def _helper_module(generated: str) -> str:
    fraction_start = generated.index("    subroutine kdm6_rain_process_fraction(")
    fraction_end = generated.index(
        "    end subroutine kdm6_rain_process_fraction", fraction_start
    ) + len("    end subroutine kdm6_rain_process_fraction")
    fraction = generated[fraction_start:fraction_end]
    state_match = re.search(
        r"(?m)^[ \t]*subroutine kdm6_rain_process_state_valid\(", generated
    )
    assert state_match is not None
    state_start = state_match.start()
    state_end = generated.index("end subroutine kdm6_rain_process_state_valid", state_start)
    state = generated[state_start:state_end + len("end subroutine kdm6_rain_process_state_valid")]
    return (
        "module pr87_ice_sublimation_helpers\n"
        "  use, intrinsic :: ieee_arithmetic, only: ieee_is_finite\n"
        "  implicit none\n"
        "  real, parameter :: PR85_ICE_NATIVE_INACTIVE_MAX=nearest(1.e-14,-1.0)\n"
        "contains\n"
        f"{fraction}\n{state}\n"
        "end module pr87_ice_sublimation_helpers\n"
    )


def test_pr87_ice_sublimation_source_contract() -> None:
    original, generated = _source_and_overlay()

    early_reset = (
        "              if(pidep(i,k).eq.-(qci(i,k,2))/dtcld) then\n"
        "                 nci(i,k,2) = 0.\n"
        "              endif\n"
    )
    assert original.count(early_reset) == 1
    assert early_reset not in generated
    reset_guard = (
        "if(pidep(i,k).eq.-(qci(i,k,2))/dtcld) then\n"
        "                 nci(i,k,2) = 0."
    )
    assert reset_guard not in generated
    mutant = generated.replace(
        "if(pidep(i,k).eq.-(qci(i,k,2))/dtcld) then\n"
        "                 ice_full_sublimation_pending(i,k) = .true.",
        "if(pidep(i,k).eq.-(qci(i,k,2))/dtcld) then\n"
        "                 nci(i,k,2) = 0.\n"
        "                 ice_full_sublimation_pending(i,k) = .true.",
        1,
    )
    assert mutant != generated and reset_guard in mutant
    assert "ice_full_sublimation_pending(i,k) = .true." in generated
    assert "if (present(ice_sublimation_pending))" in generated
    assert "ice_sublimation_pending=ice_full_sublimation_pending(i,k)" in generated

    # The cold admission/search sites carry the pending bit. Warm and final
    # stored-state validation retain the strict default contract.
    cold, warm = generated.split("call kdm6_rain_process_fraction(rain_q_before,rain_warm_q_process", 1)
    assert cold.count("ice_sublimation_pending=ice_full_sublimation_pending(i,k)") == 8
    assert "ice_sublimation_pending=ice_full_sublimation_pending(i,k)" not in warm
    stored_check = generated.split("call kdm6_rain_process_state_valid(rain_q_after,rain_n_after,brs(i,k)", 1)[1]
    stored_check = stored_check.split("if (.not.rain_stored_state_feasible)", 1)[0]
    assert "ice_sublimation_pending" not in stored_check

    # The endpoint is paired before the unchanged strict validator and commit.
    endpoint = generated.index("if (ice_full_sublimation_pending(i,k) .and. rain_q_after(2).eq.0.0)")
    strict = generated.index("call kdm6_rain_process_state_valid(rain_q_after,rain_n_after,brs(i,k)", endpoint)
    assert endpoint < strict
    assert "rain_n_after(2)=0.0" in generated[endpoint:strict]
    assert "q(2).gt.0.0 .and. n(2).eq.0.0" not in generated
    assert "gammaComposite" in generated
    assert "n_sed" in generated or "loop,n," in generated


def test_pr87_ice_sublimation_fraction_and_pair_validation() -> None:
    _, generated = _source_and_overlay()
    scratch = Path(tempfile.mkdtemp(prefix="pr87_ice_sublimation_", dir="/var/tmp"))
    module = scratch / "ice_helpers.F90"
    driver = scratch / "driver.F90"
    module.write_text(_helper_module(generated))
    driver.write_text(_DRIVER)

    for profile in ("O0", "O2"):
        build = scratch / profile
        build.mkdir()
        command = [
            "bash", "-c",
            'source "$1/tests/intel_toolchain.sh" && '
            'if [[ "$2" == O0 ]]; then flags=("${CLOUD_BAL_FREE_FLAGS[@]}"); '
            'else flags=("${CLOUD_BAL_REPRO_FLAGS[@]}"); fi && '
            '"$CLOUD_BAL_FC" "${flags[@]}" -free -module "$5" -I "$5" '
            '"$3" "$4" -o "$5/test.exe" && "$5/test.exe"',
            "pr87-ice-sublimation-test", str(ROOT), profile,
            str(module), str(driver), str(build),
        ]
        result = subprocess.run(command, cwd=build, text=True,
                                stdout=subprocess.PIPE, stderr=subprocess.STDOUT,
                                check=False)
        assert result.returncode == 0, result.stdout
        assert "PR87 ice sublimation pending cases PASS" in result.stdout, result.stdout
        print(f"{profile}: {result.stdout.strip()}")


_DRIVER = r"""
program test_pr87_ice_sublimation
  use pr87_ice_sublimation_helpers
  use, intrinsic :: iso_fortran_env, only: int32
  implicit none
  real :: q(5),n(3),qproc(5),nproc(3),fraction
  real :: bg,bgproc,temp,tempproc,qraw,pidep,qafter,nsource,dt
  logical :: valid,feasible
  integer :: status
  integer(int32) :: qafter_bits

  q=0.0; n=0.0; bg=0.0; temp=273.15
  q(2)=0.0; n(2)=4.0
  call state_check(q,n,.false.,valid)
  if (valid) error stop 'unflagged ice orphan accepted'
  call state_check(q,n,.true.,valid)
  if (.not.valid) error stop 'pending exact-zero ice mass rejected'

  q(2)=-1.0e-44
  call state_check(q,n,.true.,valid)
  if (valid) error stop 'negative ice mass accepted under pending flag'
  q(2)=1.0e-44; n(2)=-1.0
  call state_check(q,n,.true.,valid)
  if (valid) error stop 'negative ice number accepted under pending flag'
  q(2)=1.0e-44; n(2)=0.0
  call state_check(q,n,.true.,valid)
  if (valid) error stop 'positive ice mass with zero number accepted'

  ! Preserve source-order REAL32 behavior for the actual full-rate predicate.
  qraw=transfer(int(z'0000003E',int32),0.0)
  nsource=4.0; dt=20.0
  pidep=-qraw/dt
  if (pidep.ne.-qraw/dt) error stop 'exact full-sublimation predicate changed'
  qafter=qraw+dt*pidep
  qafter_bits=transfer(qafter,qafter_bits)
  if (qafter_bits.ne.int(z'00000002',int32)) error stop 'source order no longer leaves Q bits 0x2'
  if (nsource.ne.4.0) error stop 'source-order full-rate test changed NI before endpoint'
  q=0.0; n=0.0; q(2)=qafter; n(2)=nsource
  call state_check(q,n,.true.,valid)
  if (.not.valid) error stop 'strict transient ice pair rejected after source-order rounding'
  n(2)=0.0
  call state_check(q,n,.true.,valid)
  if (valid) error stop 'early-reset mutation accepted positive-QI with zero NI'

  q=0.0; n=0.0; q(2)=1.0e-44; n(2)=4.0
  qproc=0.0; nproc=0.0; qproc(2)=-q(2); bgproc=0.0; tempproc=0.0
  call fraction_check(q,qproc,n,nproc,bg,bgproc,temp,tempproc,.true.,fraction,feasible,status)
  if (.not.feasible .or. status.ne.0 .or. fraction.ne.1.0) &
    error stop 'pending full sublimation endpoint was not admitted'
  q=q+fraction*qproc; n=n+fraction*nproc
  if (q(2).ne.0.0 .or. n(2).ne.4.0) error stop 'search endpoint changed moments'
  if (q(2).eq.0.0) n(2)=0.0
  call state_check(q,n,.false.,valid)
  if (.not.valid) error stop 'paired full-sublimation endpoint rejected'

  q=0.0; n=0.0; q(2)=1.0e-44; n(2)=4.0
  qproc=0.0; nproc=0.0; qproc(2)=-0.5e-44
  call fraction_check(q,qproc,n,nproc,bg,bgproc,temp,tempproc,.true.,fraction,feasible,status)
  if (.not.feasible .or. fraction.ne.1.0) error stop 'partial sublimation fraction changed'
  q=q+fraction*qproc; n=n+fraction*nproc
  if (q(2).eq.0.0 .or. n(2).ne.4.0) error stop 'partial endpoint extinguished number'
  call state_check(q,n,.false.,valid)
  if (.not.valid) error stop 'paired partial-sublimation endpoint rejected'

  print '(a)', 'PR87 ice sublimation pending cases PASS'
contains
  subroutine state_check(qin,nin,pending,ok)
    real, intent(in) :: qin(5),nin(3)
    logical, intent(in) :: pending
    logical, intent(out) :: ok
    call kdm6_rain_process_state_valid(qin,nin,0.0,273.15,1.0,1.0, &
      0.0,0.0,0.0,3.0,1.0,2.0,100.0,900.0,1.0,3.0,1.0,2.0, &
      1.0,3.0,1.0,2.0,ok,consumer_pair_only=.false., &
      ice_transient_mass_limit=PR85_ICE_NATIVE_INACTIVE_MAX, &
      ice_sublimation_pending=pending)
  end subroutine state_check

  subroutine fraction_check(qfixed,qprocess,nfixed,nprocess,bgfixed,bgprocess, &
                            tfixed,tprocess,pending,a,ok,istat)
    real, intent(in) :: qfixed(5),qprocess(5),nfixed(3),nprocess(3)
    real, intent(in) :: bgfixed,bgprocess,tfixed,tprocess
    logical, intent(in) :: pending
    real, intent(out) :: a
    logical, intent(out) :: ok
    integer, intent(out) :: istat
    call kdm6_rain_process_fraction(qfixed,qprocess,nfixed,nprocess, &
      bgfixed,bgprocess,tfixed,tprocess,.false.,1.0,1.0,0.0,0.0, &
      0.0,3.0,1.0,2.0,100.0,900.0,1.0,3.0,1.0,2.0, &
      1.0,3.0,1.0,2.0,a,ok,istat,consumer_pair_only=.false., &
      ice_transient_mass_limit=PR85_ICE_NATIVE_INACTIVE_MAX, &
      ice_sublimation_pending=pending)
  end subroutine fraction_check
end program test_pr87_ice_sublimation
"""


if __name__ == "__main__":
    test_pr87_ice_sublimation_source_contract()
    test_pr87_ice_sublimation_fraction_and_pair_validation()
    print("PR87 ice sublimation tests PASS")
