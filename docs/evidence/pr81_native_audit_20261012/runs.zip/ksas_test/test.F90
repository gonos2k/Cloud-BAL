program test_ksas_dtconv
  implicit none
  integer :: mode
  character(len=16) :: argument
  call get_command_argument(1, argument)
  read(argument, *) mode
  call evaluate(mode)
contains
  subroutine evaluate(mode)
    implicit none
    integer, intent(in) :: mode
    integer :: i, its, ite
    integer :: ktcon1(1:1), kbcon1(1:1)
    logical :: cnvflg(1:1)
    real :: wc(1:1), zi(1:1,1:2), dtconv(1:1), dtmin, dtmax, tfac, tem
    external :: wrf_error_fatal
    its = 1
    ite = 1
    wc = 0.
    zi(1,:) = [5., 15.]
    ktcon1 = 0
    kbcon1 = 0
    dtconv = 3600.
    dtmin = 3.
    dtmax = 10.
    tfac = 4.
    cnvflg = mode /= 0
    if (mode == 1) then
      wc(1) = 2.
      ktcon1(1) = 2
      kbcon1(1) = 1
    else if (mode == 2) then
      wc(1) = 10.
      tfac = 1.
      ktcon1(1) = 2
      kbcon1(1) = 1
    endif
     do i = its,ite
       if (cnvflg(i)) then
         if (wc(i) <= 0.) call wrf_error_fatal('KSAS active convection has nonpositive wc')
         tem = zi(i,ktcon1(i)) - zi(i,kbcon1(i))
         dtconv(i) = tfac * tem / wc(i)
         dtconv(i) = max(dtconv(i),dtmin)
         dtconv(i) = min(dtconv(i),dtmax)
       else
         dtconv(i) = 0.
       endif

     enddo
    select case (mode)
    case (0)
      if (dtconv(1) /= 0.) error stop 1
    case (1)
      if (dtconv(1) /= dtmax) error stop 2
    case (2)
      if (dtconv(1) /= dtmin) error stop 3
    case (3)
      error stop 'active wc=0 did not call WRF fatal'
    end select
  end subroutine evaluate
end program test_ksas_dtconv

subroutine wrf_error_fatal(message)
  implicit none
  character(len=*), intent(in) :: message
  error stop 77
end subroutine wrf_error_fatal
