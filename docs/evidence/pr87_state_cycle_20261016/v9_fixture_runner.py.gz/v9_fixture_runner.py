#!/usr/bin/env python3
"""Compile and exercise the exact PR87 native source-first procedure on ifx."""
from __future__ import annotations

import argparse
import hashlib
import json
import math
import re
import shlex
import struct
import subprocess
import tempfile
from pathlib import Path


ROOT = Path(__file__).resolve().parents[1]
PROFILE = ROOT / "tests/intel_toolchain.sh"
KERNEL = ROOT / "src/common/cloud_bal_joint_transport.f90"
DENSITY_HELPER = ROOT / "tools/pr85_joint_stage_observer.f90"


def sha256(path: Path) -> str:
    digest = hashlib.sha256()
    with path.open("rb") as stream:
        for block in iter(lambda: stream.read(1024 * 1024), b""):
            digest.update(block)
    return digest.hexdigest()


def extract_subroutine(source: str, name: str) -> str:
    start = re.search(rf"^\s*SUBROUTINE\s+{re.escape(name)}\s*\(", source,
                      re.IGNORECASE | re.MULTILINE)
    if not start:
        raise ValueError(f"missing procedure {name}")
    tail = source[start.start():]
    end = re.search(rf"^\s*END\s+SUBROUTINE\s+{re.escape(name)}\b", tail,
                    re.IGNORECASE | re.MULTILINE)
    if not end:
        raise ValueError(f"missing terminator for {name}")
    return tail[:end.end()].strip()


def profile_flags(name: str) -> tuple[str, list[str]]:
    if name not in ("CLOUD_BAL_FREE_FLAGS", "CLOUD_BAL_REPRO_FLAGS"):
        raise ValueError(f"unsupported compiler flags: {name}")
    command = (
        f"source {shlex.quote(str(PROFILE))}; "
        f"printf '%s\\n' \"${{{name}[@]}}\""
    )
    output = subprocess.check_output(["bash", "-lc", command], text=True)
    compiler = subprocess.check_output(
        ["bash", "-lc", f"source {shlex.quote(str(PROFILE))}; printf %s \"$CLOUD_BAL_FC\""],
        text=True,
    ).strip()
    return compiler, output.splitlines()


def source_text(procedure: str, density_helper: str) -> str:
    return f"""MODULE module_state_description
  INTEGER, PARAMETER :: P_QV=1
END MODULE module_state_description

MODULE source_first_test_support
  REAL, SAVE :: q2_state(1:5,1:2,1:4,6),n2_state(1:5,1:2,1:4,5)
CONTAINS
  SUBROUTINE wrf_error_fatal(message)
    CHARACTER(*),INTENT(IN) :: message
    WRITE(*,'(a,1x,a)') 'PR87_EXPECTED_FATAL',TRIM(message)
    WRITE(*,'(a,4(1x,es24.16))') 'PR87_FATAL_ATOMIC_STATE', &
         q2_state(2,1,2,2),q2_state(3,1,2,2),n2_state(2,1,2,1),n2_state(3,1,2,1)
    ERROR STOP 87
  END SUBROUTINE wrf_error_fatal
END MODULE source_first_test_support

MODULE source_first_procedure
  USE module_state_description, ONLY: P_QV
  USE source_first_test_support, ONLY: wrf_error_fatal
CONTAINS
{procedure}
END MODULE source_first_procedure

{density_helper}

SUBROUTINE pr85_pbl_tendency_dump(stage,itimestep,rkstep, &
     ims,ime,jms,jme,kms,kme,its,ite,jts,jte,kts,kte, &
     qv_tend,qc_tend,qi_tend,qnc_tend,qni_tend)
  IMPLICIT NONE
  CHARACTER(*),INTENT(IN) :: stage
  INTEGER,INTENT(IN) :: itimestep,rkstep,ims,ime,jms,jme,kms,kme
  INTEGER,INTENT(IN) :: its,ite,jts,jte,kts,kte
  REAL,INTENT(IN) :: qv_tend(*),qc_tend(*),qi_tend(*),qnc_tend(*),qni_tend(*)
END SUBROUTINE pr85_pbl_tendency_dump

PROGRAM pr87_source_first_fallback_regression
  USE iso_fortran_env, ONLY: real32,real64
  USE source_first_procedure, ONLY: rk_update_joint_moments
  USE source_first_test_support, ONLY: q2_state,n2_state
  IMPLICIT NONE
  INTEGER,PARAMETER :: ims=1,ime=5,jms=1,jme=4,kms=1,kme=2
  INTEGER,PARAMETER :: ids=1,ide=5,jds=1,jde=4,kds=1,kde=2
  INTEGER,PARAMETER :: its=1,ite=4,jts=2,jte=2,kts=1,kte=1
  INTEGER,PARAMETER :: nmoist=6,nscalar=5
  INTEGER :: qindex(4),nindex(4),i,j,k,mode
  REAL(real32) :: q1(ims:ime,kms:kme,jms:jme,nmoist)
  REAL(real32) :: qt(ims:ime,kms:kme,jms:jme,nmoist),n1(ims:ime,kms:kme,jms:jme,nscalar)
  REAL(real32) :: nt(ims:ime,kms:kme,jms:jme,nscalar)
  REAL(real32) :: raw_qsrc(ims:ime,kms:kme,jms:jme,2),raw_nsrc(ims:ime,kms:kme,jms:jme,2)
  REAL(real32) :: coupled_qsrc(ims:ime,kms:kme,jms:jme,2),coupled_nsrc(ims:ime,kms:kme,jms:jme,2)
  REAL(real32) :: source_carrier(ims:ime,kms:kme,jms:jme),dt
  REAL(real32) :: ru(ims:ime,kms:kme,jms:jme),rv(ims:ime,kms:kme,jms:jme)
  REAL(real32) :: ww(ims:ime,kms:kme,jms:jme),muold(ims:ime,jms:jme)
  REAL(real32) :: munew(ims:ime,jms:jme),mub(ims:ime,jms:jme),c1(kms:kme),c2(kms:kme)
  REAL(real32) :: msftx(ims:ime,jms:jme),msfty(ims:ime,jms:jme),rdnw(kms:kme)
  REAL(real32) :: al(ims:ime,kms:kme,jms:jme),alb(ims:ime,kms:kme,jms:jme)
  REAL(real64),PARAMETER :: min_cloud=4.188790204786391e-15_real64
  REAL(real32) :: expected_q,expected_n,carrier
  CHARACTER(32) :: mode_text

  CALL get_command_argument(1,mode_text)
  SELECT CASE(TRIM(mode_text))
  CASE('baseline'); mode=1
  CASE('source_first'); mode=2
  CASE('virtual_donor'); mode=3
  CASE('negative_donor'); mode=4
  CASE('invalid_endpoint'); mode=5
  CASE('no_air'); mode=6
  CASE('stale_step'); mode=7
  CASE('stale_carrier'); mode=8
  CASE('stale_source_ref'); mode=9
  CASE DEFAULT; ERROR STOP 'pass baseline, source_first, virtual_donor, negative_donor, invalid_endpoint, no_air, stale_step, stale_carrier, or stale_source_ref'
  END SELECT

  qindex=[2,3,4,5]; nindex=[1,2,3,4]
  q1=0.0_real32; q2_state=0.0_real32; qt=0.0_real32
  n1=0.0_real32; n2_state=0.0_real32; nt=0.0_real32
  raw_qsrc=0.0_real32; raw_nsrc=0.0_real32
  coupled_qsrc=0.0_real32; coupled_nsrc=0.0_real32
  source_carrier=1.0_real32; dt=1.0_real32
  ru=0.25_real32; rv=0.0_real32; ww=0.0_real32
  muold=0.0_real32; munew=0.0_real32; mub=1.0_real32
  c1=1.0_real32; c2=0.0_real32; rdnw=-1.0_real32
  msftx=1.0_real32; msfty=1.0_real32; al=1.0_real32; alb=0.0_real32
  DO j=jms,jme
    DO k=kms,kme
      DO i=ims,ime
        IF (mode==1.OR.mode==2.OR.mode>=7) THEN
          q1(i,k,j,qindex(1))=REAL(min_cloud*1.0e8_real64,real32)
        ELSE
          q1(i,k,j,qindex(1))=REAL(1.5_real64*min_cloud*1.0e8_real64,real32)
        END IF
        n1(i,k,j,nindex(1))=1.0e8_real32
        IF ((mode==1.OR.mode==2.OR.mode>=7).AND.i==3) &
          q1(i,k,j,qindex(1))=REAL(1.5_real64*min_cloud*1.0e8_real64,real32)
      END DO
    END DO
  END DO
  q2_state=q1; n2_state=n1
  IF (mode==2.OR.mode>=7) THEN
    qt(2,1,2,qindex(1))=REAL(0.125_real64*min_cloud*1.0e8_real64,real32)
    qt(3,1,2,qindex(1))=REAL(-0.5_real64*min_cloud*1.0e8_real64,real32)
  ELSE IF (mode==3) THEN
    qt(2,1,2,qindex(1))=REAL(-0.625_real64*min_cloud*1.0e8_real64,real32)
  ELSE IF (mode==4) THEN
    qt(2,1,2,qindex(1))=REAL(-1.625_real64*min_cloud*1.0e8_real64,real32)
  ELSE IF (mode==5) THEN
    qt(2,1,2,qindex(1))=REAL(-1.0_real64*min_cloud*1.0e8_real64,real32)
  ELSE IF (mode==6) THEN
    carrier=REAL(92363.85_real64,real32)
    expected_q=REAL(3.7537916e-8_real64,real32)
    expected_n=8961516.0_real32
    q1(:,:,:,qindex(1))=expected_q; n1(:,:,:,nindex(1))=expected_n
    muold=0.0_real32; munew=0.0_real32; mub=1.0_real32
    c1=carrier; c2=0.0_real32
    ru=0.0_real32; rv=0.0_real32; ww=0.0_real32
    dt=20.0_real32
    source_carrier=carrier
    raw_qsrc(:,:,:,1)=REAL(-3.059018638396083e-7_real64,real32)/carrier
    raw_nsrc(:,:,:,1)=REAL(-72988600.0_real64,real32)/carrier
    coupled_qsrc(:,:,:,1)=carrier*raw_qsrc(:,:,:,1)
    coupled_nsrc(:,:,:,1)=carrier*raw_nsrc(:,:,:,1)
    qt(:,:,:,qindex(1))=coupled_qsrc(:,:,:,1)
    nt(:,:,:,nindex(1))=coupled_nsrc(:,:,:,1)
  END IF
  IF (mode/=6) THEN
    coupled_qsrc(:,:,:,1)=qt(:,:,:,qindex(1))
    coupled_nsrc(:,:,:,1)=nt(:,:,:,nindex(1))
    raw_qsrc(:,:,:,1)=coupled_qsrc(:,:,:,1)
    raw_nsrc(:,:,:,1)=coupled_nsrc(:,:,:,1)
  END IF
  IF (mode==8) source_carrier(2,1,2)=2.0_real32
  IF (mode==9) coupled_qsrc(2,1,2,1)=coupled_qsrc(2,1,2,1)+1.0_real32
  q2_state=q1; n2_state=n1
  IF (mode==7) THEN
    CALL rk_update_joint_moments(q1,q2_state,n1,n2_state,qt,nt,nmoist,nscalar,qindex,nindex,6,5, &
         ru,rv,ww,muold,munew,mub,c1,c2,msftx,msfty,1.0_real32,1.0_real32,-1.0_real32, &
         al,alb,dt,3,1,1,ids,ide,jds,jde,kds,kde,ims,ime,jms,jme,kms,kme, &
         its,ite,jts,jte,kts,kte,raw_qsrc,raw_nsrc,coupled_qsrc,coupled_nsrc,source_carrier,2)
  ELSE
    CALL rk_update_joint_moments(q1,q2_state,n1,n2_state,qt,nt,nmoist,nscalar,qindex,nindex,6,5, &
         ru,rv,ww,muold,munew,mub,c1,c2,msftx,msfty,1.0_real32,1.0_real32,-1.0_real32, &
         al,alb,dt,3,1,1,ids,ide,jds,jde,kds,kde,ims,ime,jms,jme,kms,kme, &
         its,ite,jts,jte,kts,kte,raw_qsrc,raw_nsrc,coupled_qsrc,coupled_nsrc,source_carrier,1)
  END IF

  IF (mode==1) THEN
    expected_q=REAL(1.375_real64*min_cloud*1.0e8_real64,real32)
    CALL assert_near(q2_state(3,1,2,qindex(1)),expected_q,'baseline flux result')
    CALL assert_near(n2_state(3,1,2,nindex(1)),1.0e8_real32,'baseline number result')
  ELSE
    IF (mode==4.OR.mode==5.OR.mode>=7) ERROR STOP 'rejected source-first candidate unexpectedly completed'
    IF (mode==6) THEN
      expected_q=expected_q+dt*raw_qsrc(2,1,2,1)
      expected_n=expected_n+dt*raw_nsrc(2,1,2,1)
      IF (q2_state(2,1,2,qindex(1))/=expected_q.OR.q2_state(3,1,2,qindex(1))/=expected_q .OR. &
          n2_state(2,1,2,nindex(1))/=expected_n.OR.n2_state(3,1,2,nindex(1))/=expected_n) &
        ERROR STOP 'no-air source-first endpoint was not the R32 intensive stage'
      IF (REAL(expected_q,real64)/REAL(expected_n,real64) < &
          min_cloud-8.0_real64*ABS(REAL(SPACING(REAL(min_cloud,real32)),real64))) &
        ERROR STOP 'no-air R32 staged endpoint fell outside the existing tolerance'
      WRITE(*,'(a,1x,a)') 'PR87_SOURCE_FIRST_FIXTURE_PASS','no_air'
      STOP
    END IF
    IF (mode==3) THEN
      expected_q=REAL(1.03125_real64*min_cloud*1.0e8_real64,real32)
      CALL assert_near(q2_state(2,1,2,qindex(1)),expected_q,'virtual-donor left endpoint')
      expected_q=REAL(1.34375_real64*min_cloud*1.0e8_real64,real32)
      CALL assert_near(q2_state(3,1,2,qindex(1)),expected_q,'virtual-donor right endpoint')
      CALL assert_near(n2_state(2,1,2,nindex(1)),1.0e8_real32,'virtual-donor left number')
      CALL assert_near(n2_state(3,1,2,nindex(1)),1.0e8_real32,'virtual-donor right number')
      expected_q=REAL(2.375_real64*min_cloud*1.0e8_real64,real32)
      CALL assert_near(q2_state(2,1,2,qindex(1))+q2_state(3,1,2,qindex(1)),expected_q, &
                       'out-of-cone virtual donor endpoint conservation')
      WRITE(*,'(a,1x,a)') 'PR87_SOURCE_FIRST_FIXTURE_PASS','virtual_donor'
      STOP
    END IF
    expected_q=REAL(1.09375_real64*min_cloud*1.0e8_real64,real32)
    CALL assert_near(q2_state(2,1,2,qindex(1)),expected_q,'source-first left cloud result')
    expected_q=REAL(1.03125_real64*min_cloud*1.0e8_real64,real32)
    CALL assert_near(q2_state(3,1,2,qindex(1)),expected_q,'source-first right cloud result')
    CALL assert_near(n2_state(2,1,2,nindex(1)),1.0e8_real32,'source-first left number result')
    CALL assert_near(n2_state(3,1,2,nindex(1)),1.0e8_real32,'source-first right number result')
    expected_q=REAL(2.125_real64*min_cloud*1.0e8_real64,real32)
    CALL assert_near(q2_state(2,1,2,qindex(1))+q2_state(3,1,2,qindex(1)),expected_q, &
                     'two-cell source-plus-transport conservation')
  END IF
  WRITE(*,'(a,1x,a)') 'PR87_SOURCE_FIRST_FIXTURE_PASS',TRIM(mode_text)
CONTAINS
  SUBROUTINE assert_near(actual,expected,label)
    REAL(real32),INTENT(IN) :: actual,expected
    CHARACTER(*),INTENT(IN) :: label
    IF (ABS(actual-expected)>8.0_real32*SPACING(expected)) THEN
      WRITE(*,*) 'assertion failed: ',label,actual,expected,SPACING(expected)
      ERROR STOP 'source-first fixture value mismatch'
    END IF
  END SUBROUTINE assert_near
END PROGRAM pr87_source_first_fallback_regression
"""


def run(command: list[str], cwd: Path, log_path: Path) -> subprocess.CompletedProcess[str]:
    shell_command = " ".join(shlex.quote(part) for part in command)
    result = subprocess.run(
        ["bash", "-lc", f"source {shlex.quote(str(PROFILE))}; exec {shell_command}"],
        cwd=cwd, text=True, stdout=subprocess.PIPE, stderr=subprocess.STDOUT,
        check=False,
    )
    log_path.write_text(result.stdout, encoding="utf-8")
    return result


def fallback_flags(path: Path) -> list[bool]:
    lines = [line for line in path.read_text(encoding="utf-8").splitlines()
             if "SOURCE_FIRST_PAIR_FALLBACK" in line]
    if len(lines) != 1:
        raise RuntimeError(f"expected one fallback ledger row in {path}, got {len(lines)}")
    values = re.findall(r"(?<![\w.])(?:\.TRUE\.|\.FALSE\.|T|F)(?![\w.])",
                        lines[0], re.IGNORECASE)
    if len(values) != 4:
        raise RuntimeError(f"could not parse four fallback flags from: {lines[0]}")
    return [value.lower() in ("t", ".true.") for value in values]


def assert_baseline_ledger(path: Path) -> None:
    text = path.read_text(encoding="utf-8")
    if not re.search(r"BASELINE_JOINT_FEASIBLE\s+1\s+3\s+(?:\.TRUE\.|T)(?![A-Z])", text, re.IGNORECASE):
        raise RuntimeError("baseline control did not accept theta=1")
    if fallback_flags(path) != [False, False, False, False]:
        raise RuntimeError("baseline control unexpectedly selected source-first fallback")


def assert_fallback_ledger(path: Path) -> None:
    text = path.read_text(encoding="utf-8")
    if not re.search(r"BASELINE_JOINT_FEASIBLE\s+1\s+3\s+(?:\.FALSE\.|F)(?![A-Z])", text, re.IGNORECASE):
        raise RuntimeError("dyadic control did not reject the original theta=1 candidate")
    if fallback_flags(path) != [True, False, False, False]:
        raise RuntimeError("fallback was not limited to the cloud pair")


def real32(value: float) -> float:
    return struct.unpack("=f", struct.pack("=f", value))[0]


def assert_no_air_source_ledger(path: Path) -> dict[str, list[float]]:
    lines = path.read_text(encoding="utf-8").splitlines()
    starts = [index for index, line in enumerate(lines) if line.strip().startswith("SOURCE_TOTAL")]
    if len(starts) != 1:
        raise RuntimeError(f"expected one source total row, got {starts}")
    row = lines[starts[0]].split()
    values = row[6:]
    for continuation in lines[starts[0] + 1:]:
        if len(values) >= 10 or continuation.strip().startswith("SOURCE_"):
            break
        values.extend(continuation.split())
    if len(row) < 6 or len(values) != 10:
        raise RuntimeError(f"expected one complete source total row, got {row + values}")
    if [int(value) for value in row[1:6]] != [1, 3, 1, 2, 2]:
        raise RuntimeError(f"unexpected no-air source ledger scope: {row[:6]}")
    values = [float(value) for value in values]
    proposal_q, proposal_n, represented_q, represented_n, delta_q, delta_n, \
        l1_q, l1_n, max_q, max_n = values

    carrier = real32(92363.85)
    q0 = real32(3.7537916e-8)
    n0 = real32(8961516.0)
    dt = real32(20.0)
    raw_q = real32(real32(-3.059018638396083e-7) / carrier)
    raw_n = real32(real32(-72988600.0) / carrier)
    coupled_q = real32(carrier * raw_q)
    coupled_n = real32(carrier * raw_n)
    staged_q = real32(q0 + real32(dt * raw_q))
    staged_n = real32(n0 + real32(dt * raw_n))
    expected = {
        "proposal": [2.0 * dt * coupled_q, 2.0 * dt * coupled_n],
        "represented": [2.0 * carrier * (staged_q - q0),
                        2.0 * carrier * (staged_n - n0)],
    }
    expected["delta"] = [b - a for a, b in zip(expected["proposal"], expected["represented"], strict=True)]
    expected["l1"] = [abs(value) for value in expected["delta"]]
    expected["max_abs"] = [abs(value) / 2.0 for value in expected["delta"]]
    observed = {
        "proposal": [proposal_q, proposal_n],
        "represented": [represented_q, represented_n],
        "delta": [delta_q, delta_n],
        "l1": [l1_q, l1_n],
        "max_abs": [max_q, max_n],
    }
    for key, expected_values in expected.items():
        for observed_value, expected_value in zip(observed[key], expected_values, strict=True):
            if not math.isclose(observed_value, expected_value, rel_tol=2.0e-8, abs_tol=1.0e-12):
                raise RuntimeError(f"no-air {key} mismatch: {observed[key]} != {expected_values}")
    return observed


def assert_rejected_without_commit(result: subprocess.CompletedProcess[str], cwd: Path,
                                   expected_message: str, cloud_mass: float | tuple[float, float],
                                   allow_attempt_budget: bool = False) -> dict:
    if result.returncode == 0 or expected_message not in result.stdout:
        raise RuntimeError(f"expected candidate rejection did not occur:\n{result.stdout}")
    matches = [line for line in result.stdout.splitlines()
               if "PR87_FATAL_ATOMIC_STATE" in line]
    if len(matches) != 1:
        raise RuntimeError("fatal stub did not report the pre-commit cloud state")
    values = [float(value) for value in matches[0].split()[1:]]
    cloud_masses = cloud_mass if isinstance(cloud_mass, tuple) else (cloud_mass, cloud_mass)
    expected = [cloud_masses[0], cloud_masses[1], 1.0e8, 1.0e8]
    if len(values) != 4 or any(abs(actual - goal) > 8.0 * abs(goal) * 1.2e-7
                               for actual, goal in zip(values, expected, strict=True)):
        raise RuntimeError(f"fatal path changed q2/n2 before commit: {values}")
    storage = cwd / "pr87_joint_storage.raw"
    transport = cwd / "pr85_joint_transport_budget.raw"
    if storage.exists():
        raise RuntimeError("rejected candidate wrote a committed-storage ledger")
    if transport.exists() and not allow_attempt_budget:
        raise RuntimeError("rejected donor wrote an unexpected transport budget")
    if transport.exists():
        if fallback_flags(transport) != [True, False, False, False]:
            raise RuntimeError("invalid endpoint did not use only the cloud fallback pair")
        budget_text = transport.read_text(encoding="utf-8")
        if not re.search(r"JOINT_RK\s+3\s+2\s+[\d.Ee+-]+\s+[\d.Ee+-]+\s+F(?:\s|$)",
                         budget_text, re.IGNORECASE):
            raise RuntimeError("invalid endpoint was not rejected after the retry")
    return {"status": "PASS_REJECTED_BEFORE_COMMIT", "q2_n2_at_fatal": values,
            "run_log": str(cwd / "run.log"), "run_log_sha256": sha256(cwd / "run.log"),
            "storage_ledger_absent": True,
            "transport_budget_present_for_failed_retry": transport.exists(),
            "transport_budget_sha256": sha256(transport) if transport.exists() else None}


def execute(proposal: Path, receipt_path: Path) -> dict:
    if not proposal.is_file():
        raise ValueError(f"native proposal does not exist: {proposal}")
    proposal_text = proposal.read_text(encoding="utf-8")
    procedure = extract_subroutine(proposal_text, "rk_update_joint_moments")
    observer = DENSITY_HELPER.read_text(encoding="utf-8")
    density_helper = extract_subroutine(observer, "pr85_dry_density_from_al_alb")
    generated_source = source_text(procedure, density_helper)
    scratch = Path(tempfile.mkdtemp(prefix="pr87_source_first_fixture_", dir="/var/tmp"))
    source = scratch / "source_first_fixture.F90"
    source.write_text(generated_source, encoding="utf-8")
    results: dict[str, object] = {}
    for level, profile_flag in (("O0", "CLOUD_BAL_FREE_FLAGS"),
                                ("O2", "CLOUD_BAL_REPRO_FLAGS")):
        compiler, flags = profile_flags(profile_flag)
        build = scratch / level
        build.mkdir()
        exe = build / "source_first_fixture.exe"
        compile_result = run([compiler, *flags, str(KERNEL), str(source), "-o", str(exe)],
                             build, build / "compile.log")
        if compile_result.returncode:
            raise RuntimeError(f"{level} compile failed:\n{compile_result.stdout}")
        modes: dict[str, object] = {}
        for mode in ("baseline", "source_first", "virtual_donor", "no_air",
                     "negative_donor", "invalid_endpoint", "stale_step",
                     "stale_carrier", "stale_source_ref"):
            cwd = build / mode
            cwd.mkdir()
            result = run([str(exe), mode], cwd, cwd / "run.log")
            rejected_modes = ("negative_donor", "invalid_endpoint", "stale_step",
                              "stale_carrier", "stale_source_ref")
            if mode in rejected_modes:
                reasons = {
                    "negative_donor": "PR87 unsafe continuous intensive source donor",
                    "invalid_endpoint": "PR87 full joint moment candidate infeasible",
                    "stale_step": "PR87 intensive source payload is not current or changed after capture",
                    "stale_carrier": "PR87 physical source and old state use different dry carriers",
                    "stale_source_ref": "PR87 coupled source changed since its intensive capture",
                }
                expected_cloud = (1.0 * 4.188790204786391e-15 * 1.0e8,
                                  1.5 * 4.188790204786391e-15 * 1.0e8)
                state = assert_rejected_without_commit(
                    result, cwd, reasons[mode],
                    1.5 * 4.188790204786391e-15 * 1.0e8 if mode in ("negative_donor", "invalid_endpoint")
                    else expected_cloud,
                    allow_attempt_budget=(mode == "invalid_endpoint"))
                modes[mode] = state
                continue
            if result.returncode or f"PR87_SOURCE_FIRST_FIXTURE_PASS {mode}" not in result.stdout:
                raise RuntimeError(f"{level} {mode} run failed:\n{result.stdout}")
            ledger = cwd / "pr85_joint_transport_budget.raw"
            (assert_baseline_ledger if mode == "baseline" else assert_fallback_ledger)(ledger)
            source_representation = None
            if mode == "no_air":
                source_representation = assert_no_air_source_ledger(cwd / "pr87_source_representation.raw")
            modes[mode] = {
                "status": "PASS",
                "run_log_sha256": sha256(cwd / "run.log"),
                "budget_path": str(ledger),
                "budget_sha256": sha256(ledger),
                "fallback_flags": fallback_flags(ledger),
                "source_representation_pressure_amounts": source_representation,
                "run_log": str(cwd / "run.log"),
            }
        results[level] = {
            "compiler": compiler,
            "flags": flags,
            "compiler_sha256": sha256(Path(compiler)),
            "compile_log": str(build / "compile.log"),
            "compile_log_sha256": sha256(build / "compile.log"),
            "executable": str(exe),
            "executable_sha256": sha256(exe),
            "modes": modes,
        }
    evidence = {
        "schema": "pr87_explicit_intensive_source_payload_ifx_v2",
        "status": "PASS_O0_O2",
        "proposal_path": str(proposal),
        "proposal_sha256": sha256(proposal),
        "runner_path": str(Path(__file__).resolve()),
        "runner_sha256": sha256(Path(__file__).resolve()),
        "extracted_procedure": "rk_update_joint_moments",
        "extracted_procedure_sha256": hashlib.sha256(procedure.encode()).hexdigest(),
        "generated_fixture_sha256": sha256(source),
        "kernel_path": str(KERNEL),
        "kernel_sha256": sha256(KERNEL),
        "density_helper_source": str(DENSITY_HELPER),
        "density_helper_source_sha256": sha256(DENSITY_HELPER),
        "density_helper_procedure_sha256": hashlib.sha256(density_helper.encode()).hexdigest(),
        "pinned_profile": str(PROFILE),
        "pinned_profile_sha256": sha256(PROFILE),
        "scratch": str(scratch),
        "fixture_contract": {
            "dimensions": {"i": [1,5], "j": [1,4], "k": [1,2], "active_i": [2,3], "active_j": [2,2], "active_k": [1,1]},
            "registry": {"nmoist": 6, "nscalar": 5, "qindex": [2,3,4,5], "nindex": [1,2,3,4], "qsindex": 6, "nnindex": 5},
            "dry_carrier": "old/new=1 via c1=1,c2=0,muold=munew=0,mub=1",
            "density": "DEN=1 from AL=1, ALB=0 using source-matched helper",
            "horizontal_flux": "ru=+0.25 on all x faces; rv=ww=0; dt=1",
            "explicit_source_payload": {
                "raw_source_arrays": "raw intensive Q/N source rates, REAL32, 4-D pair dimension 2",
                "coupled_source_arrays": "captured extensive Q/N tendencies, REAL32, 4-D pair dimension 2; compared to qt/nt",
                "carrier_and_step": "captured carrier equals old carrier at each active cell; source step must match itimestep",
            },
            "cloud_bounds": {"minimum_particle_mass": 4.188790204786391e-15, "maximum_particle_mass": 3.0300855069345996e-10},
            "dyadic_cases_in_units_of_minimum_mass_times_1e8": {
                "baseline": {
                    "old_cloud_mass": [1.0, 1.5],
                    "old_cloud_number": [1.0, 1.0],
                    "source_cloud_mass": [0.0, 0.0],
                    "theta1_result_cloud_mass": [1.0, 1.375],
                    "source_first_fallback_selected": False,
                },
                "source_first": {
                    "old_cloud_mass": [1.0, 1.5],
                    "old_cloud_number": [1.0, 1.0],
                    "source_cloud_mass": [0.125, -0.5],
                    "source_prepared_mass": [1.125, 1.0],
                    "original_theta1_cloud_mass": [1.125, 0.875],
                    "completed_fallback_cloud_mass": [1.09375, 1.03125],
                    "completed_cloud_number": [1.0, 1.0],
                    "completed_mass_sum": 2.125,
                    "source_first_fallback_selected": True,
                    "selected_pair": "cloud (Q index 2, N index 1)",
                },
                "virtual_donor": {
                    "old_cloud_mass": [1.5, 1.5],
                    "old_cloud_number": [1.0, 1.0],
                    "source_cloud_mass": [-0.625, 0.0],
                    "source_prepared_mass": [0.875, 1.5],
                    "original_theta1_cloud_mass": [0.875, 1.5],
                    "completed_fallback_cloud_mass": [1.03125, 1.34375],
                    "completed_cloud_number": [1.0, 1.0],
                    "completed_mass_sum": 2.375,
                    "source_first_fallback_selected": True,
                    "intermediate_outside_psd_cone": True,
                    "final_endpoint_passes_psd_cone": True,
                },
                "negative_donor": {
                    "old_cloud_mass": [1.5, 1.5],
                    "source_cloud_mass": [-1.625, 0.0],
                    "source_prepared_mass": [-0.125, 1.5],
                    "expected_result": "reject before commit and preserve q2/n2",
                },
                "invalid_endpoint": {
                    "old_cloud_mass": [1.5, 1.5],
                    "source_cloud_mass": [-1.0, 0.0],
                    "source_prepared_mass": [0.5, 1.5],
                    "expected_final_cloud_mass": [0.75, 1.25],
                    "final_endpoint_passes_psd_cone": False,
                    "expected_result": "reject before commit and preserve q2/n2",
                },
                "no_air": {
                    "kind": "manufactured no-air regression using supplied numeric fixture; not a native-cell replay",
                    "carrier": 92363.85,
                    "old_q": 3.7537916e-8,
                    "old_n": 8961516.0,
                    "dt": 20.0,
                    "raw_q_source": "REAL32(REAL32(-3.059018638396083e-7)/W)",
                    "raw_n_source": "REAL32(REAL32(-72988600)/W)",
                    "baseline_weighted_q_over_n_gap_r32_ulp": 8.160412680357695,
                    "intensive_r32_stored_q_over_n_gap_r32_ulp": 7.263443915173411,
                    "expected": "baseline theta=1 rejects; source-first stage is accepted within existing 8-ULP bound and bit-equal to the no-air final state",
                    "ledger_units": "pressure-carrier amounts; original dt*coupled source versus W*(staged-old), signed delta, L1, and max absolute delta; no kg or energy interpretation",
                },
                "stale_payload_rejections": {
                    "stale_step": "reject before commit",
                    "stale_carrier": "reject before commit",
                    "stale_source_ref": "reject before commit",
                },
            },
        },
        "results": results,
    }
    receipt_path.parent.mkdir(parents=True, exist_ok=True)
    receipt_path.write_text(json.dumps(evidence, indent=2, sort_keys=True) + "\n", encoding="utf-8")
    return evidence


def main() -> int:
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--proposal", type=Path, required=True,
                        help="exact generated native_update.f90 from the candidate source manifest")
    parser.add_argument("--receipt", type=Path, required=True,
                        help="new receipt path; existing files are never overwritten")
    args = parser.parse_args()
    if args.receipt.exists():
        parser.error(f"receipt already exists; choose a new path: {args.receipt}")
    evidence = execute(args.proposal, args.receipt)
    print(f"{evidence['status']}: {args.receipt}")
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
