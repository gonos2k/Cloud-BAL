from __future__ import annotations

import sys
from pathlib import Path

import pytest

sys.path.insert(0, str(Path(__file__).resolve().parents[1] / "tools"))

from pr87_pbl_source_payload import (  # noqa: E402
    PINNED_SHA256,
    _instrument_fragment,
    _instrument_part1,
    _instrument_part2,
    _instrument_pbl_driver,
    _instrument_solve,
    _require_hashes,
)


SOLVE = """SUBROUTINE solve_em
   USE, INTRINSIC :: iso_fortran_env, ONLY: real64
   IMPLICIT NONE
   INTEGER                         :: ij , iteration
CALL first_rk_step_part1(grid)
CALL first_rk_step_part2(grid)
CALL rk_update_joint_moments(state)
END SUBROUTINE solve_em
"""

PART1 = """SUBROUTINE first_rk_step_part1 ( grid                 &
                             , feedback_is_ready                &
                            )
    USE module_state_description
    LOGICAL, INTENT(IN), OPTIONAL :: feedback_is_ready  ! For WRF-CMAQ coupled model, indicates feedback information is available
CALL pbl_driver(grid)
END SUBROUTINE first_rk_step_part1
"""

PBL_DRIVER = """SUBROUTINE pbl_driver(              &
              ,QNORM, fasdas, mp_physics &
!\n! END FASDAS\n!\n                                                                     )
   USE module_model_constants
    REAL , OPTIONAL   ,DIMENSION(ims:ime,kms:kme,jms:jme,num_scalar),INTENT(INOUT)   :: scalar_tend
CALL shinhong(grid)
END SUBROUTINE pbl_driver
"""

PART2 = """SUBROUTINE first_rk_step_part2 (grid &
                             , pr87_source_carrier, pr87_source_step    &
                            )
    USE module_state_description
    INTEGER, INTENT(OUT) :: pr87_source_step
   rk_step = 1
END SUBROUTINE first_rk_step_part2
"""

FRAGMENT = """SUBROUTINE rk_update_joint_moments( &
     pr87_cloud_rain_diffusion_delta,pr87_cloud_rain_diffusion_step)
  USE iso_fortran_env, ONLY: real32,real64
  USE, INTRINSIC :: ieee_arithmetic, ONLY: ieee_is_finite
  IMPLICIT NONE
  INTEGER,INTENT(IN) :: itimestep,pr87_source_step
  INTEGER,INTENT(IN),OPTIONAL :: pr87_cloud_rain_diffusion_step
  REAL(real64),ALLOCATABLE :: qs64(:,:),ns64(:,:)
  REAL(real64) :: outflow,cfl,maxcfl,source_candidate(2),source_sum64(2)
  REAL(real32) :: source_rate32(2),source_increment32(2),source_endpoint32(2),source_stored(2)
  IF (spec_zone/=1.OR.il>ih.OR.jl>jh.OR.kl>kh) &
    CALL wrf_error_fatal('PR85 joint update unsupported domain footprint')
      qs64(cell,p)=REAL(qs(cell,p),real64); ns64(cell,p)=REAL(ns(cell,p),real64)
        source_rate32=[pr87_raw_qsrc(i,k,j,p),pr87_raw_nsrc(i,k,j,p)]
        source_candidate=[REAL(q1(i,k,j,qindex(p)),real64), &
                          REAL(n1(i,k,j,nindex(p)),real64)]+REAL(dt,real64)*REAL(source_rate32,real64)
        source_sum64=REAL(dt,real64)*REAL(source_rate32,real64)
        source_increment32=dt*source_rate32
        source_endpoint32=[q1(i,k,j,qindex(p)),n1(i,k,j,nindex(p))]+source_increment32
END SUBROUTINE rk_update_joint_moments
"""


def test_solve_owns_step_local_payload_and_forwards_every_boundary() -> None:
    generated = _instrument_solve(SOLVE)
    allocate = generated.index("ALLOCATE(pr87_pbl_tendency_delta64(ims:ime,kms:kme,jms:jme,4))")
    zero = generated.index("pr87_pbl_tendency_delta64 = 0.0_real64")
    producer = generated.index("CALL first_rk_step_part1")
    consumer = generated.index("CALL rk_update_joint_moments")
    assert allocate < zero < producer < consumer
    assert "pr87_pbl_tendency_step = grid%itimestep" in generated
    assert "pr87_pbl_tendency_phase = 1" in generated
    assert "pr87_pbl_tendency_delta64=pr87_pbl_tendency_delta64" in generated
    assert generated.count(", pr87_pbl_tendency_delta64, pr87_pbl_tendency_step") == 2


def test_part1_pbl_driver_shinhong_route_is_explicit_and_legacy_fields_are_untouched() -> None:
    part1 = _instrument_part1(PART1)
    pbl = _instrument_pbl_driver(PBL_DRIVER)
    assert "pr87_pbl_tendency_delta64(ims:ime,kms:kme,jms:jme,4)" in part1
    assert "PR87_TENDENCY_DELTA64=pr87_pbl_tendency_delta64" in part1
    assert "REAL(real64), INTENT(INOUT) :: pr87_tendency_delta64" in pbl
    assert "PR87_TENDENCY_DELTA64=pr87_tendency_delta64" in pbl
    assert "moist_tend" not in part1
    assert pbl.count(":: scalar_tend") == PBL_DRIVER.count(":: scalar_tend")
    assert "scalar_tend=" not in pbl


def test_part2_checks_payload_epoch_without_modifying_it() -> None:
    generated = _instrument_part2(PART2)
    assert "REAL(real64), INTENT(IN) :: pr87_pbl_tendency_delta64" in generated
    assert "pr87_pbl_tendency_step /= grid%itimestep" in generated
    assert "pr87_pbl_tendency_phase /= 1" in generated
    assert "pr87_pbl_tendency_delta64 =" not in generated


def test_native_uses_weighted_raw_delta_and_later_terms_once() -> None:
    generated = _instrument_fragment(FRAGMENT)
    assert "(REAL(pr87_raw_qsrc(i,k,j,p),real64)+ &" in generated
    assert "pr87_pbl_tendency_delta64(i,k,j,1))*REAL(pr87_source_carrier(i,k,j),real64)+ &" in generated
    assert "pr87_later_qsrc(i,k,j,p)" in generated
    assert "pr87_pbl_tendency_delta64(i,k,j,2))*REAL(pr87_source_carrier(i,k,j),real64)+ &" in generated
    assert "source_rate64=source_rate64+ &" in generated
    assert "source_candidate=[REAL(q1(i,k,j,qindex(p)),real64), &" in generated
    assert "REAL(dt,real64)*source_rate64" in generated
    assert "volume_number_bounds=number_bounds(cell,:,p)" in generated
    assert "pr87_cloud_rain_diffusion_delta(i,k,j,1)" not in generated
    assert "pbl_source_correction_sum(pbl_channel)+pbl_delta" in generated
    assert "pbl_delta=REAL(dt,real64)*pr87_source_carrier(i,k,j)*" in generated
    assert "'PR87_PBL_SOURCE_CORRECTION_RK', &\n       itimestep,rk" in generated
    assert "pbl_carrier_min,pbl_carrier_max" in generated
    assert "pbl_source_correction_l1,pbl_source_correction_max" in generated
    assert "PR87 PBL source carrier mismatch" not in generated
    assert "pr87_pbl_tendency_step/=itimestep" in generated
    assert "pr87_pbl_tendency_phase/=1" in generated


def test_source_pins_are_fail_closed() -> None:
    sources = {name: "source" for name in PINNED_SHA256}
    with pytest.raises(ValueError, match="SHA-256 mismatch"):
        _require_hashes(sources)
