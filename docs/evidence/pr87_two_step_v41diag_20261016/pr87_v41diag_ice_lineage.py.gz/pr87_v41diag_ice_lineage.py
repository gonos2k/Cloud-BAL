import gzip
import hashlib
import json
import math
import struct
from pathlib import Path

RUN = Path('/var/tmp/pr87_joint_OFF_60s_v41diag_20261016')
SOURCE = Path('/var/tmp/pr87_joint_cycle_sources_20261016_v41diag/module_mp_kdm6.F')
TARGETS = json.load(open('/var/tmp/pr87_v39_review_20261016.json'))['ice_gate_context']['cells']

def sha(path):
    h = hashlib.sha256()
    with open(path, 'rb') as f:
        for b in iter(lambda: f.read(1 << 20), b''):
            h.update(b)
    return h.hexdigest()

def f32(x):
    return struct.unpack('=f', struct.pack('=f', float(x)))[0]
def add(a, b): return f32(f32(a) + f32(b))
def sub(a, b): return f32(f32(a) - f32(b))
def mul(a, b): return f32(f32(a) * f32(b))

def q2_after(q0, rates, dt):
    # Source-ordered REAL32 expression at native_update.f90's rain_q_after(2).
    term = add(rates[10], rates[28])  # psaut + praci
    term = add(term, rates[11])       # + psaci
    term = add(term, rates[33])       # + pgaci
    for idx in (9, 8, 1, 2, 3, 4, 5):
        term = sub(term, rates[idx])
    return sub(q0, mul(term, dt))

def n2_after(n0, rates, dt):
    # Source-ordered REAL32 expression at native_update.f90's rain_n_after(2).
    term = f32(-rates[36])
    for idx, sign in ((20,-1), (40,-1), (37,-1), (15,1), (16,1),
                      (17,1), (18,1), (19,1), (21,-1)):
        term = add(term, f32(sign * rates[idx]))
    return add(n0, mul(term, dt))

receipt = json.load(open(RUN / 'receipt.json'))
run_dir = RUN / 'run'
ledger_path = run_dir / 'pr85_kdm6_cold_budget.raw.gz'
records = {}
for line in gzip.open(ledger_path, 'rt'):
    t = line.split()
    if not t or t[0] != 'PR87_KDM6_COLD_T2':
        continue
    ints = list(map(int, t[1:10]))
    step, i, lat, k, loop, ng_status, aut_status, g_status, retry = ints
    if step != 2:
        continue
    v = [float(x.replace('D','E')) for x in t[11:]]
    key = (i, lat, k)
    if key in records:
        raise RuntimeError(f'duplicate T2 cold record: {key}')
    if len(v) != 207 or not all(math.isfinite(x) for x in v):
        raise RuntimeError(f'bad value row at {key}: {len(v)} values')
    records[key] = (ints, t[10], v)

pending = set()
for line in gzip.open(run_dir / 'pr87_ice_sublimation_pending.raw.gz', 'rt'):
    t = line.split()
    if t and t[0] == 'PR87_ICE_SUBLIMATION':
        step, i, lat, k, loop = map(int, t[1:6])
        if step == 2:
            pending.add((i, lat, k))

warm_rows = []
for line in gzip.open(run_dir / 'pr85_kdm6_warm_budget.raw.gz', 'rt'):
    t = line.split()
    if t and t[0] == 'PR87_KDM6_WARM_T2':
        warm_rows.append(t)

rate_names = 'pracw piacw pmulcs pmulcg pmulrs pmulrg prevp psdep pidep pinud psaut psaci nccol nracw niacw ninud nmulcs nmulcg nmulrs nmulrg nsaci nsaut nrcol praut nraut paacw naacw pracs praci piacr psacr pgacr pgdep pgaci pgaut pgacs nraci niacr nsacr ngacr ngaci'.split()
review_cells = {(int(c['i']), int(c['j']), int(c['k'])): c for c in TARGETS}
if len(review_cells) != 13:
    raise RuntimeError(f'expected 13 V39 targets; found {len(review_cells)}')

rows = []
for key, review in review_cells.items():
    if key not in records:
        raise RuntimeError(f'missing T2 cold record: {key}')
    ints, noop, v = records[key]
    step, i, lat, k, loop, ng_status, aut_status, g_status, retry = ints
    gamma = f32(v[2])
    alpha_ng = f32(v[44])
    alpha_initial = f32(alpha_ng / gamma)
    dt = f32(v[0])
    q0 = f32(v[48])
    q_after = f32(v[63])
    n0 = f32(v[68])
    n_after = f32(v[77])
    rho = f32(v[1])
    q_process_ice = f32(v[95])
    rates_at_gamma = [f32(x) for x in v[3:44]]
    rates_at_gamma_are_exact_r32 = all(float(f32(x)) == x for x in v[3:44])
    rates_gamma1 = [f32(x / gamma) for x in rates_at_gamma]
    gamma_roundtrip_exact = all(f32(x * gamma) == y for x, y in zip(rates_gamma1, rates_at_gamma))
    nonzero_rates = [rate_names[idx] for idx, x in enumerate(rates_gamma1) if x != 0.0]
    q_gamma_half_replay = q2_after(q0, rates_at_gamma, dt)
    q_gamma_one_replay = q2_after(q0, rates_gamma1, dt)
    n_gamma_one_replay = n2_after(n0, rates_gamma1, dt)
    cap = f32(-q0 / dt)
    expected_pidep_after_alpha = f32(cap * alpha_initial)
    pidep_after_alpha = rates_gamma1[8]
    public_ni = f32(n_after / rho)
    q_proc_is_full_removal = q_process_ice == -q0
    target_has_pending_event = key in pending
    if not (ng_status == 0 and aut_status == 0 and g_status == 0 and retry == 1):
        raise RuntimeError(f'unexpected admission statuses at {key}: {ints}')
    if not (gamma == 0.5 and alpha_initial == f32(0.9999999403953552)):
        raise RuntimeError(f'unexpected gamma/initial-alpha at {key}: {gamma}, {alpha_initial}')
    if not (q_gamma_half_replay == q_after and q_gamma_one_replay == 0.0):
        raise RuntimeError(f'R32 source-order replay mismatch at {key}: {q_gamma_half_replay}, {q_after}, {q_gamma_one_replay}')
    if not (n_gamma_one_replay == n0 == n_after and n_after > 0.0):
        raise RuntimeError(f'number unchanged replay mismatch at {key}')
    if not q_proc_is_full_removal:
        raise RuntimeError(f'NG ice request is not full removal at {key}: {q_process_ice}, {-q0}')
    if target_has_pending_event:
        raise RuntimeError(f'unexpected pending event at target {key}')
    if not rates_at_gamma_are_exact_r32 or not gamma_roundtrip_exact:
        raise RuntimeError(f'ledger rates do not round-trip through REAL32 at {key}')
    pidep_matches_cap_alpha = (pidep_after_alpha == expected_pidep_after_alpha)
    if f32(q_after) != f32(review['QI']) or public_ni != f32(review['NI']):
        raise RuntimeError(f'final pair does not match V39 review at {key}')
    rows.append({
        'i': i, 'lat': lat, 'k': k, 'step': step, 'loop': loop,
        'ng_search_status': ng_status, 'aut_search_status': aut_status,
        'g_search_status': g_status, 'cold_stored_noop': (noop == 'T'),
        'q_before': q0, 'q_after': q_after,
        'internal_ice_number_volume_before': n0,
        'internal_ice_number_volume_after': n_after,
        'rho_dry': rho, 'stage_public_ice_number': public_ni,
        'ng_request_qi': q_process_ice,
        'ng_alpha_at_gamma_half': alpha_ng,
        'inferred_ng_alpha_before_composite_gamma': alpha_initial,
        'composite_gamma': gamma, 'composite_retry': retry,
        'candidate_gamma1_q_after_source_order': q_gamma_one_replay,
        'candidate_gamma1_n_after_source_order': n_gamma_one_replay,
        'candidate_gamma_half_q_after_source_order': q_gamma_half_replay,
        'pidep_rate_at_gamma1_after_ng_alpha': pidep_after_alpha,
        'pidep_rate_capped_at_full_removal_before_ng_alpha': cap,
        'nonzero_composite_rate_fields_at_gamma1': nonzero_rates,
        'pending_event_row_present': target_has_pending_event,
        'pidep_rate_matches_full_removal_cap_times_ng_alpha': pidep_matches_cap_alpha,
        'match_v39_post_qi': True, 'match_v39_post_public_ni': True,
    })

if len(rows) != 13 or len(warm_rows) != 0:
    raise RuntimeError(f'expected 13 target cold rows and no warm rows; got {len(rows)}, {len(warm_rows)}')

artifacts = {}
for name in ['pr85_kdm6_cold_budget.raw.gz','pr85_kdm6_warm_budget.raw.gz','pr87_ice_sublimation_pending.raw.gz']:
    p = run_dir / name
    artifacts[name] = {'sha256': sha(p), 'bytes': p.stat().st_size}

report = {
    'schema': 'pr87_v41diag_cold_ice_producer_lineage_v1',
    'scope': 'Closed OFF step-2 T2 cold records for the 13 V39 post-ice outliers; this diagnoses the cold producer path, not a full run or a physics approval.',
    'run': {
        'receipt_path': str(RUN / 'receipt.json'),
        'receipt_sha256': sha(RUN / 'receipt.json'),
        'status': receipt['status'], 'returncode': receipt['returncode'],
        'final_completed_step': receipt['final_completed_step'],
        'maximum_seen_timestep': receipt['maximum_seen_timestep'],
        'candidate_build_receipt_sha256': receipt['candidate_build']['receipt_sha256'],
        'executed_executable_sha256': receipt['executed_executable_sha256'],
        'source_receipt_sha256': receipt['source_receipt_sha256'],
    },
    'source': {'path': str(SOURCE), 'sha256': sha(SOURCE)},
    'artifacts': artifacts,
    'target_count': len(rows),
    'native_composite_rate_component_order': rate_names,
    'warm_target_rows': len(warm_rows),
    'pending_ledger_target_rows': 0,
    'findings': {
        'all_13_cold_rows_have_full_ice_mass_request': True,
        'all_13_have_ng_alpha_initial_next_float_below_one': True,
        'all_13_gamma1_source_order_replay_rounds_ice_q_to_zero': True,
        'all_13_gamma1_replay_preserves_positive_ice_number_volume': True,
        'all_13_gamma_half_source_order_replay_matches_actual_half_q': True,
        'all_13_have_negative_pidep_composite_rate': all(r['pidep_rate_at_gamma1_after_ng_alpha'] < 0.0 for r in rows),
        'pidep_matches_full_removal_cap_times_alpha_count': sum(r['pidep_rate_matches_full_removal_cap_times_ng_alpha'] for r in rows),
        'targets_with_psaci_contributing_to_ice_q_removal': [
            [r['i'], r['lat'], r['k']] for r in rows if 'psaci' in r['nonzero_composite_rate_fields_at_gamma1']
        ],
        'pidep_cap_alpha_match_count': sum(r['pidep_rate_matches_full_removal_cap_times_ng_alpha'] for r in rows),
        'all_13_target_pending_flags_remained_false_through_cold_commit': True,
        'all_13_step2_post_values_match_v39_qi_and_public_ni': True,
    },
    'interpretation': {
        'source_order': 'Cold KDM6 sets ice_full_sublimation_pending only when raw pidep is exactly -(qci(2))/dtcld, before max-capping; it then caps with max(pidep,-qci(2)/dtcld). The cold row shows the capped full-removal Pidep, then the near-one NG alpha and outer gamma.',
        'target_rows': 'For every target, the exact REAL32 source-order replay of the complete 41-rate vector at gamma=1 produces QI=0 while ice number volume remains positive. The total nongraupel QI request is -QI_before. Ten rows have a Pidep component matching the full-removal cap times NG alpha; three rows also have a positive psaci ice-Q loss contribution, so Pidep alone is below that cap while the aggregate still removes the full ice mass. There is no pending-event row for any target.',
        'failure_and_retry': 'The unchanged state validator rejects Q=0,N>0 with pending=false as failure reason 3 (orphan pair). At gamma=0.5, Q remains positive but below PR85_ICE_NATIVE_INACTIVE_MAX=NEAREST(1.e-14,-1), so the validator skips the ice PSD cone check and accepts positive Q,N. The recorded retry=1 and gamma=0.5 match this source path.',
        'raw_rate_inference': 'The raw Pidep input itself is not in the cold ledger. For the 10 rows where the logged Pidep component matches the full-removal cap times NG alpha, the source equality test would have marked pending if raw Pidep equaled -QI/dt; because no event was recorded, raw Pidep did not equal the cap (and the max-cap implies it was at or below it). The other three rows have a psaci contribution to the aggregate ice-Q removal; their full endpoint is not attributable to Pidep alone. The established cause across all 13 is the total accepted composite endpoint reaching QI=0 with N still positive and the pending flag false.',
        'limit': 'The run is INCOMPLETE after step 2 and aborts at timestep 3 RK1. Evidence establishes the step-2 cold source sequence and R32 replay for these 13 cells; it is not evidence of full-run completion or global PSD approval.',
    },
    'rows': rows,
}
out=Path('/var/tmp/pr87_v41diag_ice_lineage_20261016.json')
out.write_text(json.dumps(report, indent=2, sort_keys=True)+'\n')
print(out)
print('rows', len(rows), 'status', receipt['status'], 'cold_sha', artifacts['pr85_kdm6_cold_budget.raw.gz']['sha256'])
