#!/usr/bin/env python3
"""Reproduce the read-only PR87 V13 warm-endpoint failure probe."""
from __future__ import annotations
import hashlib
from pathlib import Path

BASE_SHA256 = "52c3cab9ec72113ef66c01046abf79febaba7aeabeb5a7bae7b632ced254f31e"


def replace_once(text: str, old: str, new: str, label: str) -> str:
    if text.count(old) != 1:
        raise ValueError(f"{label}: expected exactly one source anchor")
    return text.replace(old, new, 1)


def generate(source: str) -> str:
    if hashlib.sha256(source.encode()).hexdigest() != BASE_SHA256:
        raise ValueError("V13 preprocessed KDM6 source identity mismatch")
    source = replace_once(
        source,
        "   real                               :: rain_warm_qv_process,rain_warm_alpha\n",
        "   real                               :: rain_warm_qv_process,rain_warm_alpha\n"
        "   real :: pr87_warm_alpha_initial,pr87_warm_last_alpha\n"
        "   real :: pr87_warm_last_bg,pr87_warm_last_t,pr87_warm_last_qv,pr87_warm_last_ccn3\n"
        "   real, dimension(5) :: pr87_warm_last_q\n"
        "   real, dimension(3) :: pr87_warm_last_n\n"
        "   real, dimension(16) :: pr87_warm_last_rate\n"
        "   integer :: pr87_warm_search_status_initial,pr87_warm_last_retry\n"
        "   logical :: pr87_warm_feasible_initial,pr87_warm_last_valid\n",
        "declarations",
    )
    call_end = (
        "                 rain_warm_feasible,rain_warm_search_status,rain_qv_before, &\n"
        "                 rain_warm_qv_process,consumer_pair_only=.true.,require_rain_psd=.true.)\n"
    )
    source = replace_once(source, call_end, call_end +
        "            pr87_warm_alpha_initial=rain_warm_alpha\n"
        "            pr87_warm_search_status_initial=rain_warm_search_status\n"
        "            pr87_warm_feasible_initial=rain_warm_feasible\n", "capture fraction result")
    loop_start = (
        "            rain_warm_abort=.false.\n            rain_warm_state_valid=.false.\n"
        "            do rain_warm_retry=0,56\n"
    )
    source = replace_once(source, loop_start,
        "            rain_warm_abort=.false.\n            rain_warm_state_valid=.false.\n"
        "            pr87_warm_last_alpha=rain_warm_alpha\n"
        "            pr87_warm_last_rate=0.0\n"
        "            pr87_warm_last_q=rain_q_before\n"
        "            pr87_warm_last_n=rain_n_before\n"
        "            pr87_warm_last_bg=rain_bg_before\n"
        "            pr87_warm_last_t=rain_t_before\n"
        "            pr87_warm_last_qv=rain_qv_before\n"
        "            pr87_warm_last_ccn3=rain_ccn3_before\n"
        "            pr87_warm_last_retry=-1\n"
        "            pr87_warm_last_valid=.false.\n"
        "            do rain_warm_retry=0,56\n", "initialize trial snapshot")
    trial_anchor = (
        "              if (rain_warm_state_valid .and. rain_warm_qv_after.ge.0.0 .and. &\n"
        "                  rain_ccn3_after.ge.0.0) exit\n"
    )
    trial_snapshot = (
        "              pr87_warm_last_alpha=rain_warm_alpha\n"
        "              pr87_warm_last_rate=rain_warm_rate_trial\n"
        "              pr87_warm_last_q=rain_warm_q_after\n"
        "              pr87_warm_last_n=rain_warm_n_after\n"
        "              pr87_warm_last_bg=rain_warm_bg_after\n"
        "              pr87_warm_last_t=rain_warm_t_after\n"
        "              pr87_warm_last_qv=rain_warm_qv_after\n"
        "              pr87_warm_last_ccn3=rain_ccn3_after\n"
        "              pr87_warm_last_retry=rain_warm_retry\n"
        "              pr87_warm_last_valid=rain_warm_state_valid .and. &\n"
        "                   rain_warm_qv_after.ge.0.0 .and. rain_ccn3_after.ge.0.0\n"
    )
    source = replace_once(source, trial_anchor, trial_snapshot + trial_anchor, "capture last trial")
    # Replace the first exact fatal guard with writes only; preserve the original rejection.
    fatal = "            if (rain_warm_abort) error stop 'KDM6 warm native endpoint search failed'\n"
    diagnostic = (
        "            if (rain_warm_abort) then\n"
        "              write(*,'(a,9(1x,i0))') 'PR87_WARM_FAIL_LOC_STATUS', &\n"
        "                   pr87_model_timestep,lat,i,k,loop,pr87_warm_search_status_initial, &\n"
        "                   rain_warm_search_status,rain_warm_retry,pr87_warm_last_retry\n"
        "              write(*,'(a,2(1x,l1))') 'PR87_WARM_FAIL_FEASIBLE', &\n"
        "                   pr87_warm_feasible_initial,pr87_warm_last_valid\n"
        "              write(*,'(a,2(1x,es24.16))') 'PR87_WARM_FAIL_ALPHA', &\n"
        "                   pr87_warm_alpha_initial,pr87_warm_last_alpha\n"
        "              write(*,'(a,5(1x,es16.8))') 'PR87_WARM_FAIL_BASE_Q',rain_q_before\n"
        "              write(*,'(a,3(1x,es16.8))') 'PR87_WARM_FAIL_BASE_N',rain_n_before\n"
        "              write(*,'(a,4(1x,es16.8))') 'PR87_WARM_FAIL_BASE_ENV', &\n"
        "                   rain_bg_before,rain_t_before,rain_qv_before,rain_ccn3_before\n"
        "              write(*,'(a,5(1x,es16.8))') 'PR87_WARM_FAIL_PROCESS_Q',rain_warm_q_process\n"
        "              write(*,'(a,3(1x,es16.8))') 'PR87_WARM_FAIL_PROCESS_N',rain_warm_n_process\n"
        "              write(*,'(a,3(1x,es16.8))') 'PR87_WARM_FAIL_PROCESS_ENV', &\n"
        "                   rain_warm_bg_process,rain_warm_t_process,rain_warm_qv_process\n"
        "              write(*,'(a,8(1x,es16.8))') 'PR87_WARM_FAIL_RATE_BASE_1',rain_warm_rate_base(1:8)\n"
        "              write(*,'(a,8(1x,es16.8))') 'PR87_WARM_FAIL_RATE_BASE_2',rain_warm_rate_base(9:16)\n"
        "              write(*,'(a,8(1x,es16.8))') 'PR87_WARM_FAIL_LAST_RATE_1',pr87_warm_last_rate(1:8)\n"
        "              write(*,'(a,8(1x,es16.8))') 'PR87_WARM_FAIL_LAST_RATE_2',pr87_warm_last_rate(9:16)\n"
        "              write(*,'(a,5(1x,es16.8))') 'PR87_WARM_FAIL_LAST_Q',pr87_warm_last_q\n"
        "              write(*,'(a,3(1x,es16.8))') 'PR87_WARM_FAIL_LAST_N',pr87_warm_last_n\n"
        "              write(*,'(a,4(1x,es16.8))') 'PR87_WARM_FAIL_LAST_ENV', &\n"
        "                   pr87_warm_last_bg,pr87_warm_last_t,pr87_warm_last_qv,pr87_warm_last_ccn3\n"
        "              write(*,'(a,6(1x,z8.8))') 'PR87_WARM_FAIL_BASE_HEX_1', &\n"
        "                   transfer([rain_q_before(1:5),rain_n_before(1)],[0],6)\n"
        "              write(*,'(a,6(1x,z8.8))') 'PR87_WARM_FAIL_BASE_HEX_2', &\n"
        "                   transfer([rain_n_before(2:3),rain_bg_before,rain_t_before, &\n"
        "                   rain_qv_before,rain_ccn3_before],[0],6)\n"
        "              write(*,'(a,6(1x,z8.8))') 'PR87_WARM_FAIL_LAST_HEX_1', &\n"
        "                   transfer([pr87_warm_last_q(1:5),pr87_warm_last_n(1)],[0],6)\n"
        "              write(*,'(a,6(1x,z8.8))') 'PR87_WARM_FAIL_LAST_HEX_2', &\n"
        "                   transfer([pr87_warm_last_n(2:3),pr87_warm_last_bg,pr87_warm_last_t, &\n"
        "                   pr87_warm_last_qv,pr87_warm_last_ccn3],[0],6)\n"
        "              flush(6)\n"
        "              error stop 'KDM6 warm native endpoint search failed'\n"
        "            endif\n"
    )
    return replace_once(source, fatal, diagnostic, "warm endpoint fatal")


if __name__ == "__main__":
    source = Path(__file__).with_name("module_mp_kdm6_v13_preprocessed.f90").read_text()
    output = generate(source)
    Path(__file__).with_name("module_mp_kdm6_v13_warm_diag.f90").write_text(output)
    print(hashlib.sha256(output.encode()).hexdigest())
